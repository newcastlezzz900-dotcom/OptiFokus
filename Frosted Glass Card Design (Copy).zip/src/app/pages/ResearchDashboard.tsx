/**
 * OptiFokus Research Dashboard
 * PKM KC & PIMNAS 2025 - Scientific Metrics & Analysis
 */

import { useState, useEffect } from "react";
import { AppLayout } from "@/app/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Badge } from "@/app/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/app/components/ui/tabs";
import { Progress } from "@/app/components/ui/progress";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  ScatterChart,
  Scatter,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";
import {
  Brain,
  TrendingUp,
  TrendingDown,
  Activity,
  Target,
  Zap,
  Users,
  Shield,
  Download,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  BarChart3,
  PieChart,
  Eye,
  Database,
  FileText,
  Settings,
} from "lucide-react";
import { motion } from "motion/react";
import {
  getResearchUserId,
  getExperimentConfig,
  getQuizAttempts,
  getDistractionEvents,
  getLearningProgress,
  getAdaptiveDifficulty,
  getUsagePatterns,
  getDistractionPredictions,
  getAuditTrail,
  getBehaviorFlags,
  getResearchMetrics,
  exportResearchData,
  exportResearchCSV,
  updateResearchMetrics,
} from "@/app/lib/research-store";

export function ResearchDashboard() {
  const [userId] = useState(getResearchUserId());
  const [config] = useState(getExperimentConfig());
  const [quizAttempts] = useState(getQuizAttempts());
  const [distractions] = useState(getDistractionEvents());
  const [learningProgress] = useState(getLearningProgress());
  const [adaptiveDiff] = useState(getAdaptiveDifficulty());
  const [usagePatterns] = useState(getUsagePatterns());
  const [predictions] = useState(getDistractionPredictions());
  const [auditTrail] = useState(getAuditTrail());
  const [behaviorFlags] = useState(getBehaviorFlags());
  const [metrics, setMetrics] = useState(getResearchMetrics());

  useEffect(() => {
    updateResearchMetrics();
    setMetrics(getResearchMetrics());
  }, []);

  // Calculate quiz statistics
  const quizStats = {
    total: quizAttempts.length,
    correct: quizAttempts.filter(q => q.isCorrect).length,
    accuracy: quizAttempts.length > 0 
      ? (quizAttempts.filter(q => q.isCorrect).length / quizAttempts.length * 100).toFixed(1)
      : 0,
    avgResponseTime: quizAttempts.length > 0
      ? (quizAttempts.reduce((sum, q) => sum + q.responseTime, 0) / quizAttempts.length / 1000).toFixed(1)
      : 0,
  };

  // Calculate distraction statistics
  const distractionStats = {
    total: distractions.length,
    blocked: distractions.filter(d => d.wasBlocked).length,
    blockRate: distractions.length > 0
      ? (distractions.filter(d => d.wasBlocked).length / distractions.length * 100).toFixed(1)
      : 0,
    predicted: predictions.filter(p => p.preventionSuggested).length,
  };

  // Prepare chart data
  const quizAccuracyOverTime = quizAttempts
    .map((q, i) => ({
      attempt: i + 1,
      accuracy: quizAttempts.slice(0, i + 1).filter(qa => qa.isCorrect).length / (i + 1) * 100,
      responseTime: q.responseTime / 1000,
    }))
    .filter((_, i) => i % 5 === 0 || i === quizAttempts.length - 1); // Sample every 5

  const difficultyDistribution = [
    {
      difficulty: "Easy",
      count: quizAttempts.filter(q => q.difficulty === "easy").length,
      correct: quizAttempts.filter(q => q.difficulty === "easy" && q.isCorrect).length,
    },
    {
      difficulty: "Medium",
      count: quizAttempts.filter(q => q.difficulty === "medium").length,
      correct: quizAttempts.filter(q => q.difficulty === "medium" && q.isCorrect).length,
    },
    {
      difficulty: "Hard",
      count: quizAttempts.filter(q => q.difficulty === "hard").length,
      correct: quizAttempts.filter(q => q.difficulty === "hard" && q.isCorrect).length,
    },
  ];

  const adaptiveProgress = adaptiveDiff?.performanceHistory.map((h, i) => ({
    attempt: i + 1,
    difficulty: (h.difficulty * 100).toFixed(0),
    success: h.success ? 100 : 0,
  })) || [];

  const distractionByHour = Array.from({ length: 24 }, (_, hour) => {
    const hourDistractions = distractions.filter(d => 
      new Date(d.timestamp).getHours() === hour
    );
    return {
      hour: `${hour}:00`,
      count: hourDistractions.length,
      blocked: hourDistractions.filter(d => d.wasBlocked).length,
    };
  }).filter(d => d.count > 0);

  const responseTimeDistribution = quizAttempts.map(q => ({
    responseTime: q.responseTime / 1000,
    correct: q.isCorrect ? 1 : 0,
  }));

  const handleExportJSON = () => {
    const data = exportResearchData();
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `optifokus-research-${userId}-${new Date().toISOString().split("T")[0]}.json`;
    a.click();
  };

  const handleExportCSV = () => {
    const csv = exportResearchCSV();
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `optifokus-research-${userId}-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  return (
    <AppLayout>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-blue-950/20 dark:to-purple-950/20">
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Research Dashboard
                </h1>
                <p className="text-gray-600 dark:text-gray-400">
                  Scientific Data Collection & Analysis - PKM KC 2025
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleExportCSV}
                  variant="outline"
                  className="border-blue-300 dark:border-blue-700"
                >
                  <Download className="mr-2 w-4 h-4" />
                  Export CSV
                </Button>
                <Button
                  onClick={handleExportJSON}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                >
                  <Database className="mr-2 w-4 h-4" />
                  Export JSON
                </Button>
              </div>
            </div>

            {/* Research ID & Config */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Eye className="w-4 h-4 text-blue-600" />
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      Research ID
                    </span>
                  </div>
                  <p className="text-xs font-mono text-gray-900 dark:text-white break-all">
                    {userId}
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Settings className="w-4 h-4 text-purple-600" />
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      Experiment Variant
                    </span>
                  </div>
                  <Badge className={
                    config?.variant === "control" 
                      ? "bg-gray-500"
                      : config?.variant === "treatment_A"
                      ? "bg-blue-500"
                      : "bg-purple-500"
                  }>
                    {config?.variant?.toUpperCase()}
                  </Badge>
                </CardContent>
              </Card>

              <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      Data Points
                    </span>
                  </div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {metrics.dataPoints.toLocaleString()}
                  </p>
                </CardContent>
              </Card>
            </div>
          </motion.div>

          {/* Key Metrics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
          >
            <Card className="bg-gradient-to-br from-green-500 to-emerald-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Brain className="w-8 h-8" />
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div className="text-3xl font-bold mb-1">
                  {quizStats.accuracy}%
                </div>
                <div className="text-sm opacity-90">Quiz Accuracy</div>
                <div className="mt-2 text-xs opacity-75">
                  {quizStats.correct}/{quizStats.total} correct
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-500 to-cyan-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Shield className="w-8 h-8" />
                  <CheckCircle className="w-5 h-5" />
                </div>
                <div className="text-3xl font-bold mb-1">
                  {distractionStats.blockRate}%
                </div>
                <div className="text-sm opacity-90">Block Success Rate</div>
                <div className="mt-2 text-xs opacity-75">
                  {distractionStats.blocked}/{distractionStats.total} blocked
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-500 to-pink-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Target className="w-8 h-8" />
                  <Activity className="w-5 h-5" />
                </div>
                <div className="text-3xl font-bold mb-1">
                  {(adaptiveDiff?.currentDifficulty * 100).toFixed(0)}%
                </div>
                <div className="text-sm opacity-90">Adaptive Difficulty</div>
                <div className="mt-2 text-xs opacity-75">
                  Stability: {(adaptiveDiff?.stabilityScore * 100).toFixed(0)}%
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500 to-red-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Zap className="w-8 h-8" />
                  <Eye className="w-5 h-5" />
                </div>
                <div className="text-3xl font-bold mb-1">
                  {distractionStats.predicted}
                </div>
                <div className="text-sm opacity-90">Predictions Made</div>
                <div className="mt-2 text-xs opacity-75">
                  PDD Model Active
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <Tabs defaultValue="ubcq" className="space-y-6">
            <TabsList className="bg-white/50 dark:bg-gray-900/50 backdrop-blur-lg grid grid-cols-5 w-full">
              <TabsTrigger value="ubcq">UBCQ</TabsTrigger>
              <TabsTrigger value="adaptive">Adaptive</TabsTrigger>
              <TabsTrigger value="pdd">PDD</TabsTrigger>
              <TabsTrigger value="validity">Validity</TabsTrigger>
              <TabsTrigger value="export">Export</TabsTrigger>
            </TabsList>

            {/* UBCQ Tab */}
            <TabsContent value="ubcq" className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Brain className="w-5 h-5 text-green-600" />
                      Unlock-by-Contextual-Quiz (UBCQ) Performance
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={quizAccuracyOverTime}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                        <XAxis dataKey="attempt" label={{ value: "Attempt Number", position: "insideBottom", offset: -5 }} />
                        <YAxis yAxisId="left" label={{ value: "Accuracy (%)", angle: -90, position: "insideLeft" }} />
                        <YAxis yAxisId="right" orientation="right" label={{ value: "Response Time (s)", angle: 90, position: "insideRight" }} />
                        <Tooltip />
                        <Legend />
                        <Line yAxisId="left" type="monotone" dataKey="accuracy" stroke="#10B981" strokeWidth={3} name="Accuracy %" />
                        <Line yAxisId="right" type="monotone" dataKey="responseTime" stroke="#F59E0B" strokeWidth={2} name="Response Time (s)" />
                      </LineChart>
                    </ResponsiveContainer>

                    <div className="mt-6 grid grid-cols-3 gap-4">
                      <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <div className="text-sm text-green-700 dark:text-green-300 mb-1">
                          Total Attempts
                        </div>
                        <div className="text-3xl font-bold text-green-700 dark:text-green-300">
                          {quizStats.total}
                        </div>
                      </div>
                      <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <div className="text-sm text-blue-700 dark:text-blue-300 mb-1">
                          Avg Response Time
                        </div>
                        <div className="text-3xl font-bold text-blue-700 dark:text-blue-300">
                          {quizStats.avgResponseTime}s
                        </div>
                      </div>
                      <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                        <div className="text-sm text-purple-700 dark:text-purple-300 mb-1">
                          Learning Retention
                        </div>
                        <div className="text-3xl font-bold text-purple-700 dark:text-purple-300">
                          {metrics.improvements.learningRetention.toFixed(0)}%
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-blue-600" />
                      Difficulty Distribution & Performance
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={difficultyDistribution}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                        <XAxis dataKey="difficulty" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="count" fill="#3B82F6" name="Total Attempts" />
                        <Bar dataKey="correct" fill="#10B981" name="Correct Answers" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Adaptive Tab */}
            <TabsContent value="adaptive" className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="w-5 h-5 text-purple-600" />
                      Adaptive Difficulty Loop - Real-time Adjustment
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <AreaChart data={adaptiveProgress}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                        <XAxis dataKey="attempt" label={{ value: "Attempt", position: "insideBottom", offset: -5 }} />
                        <YAxis label={{ value: "Value", angle: -90, position: "insideLeft" }} />
                        <Tooltip />
                        <Legend />
                        <Area type="monotone" dataKey="difficulty" stackId="1" stroke="#8B5CF6" fill="url(#difficultyGradient)" name="Difficulty Level %" />
                        <Area type="monotone" dataKey="success" stackId="2" stroke="#10B981" fill="url(#successGradient)" name="Success (100=Yes, 0=No)" />
                        <defs>
                          <linearGradient id="difficultyGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.8}/>
                            <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0.1}/>
                          </linearGradient>
                          <linearGradient id="successGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
                            <stop offset="95%" stopColor="#10B981" stopOpacity={0.1}/>
                          </linearGradient>
                        </defs>
                      </AreaChart>
                    </ResponsiveContainer>

                    <div className="mt-6 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                      <h3 className="font-bold text-purple-900 dark:text-purple-300 mb-2">
                        🧠 Adaptive Algorithm Insights
                      </h3>
                      <ul className="text-sm text-purple-800 dark:text-purple-200 space-y-1">
                        <li>• Current Difficulty: <strong>{(adaptiveDiff?.currentDifficulty * 100).toFixed(0)}%</strong></li>
                        <li>• Adaptation Rate: <strong>{(adaptiveDiff?.adaptationRate * 100).toFixed(0)}%</strong> per adjustment</li>
                        <li>• Performance Stability: <strong>{(adaptiveDiff?.stabilityScore * 100).toFixed(0)}%</strong></li>
                        <li>• History Tracking: <strong>{adaptiveDiff?.performanceHistory.length || 0}</strong> attempts recorded</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-orange-600" />
                      Response Time vs Correctness
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <ScatterChart>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                        <XAxis type="number" dataKey="responseTime" name="Response Time" unit="s" />
                        <YAxis type="number" dataKey="correct" name="Correct" domain={[-0.1, 1.1]} ticks={[0, 1]} />
                        <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                        <Scatter name="Quiz Attempts" data={responseTimeDistribution} fill="#8B5CF6">
                          {responseTimeDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.correct ? "#10B981" : "#EF4444"} />
                          ))}
                        </Scatter>
                      </ScatterChart>
                    </ResponsiveContainer>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-4 text-center">
                      🟢 Green = Correct | 🔴 Red = Incorrect
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* PDD Tab */}
            <TabsContent value="pdd" className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Eye className="w-5 h-5 text-orange-600" />
                      Predictive Distraction Detection (PDD) - Time Patterns
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={distractionByHour}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                        <XAxis dataKey="hour" label={{ value: "Time of Day", position: "insideBottom", offset: -5 }} />
                        <YAxis label={{ value: "Distraction Count", angle: -90, position: "insideLeft" }} />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="count" stackId="a" fill="#F59E0B" name="Total Distractions" />
                        <Bar dataKey="blocked" stackId="a" fill="#10B981" name="Successfully Blocked" />
                      </BarChart>
                    </ResponsiveContainer>

                    <div className="mt-6 grid grid-cols-2 gap-4">
                      <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                        <div className="text-sm text-orange-700 dark:text-orange-300 mb-1">
                          Peak Distraction Hour
                        </div>
                        <div className="text-2xl font-bold text-orange-700 dark:text-orange-300">
                          {distractionByHour.length > 0
                            ? distractionByHour.reduce((prev, current) => 
                                prev.count > current.count ? prev : current
                              ).hour
                            : "N/A"}
                        </div>
                      </div>
                      <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <div className="text-sm text-green-700 dark:text-green-300 mb-1">
                          Prediction Accuracy
                        </div>
                        <div className="text-2xl font-bold text-green-700 dark:text-green-300">
                          {predictions.length > 0
                            ? ((predictions.filter(p => p.actualDistraction).length / predictions.length) * 100).toFixed(0)
                            : 0}%
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-blue-600" />
                      PDD Model Performance
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-600 dark:text-gray-400">Predictions Made</span>
                          <span className="font-semibold dark:text-white">{predictions.length}</span>
                        </div>
                        <Progress value={(predictions.length / 100) * 100} className="h-2" />
                      </div>

                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-600 dark:text-gray-400">Prevention Suggested</span>
                          <span className="font-semibold dark:text-white">
                            {predictions.filter(p => p.preventionSuggested).length}
                          </span>
                        </div>
                        <Progress 
                          value={(predictions.filter(p => p.preventionSuggested).length / predictions.length) * 100} 
                          className="h-2" 
                        />
                      </div>

                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-600 dark:text-gray-400">Prevention Accepted</span>
                          <span className="font-semibold dark:text-white">
                            {predictions.filter(p => p.preventionAccepted).length}
                          </span>
                        </div>
                        <Progress 
                          value={(predictions.filter(p => p.preventionAccepted).length / predictions.filter(p => p.preventionSuggested).length) * 100} 
                          className="h-2" 
                        />
                      </div>
                    </div>

                    <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <h3 className="font-bold text-blue-900 dark:text-blue-300 mb-2">
                        🔮 PDD Algorithm Details
                      </h3>
                      <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                        <li>• <strong>Model Type:</strong> Rule-based + Historical Pattern Matching</li>
                        <li>• <strong>Features:</strong> Time of day, Day of week, Recent activity</li>
                        <li>• <strong>Threshold:</strong> 30% probability for notification</li>
                        <li>• <strong>Validation:</strong> Continuous accuracy tracking</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Validity Tab */}
            <TabsContent value="validity" className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="w-5 h-5 text-red-600" />
                      Anti-Gaming & Data Validity
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="font-semibold text-green-900 dark:text-green-300">
                            Data Integrity: VALID
                          </span>
                        </div>
                        <p className="text-sm text-green-800 dark:text-green-200">
                          No critical behavior anomalies detected. Data suitable for research analysis.
                        </p>
                      </div>

                      <div>
                        <h3 className="font-bold text-gray-900 dark:text-white mb-3">
                          Behavior Flags ({behaviorFlags.length})
                        </h3>
                        {behaviorFlags.length === 0 ? (
                          <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg text-center text-gray-500 dark:text-gray-400">
                            No behavior flags detected - clean data
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {behaviorFlags.slice(0, 5).map(flag => (
                              <div
                                key={flag.id}
                                className={`p-3 rounded-lg border ${
                                  flag.severity === "high"
                                    ? "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800"
                                    : flag.severity === "medium"
                                    ? "bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800"
                                    : "bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800"
                                }`}
                              >
                                <div className="flex items-center justify-between mb-1">
                                  <Badge className={
                                    flag.severity === "high" ? "bg-red-500" : 
                                    flag.severity === "medium" ? "bg-yellow-500" : 
                                    "bg-blue-500"
                                  }>
                                    {flag.flagType}
                                  </Badge>
                                  <span className="text-xs text-gray-500 dark:text-gray-400">
                                    {new Date(flag.timestamp).toLocaleString()}
                                  </span>
                                </div>
                                <p className="text-sm text-gray-700 dark:text-gray-300">
                                  {flag.evidence.join(", ")}
                                </p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <div>
                        <h3 className="font-bold text-gray-900 dark:text-white mb-3">
                          Audit Trail ({auditTrail.length} events)
                        </h3>
                        <div className="space-y-2 max-h-64 overflow-y-auto">
                          {auditTrail.slice(-10).reverse().map(event => (
                            <div
                              key={event.id}
                              className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg text-xs"
                            >
                              <div className="flex items-center justify-between mb-1">
                                <span className="font-medium text-gray-900 dark:text-white">
                                  {event.eventType}
                                </span>
                                <span className="text-gray-500 dark:text-gray-400">
                                  {new Date(event.timestamp).toLocaleTimeString()}
                                </span>
                              </div>
                              <p className="text-gray-600 dark:text-gray-400 font-mono">
                                Hash: {event.integrityHash.slice(0, 16)}...
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Export Tab */}
            <TabsContent value="export" className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Download className="w-5 h-5 text-blue-600" />
                      Research-Ready Export
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg">
                        <h3 className="font-bold text-blue-900 dark:text-blue-300 mb-3">
                          📊 Export Options
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <Button
                            onClick={handleExportCSV}
                            variant="outline"
                            className="h-auto py-4 flex-col gap-2"
                          >
                            <FileText className="w-8 h-8 text-green-600" />
                            <div>
                              <div className="font-bold">CSV Format</div>
                              <div className="text-xs text-gray-600 dark:text-gray-400">
                                For SPSS, Excel, R analysis
                              </div>
                            </div>
                          </Button>

                          <Button
                            onClick={handleExportJSON}
                            variant="outline"
                            className="h-auto py-4 flex-col gap-2"
                          >
                            <Database className="w-8 h-8 text-blue-600" />
                            <div>
                              <div className="font-bold">JSON Format</div>
                              <div className="text-xs text-gray-600 dark:text-gray-400">
                                Full data structure
                              </div>
                            </div>
                          </Button>
                        </div>
                      </div>

                      <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                        <h3 className="font-bold text-yellow-900 dark:text-yellow-300 mb-2 flex items-center gap-2">
                          <AlertTriangle className="w-5 h-5" />
                          Research Ethics Notice
                        </h3>
                        <ul className="text-sm text-yellow-800 dark:text-yellow-200 space-y-1">
                          <li>✓ All data is anonymized (no PII)</li>
                          <li>✓ User consent required for research use</li>
                          <li>✓ Data stored locally (privacy-first)</li>
                          <li>✓ Suitable for IRB submission</li>
                        </ul>
                      </div>

                      <div>
                        <h3 className="font-bold text-gray-900 dark:text-white mb-3">
                          Included Metrics
                        </h3>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                            ✓ Quiz attempts & accuracy
                          </div>
                          <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                            ✓ Distraction events
                          </div>
                          <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                            ✓ Adaptive difficulty history
                          </div>
                          <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                            ✓ Usage patterns
                          </div>
                          <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                            ✓ PDD predictions
                          </div>
                          <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                            ✓ Audit trail
                          </div>
                          <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                            ✓ Behavior flags
                          </div>
                          <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
                            ✓ Research metrics
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AppLayout>
  );
}
