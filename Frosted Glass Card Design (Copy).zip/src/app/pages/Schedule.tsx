import { useState, useEffect } from "react";
import { AppLayout } from "@/app/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Badge } from "@/app/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/app/components/ui/dialog";
import {
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  User,
  Plus,
  Edit,
  Trash2,
} from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";
import {
  getSchedules,
  addSchedule,
  updateSchedule,
  deleteSchedule,
  getUserBadgeColor,
  getUserBadgeLabel,
  Schedule as ScheduleType,
} from "@/app/lib/store";

const DAYS = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const COLORS = [
  { name: "Blue", value: "bg-blue-500" },
  { name: "Purple", value: "bg-purple-500" },
  { name: "Green", value: "bg-green-500" },
  { name: "Orange", value: "bg-orange-500" },
  { name: "Pink", value: "bg-pink-500" },
  { name: "Teal", value: "bg-teal-500" },
];

export function Schedule() {
  const [schedules, setSchedules] = useState<ScheduleType[]>(getSchedules());
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<ScheduleType | null>(null);
  
  // Form states
  const [mataPelajaran, setMataPelajaran] = useState("");
  const [hari, setHari] = useState("Senin");
  const [jamMulai, setJamMulai] = useState("");
  const [jamSelesai, setJamSelesai] = useState("");
  const [ruangan, setRuangan] = useState("");
  const [dosen, setDosen] = useState("");
  const [selectedColor, setSelectedColor] = useState("bg-blue-500");

  const userBadgeColor = getUserBadgeColor();
  const userBadgeLabel = getUserBadgeLabel();

  useEffect(() => {
    setSchedules(getSchedules());
  }, []);

  const handleAddSchedule = () => {
    if (!mataPelajaran || !jamMulai || !jamSelesai) {
      toast.error("Mata pelajaran dan jam harus diisi!");
      return;
    }

    const newSchedule = addSchedule({
      mataPelajaran,
      hari,
      jamMulai,
      jamSelesai,
      ruangan,
      dosen,
      color: selectedColor,
    });

    setSchedules(getSchedules());
    resetForm();
    setShowAddDialog(false);
    toast.success("Jadwal berhasil ditambahkan! 📅");
  };

  const handleUpdateSchedule = () => {
    if (!editingSchedule) return;

    updateSchedule(editingSchedule.id, {
      mataPelajaran,
      hari,
      jamMulai,
      jamSelesai,
      ruangan,
      dosen,
      color: selectedColor,
    });

    setSchedules(getSchedules());
    resetForm();
    setEditingSchedule(null);
    toast.success("Jadwal berhasil diupdate! ✅");
  };

  const handleDeleteSchedule = (id: string) => {
    if (confirm("Yakin ingin menghapus jadwal ini?")) {
      deleteSchedule(id);
      setSchedules(getSchedules());
      toast.success("Jadwal dihapus");
    }
  };

  const handleEditSchedule = (schedule: ScheduleType) => {
    setEditingSchedule(schedule);
    setMataPelajaran(schedule.mataPelajaran);
    setHari(schedule.hari);
    setJamMulai(schedule.jamMulai);
    setJamSelesai(schedule.jamSelesai);
    setRuangan(schedule.ruangan || "");
    setDosen(schedule.dosen || "");
    setSelectedColor(schedule.color);
  };

  const resetForm = () => {
    setMataPelajaran("");
    setHari("Senin");
    setJamMulai("");
    setJamSelesai("");
    setRuangan("");
    setDosen("");
    setSelectedColor("bg-blue-500");
  };

  const getSchedulesByDay = (day: string) => {
    return schedules
      .filter((s) => s.hari === day)
      .sort((a, b) => a.jamMulai.localeCompare(b.jamMulai));
  };

  // Get current date info
  const now = new Date();
  const dayName = now.toLocaleDateString("id-ID", { weekday: "long" });
  const dayDate = now.getDate();
  const monthName = now.toLocaleDateString("id-ID", { month: "long" });
  const currentDateString = `${dayName} - ${dayDate} - ${monthName}`;

  const getTodaySchedules = () => {
    return getSchedulesByDay(dayName);
  };

  return (
    <AppLayout>
      {/* Beautiful Background */}
      <div className="fixed inset-0 -z-10 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-950 dark:via-blue-950/20 dark:to-purple-950/20" />
      <div className="fixed inset-0 -z-10 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5Q0EzQUYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDEzNGgxMnYxMkgzNnptMjQtMjRoMTJ2MTJINjB6bS0yNCAwaDEydjEySDM2em0wLTI0aDEydjEySDM2em0tMjQgMGgxMnYxMkgxMnptMC0yNGgxMnYxMkgxMnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-40 dark:opacity-20" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 relative">
        {/* Header with Date and User Badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">
                  {currentDateString}
                </h1>
                <Badge className={`${userBadgeColor} text-white border-0 px-3 py-1`}>
                  {userBadgeLabel}
                </Badge>
              </div>
              <p className="text-gray-600 dark:text-gray-400 text-sm sm:text-base">
                Jadwal Kuliah & Aktivitas Belajar
              </p>
            </div>
            <Button
              onClick={() => setShowAddDialog(true)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 w-full sm:w-auto shadow-lg hover:shadow-xl transition-shadow"
            >
              <Plus className="mr-2" size={18} />
              Tambah Jadwal
            </Button>
          </div>
        </motion.div>

        {/* Table View - Like the image */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <Card className="overflow-hidden bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-2 border-gray-200 dark:border-gray-800">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-blue-600 to-purple-600">
                    {DAYS.map((day) => (
                      <th
                        key={day}
                        className="px-4 py-4 text-left text-sm sm:text-base font-bold text-white border-r border-blue-500 last:border-r-0"
                      >
                        {day}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    {DAYS.map((day) => {
                      const daySchedules = getSchedulesByDay(day);
                      const isToday = day === dayName;
                      
                      return (
                        <td
                          key={day}
                          className={`align-top px-2 sm:px-4 py-4 border-r border-gray-200 dark:border-gray-700 last:border-r-0 ${
                            isToday ? "bg-blue-50 dark:bg-blue-950/30" : ""
                          }`}
                        >
                          {daySchedules.length === 0 ? (
                            <div className="text-center py-8 text-gray-400 dark:text-gray-600 text-sm">
                              Tidak ada jadwal
                            </div>
                          ) : (
                            <div className="space-y-2 min-h-[200px]">
                              {daySchedules.map((schedule) => (
                                <motion.div
                                  key={schedule.id}
                                  initial={{ opacity: 0, scale: 0.9 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  className={`p-2 sm:p-3 rounded-lg border-l-4 ${schedule.color} bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-850 hover:shadow-md transition-shadow group relative`}
                                  style={{
                                    borderLeftColor: schedule.color.replace('bg-', ''),
                                  }}
                                >
                                  {/* Edit/Delete buttons - show on hover */}
                                  <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-6 w-6 bg-white dark:bg-gray-700"
                                      onClick={() => handleEditSchedule(schedule)}
                                    >
                                      <Edit size={10} />
                                    </Button>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-6 w-6 text-red-600 hover:text-red-700 bg-white dark:bg-gray-700"
                                      onClick={() => handleDeleteSchedule(schedule.id)}
                                    >
                                      <Trash2 size={10} />
                                    </Button>
                                  </div>

                                  <h4 className="font-bold text-xs sm:text-sm text-gray-900 dark:text-white mb-1 pr-14">
                                    {schedule.mataPelajaran}
                                  </h4>
                                  
                                  <div className="space-y-0.5 text-xs text-gray-600 dark:text-gray-400">
                                    <div className="flex items-center gap-1">
                                      <Clock size={10} />
                                      <span className="text-xs">
                                        {schedule.jamMulai} - {schedule.jamSelesai}
                                      </span>
                                    </div>
                                    {schedule.ruangan && (
                                      <div className="flex items-center gap-1">
                                        <MapPin size={10} />
                                        <span className="text-xs truncate">{schedule.ruangan}</span>
                                      </div>
                                    )}
                                    {schedule.dosen && (
                                      <div className="flex items-center gap-1">
                                        <User size={10} />
                                        <span className="text-xs truncate">{schedule.dosen}</span>
                                      </div>
                                    )}
                                  </div>
                                </motion.div>
                              ))}
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                </tbody>
              </table>
            </div>
          </Card>
        </motion.div>

        {/* Statistics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid sm:grid-cols-3 gap-4"
        >
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/30 border-blue-200 dark:border-blue-800 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <p className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-1">
                {schedules.length}
              </p>
              <p className="text-sm text-blue-800 dark:text-blue-300">Total Jadwal</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/30 dark:to-purple-900/30 border-purple-200 dark:border-purple-800 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <p className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-1">
                {new Set(schedules.map((s) => s.mataPelajaran)).size}
              </p>
              <p className="text-sm text-purple-800 dark:text-purple-300">Mata Kuliah</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/30 dark:to-green-900/30 border-green-200 dark:border-green-800 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <p className="text-3xl font-bold text-green-600 dark:text-green-400 mb-1">
                {getTodaySchedules().length}
              </p>
              <p className="text-sm text-green-800 dark:text-green-300">Hari Ini</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Legend */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-6"
        >
          <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-sm">
            <CardContent className="p-4">
              <h3 className="font-bold text-sm mb-3 text-gray-900 dark:text-white">
                Status Pengguna:
              </h3>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-red-500 rounded-full" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    Pemula ({"<"} 1 bulan)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-yellow-500 rounded-full" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    Berkembang (1-12 bulan)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-green-500 rounded-full" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    Veteran ({">"}1 tahun)
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog
        open={showAddDialog || editingSchedule !== null}
        onOpenChange={(open) => {
          if (!open) {
            setShowAddDialog(false);
            setEditingSchedule(null);
            resetForm();
          }
        }}
      >
        <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingSchedule ? "Edit Jadwal" : "Tambah Jadwal Baru"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <Label className="mb-2 block">Mata Pelajaran / Kuliah *</Label>
              <Input
                placeholder="Contoh: Kalkulus II"
                value={mataPelajaran}
                onChange={(e) => setMataPelajaran(e.target.value)}
              />
            </div>

            <div>
              <Label className="mb-2 block">Hari *</Label>
              <select
                value={hari}
                onChange={(e) => setHari(e.target.value)}
                className="w-full border dark:border-gray-700 dark:bg-gray-800 dark:text-white rounded-lg px-3 py-2"
              >
                {DAYS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="mb-2 block">Jam Mulai *</Label>
                <Input
                  type="time"
                  value={jamMulai}
                  onChange={(e) => setJamMulai(e.target.value)}
                />
              </div>
              <div>
                <Label className="mb-2 block">Jam Selesai *</Label>
                <Input
                  type="time"
                  value={jamSelesai}
                  onChange={(e) => setJamSelesai(e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label className="mb-2 block">Ruangan / Tempat</Label>
              <Input
                placeholder="Contoh: GKU 201"
                value={ruangan}
                onChange={(e) => setRuangan(e.target.value)}
              />
            </div>

            <div>
              <Label className="mb-2 block">Dosen / Pengajar</Label>
              <Input
                placeholder="Contoh: Dr. Ahmad Santoso"
                value={dosen}
                onChange={(e) => setDosen(e.target.value)}
              />
            </div>

            <div>
              <Label className="mb-2 block">Warna Label</Label>
              <div className="grid grid-cols-6 gap-2">
                {COLORS.map((color) => (
                  <button
                    key={color.value}
                    onClick={() => setSelectedColor(color.value)}
                    className={`h-10 rounded-lg ${color.value} ${
                      selectedColor === color.value
                        ? "ring-4 ring-offset-2 ring-gray-400 scale-110"
                        : "hover:scale-105"
                    } transition-all`}
                  />
                ))}
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button
                onClick={editingSchedule ? handleUpdateSchedule : handleAddSchedule}
                className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600"
              >
                {editingSchedule ? "Update" : "Tambah"}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddDialog(false);
                  setEditingSchedule(null);
                  resetForm();
                }}
              >
                Batal
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
