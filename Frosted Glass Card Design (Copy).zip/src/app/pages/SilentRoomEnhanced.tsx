import { useState, useEffect } from "react";
import { AppLayout } from "@/app/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Avatar, AvatarFallback } from "@/app/components/ui/avatar";
import { Badge } from "@/app/components/ui/badge";
import { Progress } from "@/app/components/ui/progress";
import { ScrollArea } from "@/app/components/ui/scroll-area";
import {
  Users,
  Clock,
  UserPlus,
  LogOut,
  Zap,
  Coffee,
  Flame,
  Eye,
  Target,
  CheckCircle,
  XCircle,
  AlertCircle,
  TrendingUp,
  Mic,
  MicOff,
  Send,
  MessageCircle,
  Volume2,
  VolumeX,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

interface Participant {
  id: string;
  name: string;
  avatar: string;
  status: "focusing" | "break" | "offline";
  focusMinutes: number;
  streak: number;
  lastActivity: string;
  isMicOn?: boolean;
  isSpeaking?: boolean;
}

interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  message: string;
  timestamp: Date;
}

interface Room {
  id: string;
  name: string;
  description: string;
  participants: Participant[];
  maxParticipants: number;
  isBreakTime: boolean;
  timer: number;
  totalFocusTime: number;
}

interface ActivityLog {
  id: string;
  type: "join" | "leave" | "quiz_success" | "quiz_failed" | "focus_complete";
  user: string;
  timestamp: Date;
  message: string;
}

// Mock data
const mockRooms: Room[] = [
  {
    id: "1",
    name: "Deep Work Session",
    description: "50 min focus + 10 min break",
    participants: [
      { 
        id: "1", 
        name: "Sarah Putri", 
        avatar: "SP",
        status: "focusing", 
        focusMinutes: 145, 
        streak: 12,
        lastActivity: "Focusing for 23 minutes",
        isMicOn: false,
        isSpeaking: false,
      },
      { 
        id: "2", 
        name: "Ahmad Rizki", 
        avatar: "AR",
        status: "focusing", 
        focusMinutes: 98, 
        streak: 8,
        lastActivity: "Focusing for 18 minutes",
        isMicOn: false,
        isSpeaking: false,
      },
      { 
        id: "3", 
        name: "Dinda Ayu", 
        avatar: "DA",
        status: "break", 
        focusMinutes: 78, 
        streak: 5,
        lastActivity: "On break (2 min left)",
        isMicOn: true,
        isSpeaking: true,
      },
      { 
        id: "4", 
        name: "Budi Santoso", 
        avatar: "BS",
        status: "break", 
        focusMinutes: 156, 
        streak: 15,
        lastActivity: "On break (5 min left)",
        isMicOn: true,
        isSpeaking: false,
      },
    ],
    maxParticipants: 10,
    isBreakTime: false,
    timer: 2345,
    totalFocusTime: 1250,
  },
  {
    id: "2",
    name: "Study Together",
    description: "40 min focus + 5 min break",
    participants: [
      { 
        id: "5", 
        name: "Eka Pratama", 
        avatar: "EP",
        status: "focusing", 
        focusMinutes: 67, 
        streak: 4,
        lastActivity: "Focusing for 12 minutes",
        isMicOn: false,
        isSpeaking: false,
      },
      { 
        id: "6", 
        name: "Fira Amelia", 
        avatar: "FA",
        status: "focusing", 
        focusMinutes: 89, 
        streak: 7,
        lastActivity: "Focusing for 15 minutes",
        isMicOn: false,
        isSpeaking: false,
      },
    ],
    maxParticipants: 8,
    isBreakTime: false,
    timer: 1890,
    totalFocusTime: 680,
  },
];

export function SilentRoomEnhanced() {
  const [rooms] = useState<Room[]>(mockRooms);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [isInRoom, setIsInRoom] = useState(false);
  const [roomTimer, setRoomTimer] = useState(0);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [isBreakMode, setIsBreakMode] = useState(false);
  const [isMicOn, setIsMicOn] = useState(false);
  const [isSoundOn, setIsSoundOn] = useState(true);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      userId: "3",
      userName: "Dinda Ayu",
      message: "Halo semua! Break dulu ya 😊",
      timestamp: new Date(Date.now() - 120000),
    },
    {
      id: "2",
      userId: "4",
      userName: "Budi Santoso",
      message: "Siap! Tadi materinya lumayan berat ya",
      timestamp: new Date(Date.now() - 60000),
    },
  ]);
  const [messageInput, setMessageInput] = useState("");

  useEffect(() => {
    if (isInRoom && selectedRoom) {
      const interval = setInterval(() => {
        setRoomTimer((prev) => {
          const newTime = prev + 1;
          // Auto toggle break every 50 minutes
          if (newTime % 3000 === 0) {
            setIsBreakMode(prev => !prev);
            if (!isBreakMode) {
              toast.success("🎉 Break Time!", {
                description: "10 menit istirahat. Mic & chat diaktifkan!",
              });
            } else {
              toast.info("⚡ Focus Time!", {
                description: "Kembali fokus. Silent mode aktif.",
              });
              setIsMicOn(false);
            }
          }
          return newTime;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isInRoom, selectedRoom, isBreakMode]);

  const handleJoinRoom = (room: Room) => {
    setSelectedRoom(room);
    setIsInRoom(true);
    setRoomTimer(room.timer);
    
    const newLog: ActivityLog = {
      id: Date.now().toString(),
      type: "join",
      user: "You",
      timestamp: new Date(),
      message: "joined the room",
    };
    setActivityLogs([newLog, ...activityLogs]);
    
    toast.success(`Joined ${room.name}!`, {
      description: "Silent mode aktif. Fokus belajar!",
    });
  };

  const handleLeaveRoom = () => {
    const newLog: ActivityLog = {
      id: Date.now().toString(),
      type: "leave",
      user: "You",
      timestamp: new Date(),
      message: "left the room",
    };
    setActivityLogs([newLog, ...activityLogs]);
    
    setIsInRoom(false);
    setSelectedRoom(null);
    setIsMicOn(false);
    setIsBreakMode(false);
    toast.info("You left the room");
  };

  const handleToggleMic = () => {
    if (!isBreakMode) {
      toast.error("Mic hanya bisa diaktifkan saat break!");
      return;
    }
    
    setIsMicOn(!isMicOn);
    toast.success(isMicOn ? "Mic dimatikan" : "Mic dinyalakan 🎤");
  };

  const handleSendMessage = () => {
    if (!messageInput.trim()) return;
    
    if (!isBreakMode) {
      toast.error("Chat hanya bisa dikirim saat break!");
      return;
    }

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      userId: "you",
      userName: "You",
      message: messageInput,
      timestamp: new Date(),
    };

    setChatMessages([...chatMessages, newMessage]);
    setMessageInput("");
    toast.success("Pesan terkirim!");
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "Baru saja";
    if (diffMins < 60) return `${diffMins} menit lalu`;
    return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
  };

  if (!isInRoom) {
    return (
      <AppLayout>
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {/* Header */}
            <motion.div
              className="mb-8"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent mb-3">
                Silent Focus Room
              </h1>
              <p className="text-lg text-slate-600 dark:text-slate-300">
                Belajar bareng teman tanpa distraksi. Break time = mic & chat aktif! 🎯
              </p>
            </motion.div>

            {/* Info Box */}
            <motion.div
              className="mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 dark:from-orange-950/20 dark:to-yellow-950/20 border-2 border-orange-200 dark:border-orange-800 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <AlertCircle className="w-6 h-6 text-orange-600 dark:text-orange-400 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-bold text-orange-800 dark:text-orange-200 mb-3 text-lg">
                        💡 Fitur PKM KC: Silent Social Accountability
                      </h3>
                      <div className="space-y-2 text-sm text-orange-700 dark:text-orange-300">
                        <p>✅ <strong>Focus Mode:</strong> Silent (no mic, no chat) - Kehadiran sosial tanpa gangguan</p>
                        <p>✅ <strong>Break Mode:</strong> Mic & Chat aktif - Diskusi & networking</p>
                        <p>✅ <strong>Peer Presence:</strong> Lihat teman yang sedang fokus untuk motivasi</p>
                        <p>✅ <strong>Leaderboard Non-Publik:</strong> Kompetisi sehat tanpa toxic pressure</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Rooms Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {rooms.map((room, idx) => (
                <motion.div
                  key={room.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <Card className="shadow-xl border-2 border-blue-200 dark:border-blue-900 hover:shadow-2xl transition-all hover:scale-105">
                    <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
                      <CardTitle className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                            <Users size={24} />
                          </div>
                          <div>
                            <span>{room.name}</span>
                            <p className="text-sm font-normal opacity-90 mt-1">
                              {room.description}
                            </p>
                          </div>
                        </div>
                      </CardTitle>
                    </CardHeader>

                    <CardContent className="p-6">
                      {/* Stats */}
                      <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-xl border border-blue-200 dark:border-blue-800">
                          <Users className="w-5 h-5 text-blue-600 dark:text-blue-400 mb-1" />
                          <p className="text-xs text-blue-600 dark:text-blue-400">Participants</p>
                          <p className="font-bold text-blue-700 dark:text-blue-300">
                            {room.participants.length}/{room.maxParticipants}
                          </p>
                        </div>
                        <div className="p-3 bg-green-50 dark:bg-green-950/30 rounded-xl border border-green-200 dark:border-green-800">
                          <Clock className="w-5 h-5 text-green-600 dark:text-green-400 mb-1" />
                          <p className="text-xs text-green-600 dark:text-green-400">Focus Time</p>
                          <p className="font-bold text-green-700 dark:text-green-300">
                            {Math.floor(room.totalFocusTime / 60)}h {room.totalFocusTime % 60}m
                          </p>
                        </div>
                      </div>

                      {/* Participants */}
                      <div className="mb-6">
                        <p className="text-sm font-semibold text-slate-600 dark:text-slate-400 mb-3">
                          Active Now:
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {room.participants.slice(0, 5).map((participant) => (
                            <div
                              key={participant.id}
                              className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-lg"
                            >
                              <Avatar className="w-6 h-6">
                                <AvatarFallback className="text-xs bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                                  {participant.avatar}
                                </AvatarFallback>
                              </Avatar>
                              <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                                {participant.name}
                              </span>
                              {participant.status === "focusing" && (
                                <Zap className="w-3 h-3 text-blue-500" />
                              )}
                              {participant.status === "break" && (
                                <Coffee className="w-3 h-3 text-orange-500" />
                              )}
                            </div>
                          ))}
                          {room.participants.length > 5 && (
                            <Badge variant="secondary">
                              +{room.participants.length - 5} more
                            </Badge>
                          )}
                        </div>
                      </div>

                      <Button
                        onClick={() => handleJoinRoom(room)}
                        className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-lg"
                      >
                        <UserPlus className="mr-2" size={18} />
                        Join Room
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Header */}
          <motion.div
            className="mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <h1 className="text-3xl font-bold text-slate-800 dark:text-white">
                  {selectedRoom?.name}
                </h1>
                <p className="text-slate-600 dark:text-slate-300">
                  {selectedRoom?.description}
                </p>
              </div>
              
              <div className="flex items-center gap-3">
                {isBreakMode ? (
                  <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-5 py-2.5 text-base shadow-lg">
                    <Coffee className="w-5 h-5 mr-2 inline" />
                    Break Time
                  </Badge>
                ) : (
                  <Badge className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-5 py-2.5 text-base shadow-lg">
                    <Zap className="w-5 h-5 mr-2 inline" />
                    Focus Mode
                  </Badge>
                )}
                
                <Button
                  onClick={handleLeaveRoom}
                  variant="outline"
                  className="border-red-300 dark:border-red-700 text-red-600 dark:text-red-400"
                >
                  <LogOut className="mr-2" size={18} />
                  Leave
                </Button>
              </div>
            </div>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main Content - Participants & Voice */}
            <div className="lg:col-span-2 space-y-6">
              {/* Timer Card */}
              <Card className="shadow-xl border-2 border-blue-200 dark:border-blue-900">
                <CardContent className="p-8 text-center">
                  <div className="text-6xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent mb-4">
                    {formatTime(roomTimer)}
                  </div>
                  <Progress 
                    value={(roomTimer % 3000) / 30} 
                    className="h-3 mb-3" 
                  />
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    {isBreakMode ? "Break time remaining" : "Next break in"}: {formatTime(3000 - (roomTimer % 3000))}
                  </p>
                </CardContent>
              </Card>

              {/* Participants Grid */}
              <Card className="shadow-xl border-2 border-purple-200 dark:border-purple-900">
                <CardHeader className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                  <CardTitle className="flex items-center gap-3">
                    <Users size={24} />
                    <span>Participants ({selectedRoom?.participants.length})</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid sm:grid-cols-2 gap-4">
                    {selectedRoom?.participants.map((participant) => (
                      <motion.div
                        key={participant.id}
                        className={`p-4 rounded-xl border-2 ${
                          participant.status === "focusing"
                            ? "bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800"
                            : "bg-orange-50 dark:bg-orange-950/30 border-orange-200 dark:border-orange-800"
                        }`}
                        whileHover={{ scale: 1.05 }}
                      >
                        <div className="flex items-start gap-3">
                          <div className="relative">
                            <Avatar className={`w-12 h-12 ${
                              participant.isSpeaking 
                                ? "ring-4 ring-green-500 ring-offset-2" 
                                : ""
                            }`}>
                              <AvatarFallback className="text-sm bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                                {participant.avatar}
                              </AvatarFallback>
                            </Avatar>
                            {participant.status === "break" && participant.isMicOn && (
                              <div className="absolute -bottom-1 -right-1 p-1 bg-green-500 rounded-full">
                                <Mic className="w-3 h-3 text-white" />
                              </div>
                            )}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-slate-800 dark:text-white truncate">
                              {participant.name}
                            </p>
                            <p className="text-xs text-slate-600 dark:text-slate-400">
                              {participant.lastActivity}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="secondary" className="text-xs">
                                <Flame className="w-3 h-3 mr-1" />
                                {participant.streak} days
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Voice Controls (Only in Break) */}
              {isBreakMode && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <Card className="shadow-xl border-2 border-green-200 dark:border-green-900">
                    <CardHeader className="bg-gradient-to-r from-green-500 to-emerald-500 text-white">
                      <CardTitle className="flex items-center gap-3">
                        <Volume2 size={24} />
                        <span>Voice Controls</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-center gap-4">
                        <Button
                          onClick={handleToggleMic}
                          size="lg"
                          className={`h-20 w-20 rounded-full ${
                            isMicOn
                              ? "bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                              : "bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700"
                          }`}
                        >
                          {isMicOn ? <Mic size={32} /> : <MicOff size={32} />}
                        </Button>
                        
                        <Button
                          onClick={() => {
                            setIsSoundOn(!isSoundOn);
                            toast.success(isSoundOn ? "Sound muted" : "Sound on");
                          }}
                          size="lg"
                          variant="outline"
                          className="h-20 w-20 rounded-full"
                        >
                          {isSoundOn ? <Volume2 size={32} /> : <VolumeX size={32} />}
                        </Button>
                      </div>
                      
                      <p className="text-center text-sm text-slate-600 dark:text-slate-400 mt-4">
                        {isMicOn ? "🎤 Mic aktif - Kamu bisa bicara!" : "🔇 Mic muted"}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </div>

            {/* Sidebar - Chat & Activity */}
            <div className="space-y-6">
              {/* Chat Box (Only in Break) */}
              {isBreakMode ? (
                <Card className="shadow-xl border-2 border-indigo-200 dark:border-indigo-900">
                  <CardHeader className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
                    <CardTitle className="flex items-center gap-3">
                      <MessageCircle size={20} />
                      <span>Chat Room</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <ScrollArea className="h-80 mb-4 pr-4">
                      <div className="space-y-3">
                        {chatMessages.map((msg) => (
                          <motion.div
                            key={msg.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className={`p-3 rounded-lg ${
                              msg.userId === "you"
                                ? "bg-blue-100 dark:bg-blue-950/30 ml-8"
                                : "bg-slate-100 dark:bg-slate-800 mr-8"
                            }`}
                          >
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-xs text-slate-800 dark:text-white">
                                {msg.userName}
                              </span>
                              <span className="text-xs text-slate-500 dark:text-slate-400">
                                {formatTimestamp(msg.timestamp)}
                              </span>
                            </div>
                            <p className="text-sm text-slate-700 dark:text-slate-300">
                              {msg.message}
                            </p>
                          </motion.div>
                        ))}
                      </div>
                    </ScrollArea>
                    
                    <div className="flex gap-2">
                      <Input
                        placeholder="Ketik pesan..."
                        value={messageInput}
                        onChange={(e) => setMessageInput(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                      />
                      <Button
                        onClick={handleSendMessage}
                        className="bg-gradient-to-r from-indigo-500 to-purple-500"
                      >
                        <Send size={18} />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="shadow-xl border-2 border-slate-200 dark:border-slate-800">
                  <CardContent className="p-8 text-center">
                    <MessageCircle className="w-16 h-16 mx-auto mb-4 text-slate-400" />
                    <h3 className="font-bold text-lg text-slate-800 dark:text-white mb-2">
                      Silent Mode 🤫
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      Chat & voice akan aktif saat break time. Fokus dulu!
                    </p>
                  </CardContent>
                </Card>
              )}

              {/* Activity Log */}
              <Card className="shadow-xl border-2 border-slate-200 dark:border-slate-800">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <TrendingUp size={20} />
                    Activity Log
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <ScrollArea className="h-60">
                    <div className="space-y-2">
                      {activityLogs.map((log) => (
                        <div
                          key={log.id}
                          className="text-sm p-2 bg-slate-50 dark:bg-slate-800 rounded-lg"
                        >
                          <span className="font-semibold text-blue-600 dark:text-blue-400">
                            {log.user}
                          </span>{" "}
                          <span className="text-slate-600 dark:text-slate-400">
                            {log.message}
                          </span>
                          <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                            {formatTimestamp(log.timestamp)}
                          </p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
