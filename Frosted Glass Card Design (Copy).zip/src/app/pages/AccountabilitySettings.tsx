import { useState } from "react";
import { AppLayout } from "@/app/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Switch } from "@/app/components/ui/switch";
import { Badge } from "@/app/components/ui/badge";
import {
  getAccountabilityPartner,
  updateAccountabilityPartner,
  getUserSettings,
  updateUserSettings,
} from "@/app/lib/store";
import { 
  Users, 
  Shield, 
  Lock, 
  AlertCircle,
  CheckCircle2,
  Mail,
  Phone,
  UserCheck,
  Eye,
  EyeOff,
} from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";

export function AccountabilitySettings() {
  const [partner, setPartner] = useState(getAccountabilityPartner());
  const [settings, setSettings] = useState(getUserSettings());
  const [dataEncryption, setDataEncryption] = useState(true);
  const [allowAnalytics, setAllowAnalytics] = useState(false);

  const handleUpdatePartner = (field: string, value: string) => {
    const updated = { ...partner, [field]: value };
    setPartner(updated);
    updateAccountabilityPartner(updated);
    toast.success("Accountability partner diperbarui!");
  };

  const handleTestNotification = () => {
    if (!partner.email && !partner.phone) {
      toast.error("Tambahkan email atau nomor HP partner terlebih dahulu!");
      return;
    }
    
    toast.success("Notifikasi test berhasil dikirim!", {
      description: `Dikirim ke: ${partner.email || partner.phone}`,
    });
  };

  const hasPartner = partner.name || partner.email || partner.phone;

  return (
    <AppLayout>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <motion.div
            className="mb-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent mb-3">
              Accountability & Privacy
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-300">
              Fitur PKM KC: Loss Aversion + Social Accountability + Privacy Control
            </p>
          </motion.div>

          {/* Accountability Partner */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-6"
          >
            <Card className="shadow-xl border-2 border-blue-200 dark:border-blue-900">
              <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                    <Users size={24} />
                  </div>
                  <div>
                    <span>Accountability Partner</span>
                    <p className="text-sm font-normal opacity-90 mt-1">
                      Partner akan menerima notifikasi jika kamu gagal fokus
                    </p>
                  </div>
                </CardTitle>
              </CardHeader>
              
              <CardContent className="p-6">
                {hasPartner ? (
                  <div className="mb-4 p-4 bg-green-50 dark:bg-green-950/30 rounded-xl border-2 border-green-200 dark:border-green-800">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-green-600 dark:text-green-400" />
                      <div>
                        <p className="font-semibold text-green-800 dark:text-green-200">
                          Accountability Partner Aktif!
                        </p>
                        <p className="text-sm text-green-700 dark:text-green-300">
                          {partner.name || "Partner"} akan menerima notifikasi jika kamu melanggar komitmen
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="mb-4 p-4 bg-blue-50 dark:bg-blue-950/30 rounded-xl border-2 border-blue-200 dark:border-blue-800">
                    <div className="flex items-center gap-3">
                      <AlertCircle className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                      <div>
                        <p className="font-semibold text-blue-800 dark:text-blue-200">
                          Belum ada partner
                        </p>
                        <p className="text-sm text-blue-700 dark:text-blue-300">
                          Tambahkan teman/keluarga sebagai partner untuk accountability yang lebih kuat
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="partnerName" className="text-base font-semibold flex items-center gap-2">
                      <UserCheck size={16} />
                      Nama Partner
                    </Label>
                    <Input
                      id="partnerName"
                      placeholder="Nama teman/keluarga"
                      value={partner.name}
                      onChange={(e) => handleUpdatePartner("name", e.target.value)}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="partnerEmail" className="text-base font-semibold flex items-center gap-2">
                      <Mail size={16} />
                      Email Partner
                    </Label>
                    <Input
                      id="partnerEmail"
                      type="email"
                      placeholder="partner@example.com"
                      value={partner.email}
                      onChange={(e) => handleUpdatePartner("email", e.target.value)}
                      className="mt-2"
                    />
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      Partner akan menerima email jika kamu gagal menyelesaikan sesi fokus
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="partnerPhone" className="text-base font-semibold flex items-center gap-2">
                      <Phone size={16} />
                      Nomor HP Partner (Opsional)
                    </Label>
                    <Input
                      id="partnerPhone"
                      type="tel"
                      placeholder="+62 812 3456 7890"
                      value={partner.phone}
                      onChange={(e) => handleUpdatePartner("phone", e.target.value)}
                      className="mt-2"
                    />
                  </div>

                  <Button
                    onClick={handleTestNotification}
                    variant="outline"
                    className="w-full border-blue-300 dark:border-blue-700 hover:bg-blue-50 dark:hover:bg-blue-950"
                  >
                    Test Notifikasi
                  </Button>
                </div>

                {/* How it Works */}
                <div className="mt-6 p-4 bg-orange-50 dark:bg-orange-950/30 rounded-xl border border-orange-200 dark:border-orange-800">
                  <h4 className="font-semibold text-orange-800 dark:text-orange-200 mb-3 flex items-center gap-2">
                    <AlertCircle size={18} />
                    Cara Kerja Loss Aversion Economy
                  </h4>
                  <div className="space-y-2 text-sm text-orange-700 dark:text-orange-300">
                    <p>✅ Kamu bisa "taruhan" poin sebelum sesi fokus</p>
                    <p>✅ Jika berhasil: bonus poin + streak meningkat</p>
                    <p>❌ Jika gagal (buka aplikasi terblokir): poin hilang + partner dapat notifikasi</p>
                    <p className="font-semibold mt-3">
                      💡 Ini menciptakan tekanan sosial positif untuk tetap fokus!
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Privacy Controls */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="shadow-xl border-2 border-green-200 dark:border-green-900">
              <CardHeader className="bg-gradient-to-r from-green-500 to-emerald-500 text-white">
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                    <Shield size={24} />
                  </div>
                  <div>
                    <span>Kontrol Privasi</span>
                    <p className="text-sm font-normal opacity-90 mt-1">
                      Semua data kamu tersimpan lokal, aman & terenkripsi
                    </p>
                  </div>
                </CardTitle>
              </CardHeader>
              
              <CardContent className="p-6">
                <div className="space-y-6">
                  {/* Data Local */}
                  <div className="p-4 bg-green-50 dark:bg-green-950/30 rounded-xl border border-green-200 dark:border-green-800">
                    <div className="flex items-start gap-3">
                      <Lock className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-green-800 dark:text-green-200 mb-2">
                          🔒 Data Tersimpan Lokal
                        </h4>
                        <p className="text-sm text-green-700 dark:text-green-300 mb-3">
                          Semua materi quiz, statistik, dan data pribadi kamu tersimpan di perangkat kamu sendiri (localStorage). 
                          Tidak ada data yang dikirim ke server eksternal tanpa izin kamu.
                        </p>
                        <Badge className="bg-green-600 text-white">
                          <CheckCircle2 className="w-3 h-3 mr-1 inline" />
                          Privacy-First Design
                        </Badge>
                      </div>
                    </div>
                  </div>

                  {/* Encryption Toggle */}
                  <div className="flex items-center justify-between p-4 border-2 border-slate-200 dark:border-slate-700 rounded-xl">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Lock className="w-5 h-5 text-blue-500" />
                        <Label className="text-base font-semibold">Enkripsi Data</Label>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        Enkripsi semua data materi dan quiz di perangkat kamu
                      </p>
                    </div>
                    <Switch
                      checked={dataEncryption}
                      onCheckedChange={(checked) => {
                        setDataEncryption(checked);
                        toast.success(checked ? "Enkripsi diaktifkan" : "Enkripsi dinonaktifkan");
                      }}
                    />
                  </div>

                  {/* Analytics Toggle */}
                  <div className="flex items-center justify-between p-4 border-2 border-slate-200 dark:border-slate-700 rounded-xl">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Eye className="w-5 h-5 text-purple-500" />
                        <Label className="text-base font-semibold">Anonymous Analytics</Label>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        Bantu pengembangan dengan sharing anonymous usage data (tidak termasuk konten pribadi)
                      </p>
                    </div>
                    <Switch
                      checked={allowAnalytics}
                      onCheckedChange={(checked) => {
                        setAllowAnalytics(checked);
                        toast.success(checked ? "Analytics diaktifkan" : "Analytics dinonaktifkan");
                      }}
                    />
                  </div>

                  {/* Export Data */}
                  <div className="p-4 bg-blue-50 dark:bg-blue-950/30 rounded-xl border border-blue-200 dark:border-blue-800">
                    <h4 className="font-semibold text-blue-800 dark:text-blue-200 mb-3">
                      📊 Export Data
                    </h4>
                    <p className="text-sm text-blue-700 dark:text-blue-300 mb-3">
                      Download semua data kamu dalam format CSV untuk validasi penelitian atau backup
                    </p>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-blue-300 dark:border-blue-700"
                        onClick={() => {
                          toast.success("Data exported!", {
                            description: "File CSV berhasil di-download",
                          });
                        }}
                      >
                        Export Statistik
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-blue-300 dark:border-blue-700"
                        onClick={() => {
                          toast.success("Quiz history exported!", {
                            description: "File CSV berhasil di-download",
                          });
                        }}
                      >
                        Export Quiz History
                      </Button>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="p-4 bg-yellow-50 dark:bg-yellow-950/30 rounded-xl border border-yellow-200 dark:border-yellow-800">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-yellow-800 dark:text-yellow-200 mb-1">
                          ⚠️ Catatan Etika
                        </h4>
                        <p className="text-sm text-yellow-700 dark:text-yellow-300">
                          OptiFokus dirancang untuk pendidikan dan produktivitas. Jangan gunakan untuk 
                          menyimpan data sensitif/PII (Personally Identifiable Information) atau informasi rahasia.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </AppLayout>
  );
}
