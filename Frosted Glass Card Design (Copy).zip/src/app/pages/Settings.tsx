import { useState } from "react";
import { Navbar } from "@/app/components/Navbar";
import { BottomNav } from "@/app/components/BottomNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Switch } from "@/app/components/ui/switch";
import { Label } from "@/app/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/app/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/app/components/ui/dialog";
import {
  getBlockedApps,
  toggleAppBlock,
  getUserStats,
  updateUserStats,
  BlockedApp,
  updateBlockedApps,
  getUserSettings,
  updateUserSettings,
  getAccountabilityPartner,
  updateAccountabilityPartner,
} from "@/app/lib/store";
import { 
  Shield, 
  Trash2, 
  RotateCcw, 
  Settings as SettingsIcon, 
  Plus,
  User,
  Bell,
  Volume2,
  Clock,
  Target,
  Globe,
  Users,
  Lock,
  AlertCircle,
} from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";

export function Settings() {
  const [blockedApps, setBlockedApps] = useState(getBlockedApps());
  const [stats, setStats] = useState(getUserStats());
  const [settings, setSettings] = useState(getUserSettings());
  const [showAddApp, setShowAddApp] = useState(false);
  const [newAppName, setNewAppName] = useState("");
  const [newAppIcon, setNewAppIcon] = useState("📱");

  const emojiOptions = ["📱", "🎮", "📺", "🎵", "💬", "📷", "🎬", "🛒", "🎯", "⚽", "🎨", "📰"];
  const avatarOptions = ["😊", "👨‍🎓", "👩‍🎓", "🧑‍💻", "👨‍💼", "👩‍💼", "🎓", "📚", "🔥", "⭐", "💪", "🚀"];

  const handleToggleBlock = (appId: string) => {
    toggleAppBlock(appId);
    setBlockedApps(getBlockedApps());
    toast.success("Pengaturan diperbarui");
  };

  const handleAddCustomApp = () => {
    if (!newAppName.trim()) {
      toast.error("Nama aplikasi harus diisi!");
      return;
    }

    const newApp: BlockedApp = {
      id: Date.now().toString(),
      name: newAppName,
      icon: newAppIcon,
      isBlocked: false,
    };

    const updatedApps = [...blockedApps, newApp];
    updateBlockedApps(updatedApps);
    setBlockedApps(updatedApps);
    setNewAppName("");
    setNewAppIcon("📱");
    setShowAddApp(false);
    toast.success(`${newAppName} ditambahkan! Aktifkan untuk memblokir.`);
  };

  const handleDeleteApp = (appId: string) => {
    if (confirm("Yakin ingin menghapus aplikasi ini?")) {
      const updatedApps = blockedApps.filter((app) => app.id !== appId);
      updateBlockedApps(updatedApps);
      setBlockedApps(updatedApps);
      toast.success("Aplikasi dihapus");
    }
  };

  const handleUpdateSettings = (key: string, value: any) => {
    const newSettings = { ...settings, [key]: value };
    updateUserSettings(newSettings);
    setSettings(newSettings);
    toast.success("Pengaturan diperbarui");
  };

  const handleResetStats = () => {
    if (confirm("Yakin ingin reset semua statistik? Data tidak bisa dikembalikan!")) {
      updateUserStats({
        points: 0,
        streak: 0,
        totalFocusMinutes: 0,
        distractionsBlocked: 0,
        meetings: 0,
        lastActiveDate: new Date().toISOString().split("T")[0],
      });
      setStats(getUserStats());
      toast.success("Statistik direset");
    }
  };

  const activeBlocks = blockedApps.filter((app) => app.isBlocked).length;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-20 md:pb-0">
      {/* Beautiful Background */}
      <div className="fixed inset-0 -z-10 bg-gradient-to-br from-slate-50 via-gray-50 to-zinc-50 dark:from-gray-950 dark:via-slate-950/20 dark:to-zinc-950/20" />
      <div className="fixed inset-0 -z-10 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5Q0EzQUYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDEzNGgxMnYxMkgzNnptMjQtMjRoMTJ2MTJINjB6bS0yNCAwaDEydjEySDM2em0wLTI0aDEydjEySDM2em0tMjQgMGgxMnYxMkgxMnptMC0yNGgxMnYxMkgxMnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-40 dark:opacity-20" />
      
      <Navbar />
      <BottomNav />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 relative">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center gap-2">
            <SettingsIcon size={28} />
            Pengaturan
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6 sm:mb-8">
            Personalisasi aplikasi sesuai kebutuhanmu
          </p>
        </motion.div>

        <Tabs defaultValue="akun" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 gap-2">
            <TabsTrigger value="akun">
              <User size={16} className="mr-1 sm:mr-2" />
              <span className="hidden sm:inline">Akun</span>
            </TabsTrigger>
            <TabsTrigger value="aplikasi">
              <SettingsIcon size={16} className="mr-1 sm:mr-2" />
              <span className="hidden sm:inline">Aplikasi</span>
            </TabsTrigger>
            <TabsTrigger value="blokir">
              <Shield size={16} className="mr-1 sm:mr-2" />
              <span className="hidden sm:inline">Blokir</span>
            </TabsTrigger>
            <TabsTrigger value="lainnya">
              <Globe size={16} className="mr-1 sm:mr-2" />
              <span className="hidden sm:inline">Lainnya</span>
            </TabsTrigger>
          </TabsList>

          {/* Akun Tab */}
          <TabsContent value="akun" className="space-y-6">
            <Card className="dark:bg-gray-900 dark:border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User size={20} />
                  Informasi Akun
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label className="mb-2 block">Nama Pengguna</Label>
                  <Input
                    value={settings.userName}
                    onChange={(e) => handleUpdateSettings("userName", e.target.value)}
                    placeholder="Masukkan nama kamu"
                  />
                </div>

                <div>
                  <Label className="mb-3 block">Avatar</Label>
                  <div className="grid grid-cols-6 sm:grid-cols-12 gap-2">
                    {avatarOptions.map((emoji) => (
                      <button
                        key={emoji}
                        onClick={() => handleUpdateSettings("userAvatar", emoji)}
                        className={`p-3 text-2xl rounded-lg border-2 transition-all ${
                          settings.userAvatar === emoji
                            ? "border-blue-500 bg-blue-50 dark:bg-blue-950/30 scale-110"
                            : "border-gray-200 dark:border-gray-700 hover:border-blue-300"
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800">
                  <h4 className="font-semibold text-blue-900 dark:text-blue-200 mb-2">
                    Statistik Kamu
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-blue-700 dark:text-blue-300">Total Poin</p>
                      <p className="font-bold text-blue-900 dark:text-blue-100 text-lg">{stats.points}</p>
                    </div>
                    <div>
                      <p className="text-blue-700 dark:text-blue-300">Streak</p>
                      <p className="font-bold text-blue-900 dark:text-blue-100 text-lg">{stats.streak} hari</p>
                    </div>
                    <div>
                      <p className="text-blue-700 dark:text-blue-300">Waktu Fokus</p>
                      <p className="font-bold text-blue-900 dark:text-blue-100 text-lg">
                        {Math.floor(stats.totalFocusMinutes / 60)}j
                      </p>
                    </div>
                    <div>
                      <p className="text-blue-700 dark:text-blue-300">Pertemuan</p>
                      <p className="font-bold text-blue-900 dark:text-blue-100 text-lg">{stats.meetings}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aplikasi Tab */}
          <TabsContent value="aplikasi" className="space-y-6">
            <Card className="dark:bg-gray-900 dark:border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell size={20} />
                  Notifikasi & Suara
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <Label className="text-base">Notifikasi</Label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Dapatkan notifikasi untuk reminder dan achievement
                    </p>
                  </div>
                  <Switch
                    checked={settings.notifications}
                    onCheckedChange={(checked) => handleUpdateSettings("notifications", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <Label className="text-base">Efek Suara</Label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Mainkan sound effects untuk interaksi
                    </p>
                  </div>
                  <Switch
                    checked={settings.soundEffects}
                    onCheckedChange={(checked) => handleUpdateSettings("soundEffects", checked)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="dark:bg-gray-900 dark:border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock size={20} />
                  Pengaturan Fokus
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <Label className="text-base">Auto Break</Label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Mulai istirahat otomatis setelah sesi fokus
                    </p>
                  </div>
                  <Switch
                    checked={settings.autoBreak}
                    onCheckedChange={(checked) => handleUpdateSettings("autoBreak", checked)}
                  />
                </div>

                <div>
                  <Label className="mb-2 block">Durasi Istirahat (menit)</Label>
                  <select
                    value={settings.breakDuration}
                    onChange={(e) => handleUpdateSettings("breakDuration", parseInt(e.target.value))}
                    className="w-full border dark:border-gray-700 dark:bg-gray-800 dark:text-white rounded-lg px-3 py-2"
                  >
                    <option value={5}>5 menit</option>
                    <option value={10}>10 menit</option>
                    <option value={15}>15 menit</option>
                    <option value={20}>20 menit</option>
                  </select>
                </div>

                <div>
                  <Label className="mb-2 block flex items-center gap-2">
                    <Target size={16} />
                    Target Harian (menit)
                  </Label>
                  <Input
                    type="number"
                    value={settings.dailyGoal}
                    onChange={(e) => handleUpdateSettings("dailyGoal", parseInt(e.target.value) || 120)}
                    min={30}
                    max={480}
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Rekomendasi: 120 menit (2 jam)
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Blokir Tab */}
          <TabsContent value="blokir" className="space-y-6">
            <Card className="dark:bg-gray-900 dark:border-gray-800">
              <CardHeader className="bg-gradient-to-r from-red-500 to-orange-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center justify-between text-lg sm:text-xl">
                  <span className="flex items-center gap-2">
                    <Shield size={24} />
                    Kelola Aplikasi Diblokir
                  </span>
                  <span className="text-sm font-normal">
                    {activeBlocks}/{blockedApps.length} aktif
                  </span>
                </CardTitle>
              </CardHeader>
              
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Aktifkan pemblokiran untuk aplikasi yang sering mengganggumu
                  </p>
                  <Button
                    size="sm"
                    onClick={() => setShowAddApp(true)}
                    className="bg-gradient-to-r from-blue-600 to-purple-600"
                  >
                    <Plus size={16} className="mr-1" />
                    Tambah
                  </Button>
                </div>

                <div className="space-y-3">
                  {blockedApps.map((app) => (
                    <motion.div
                      key={app.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      whileHover={{ scale: 1.01 }}
                      className={`flex items-center justify-between p-3 sm:p-4 rounded-lg border-2 transition-all shadow-sm hover:shadow-md ${
                        app.isBlocked
                          ? "bg-red-50 dark:bg-red-950/30 border-red-400 dark:border-red-700"
                          : "bg-gray-50 dark:bg-gray-800 border-gray-300 dark:border-gray-600"
                      }`}
                    >
                      <div className="flex items-center gap-3 flex-1">
                        <span className="text-2xl sm:text-3xl">{app.icon}</span>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-gray-900 dark:text-white truncate">
                            {app.name}
                          </p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <p className={`text-xs font-medium ${
                              app.isBlocked 
                                ? "text-red-600 dark:text-red-400" 
                                : "text-gray-500 dark:text-gray-400"
                            }`}>
                              {app.isBlocked ? "🔒 Diblokir" : "🔓 Tidak diblokir"}
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <Switch
                          checked={app.isBlocked}
                          onCheckedChange={() => handleToggleBlock(app.id)}
                        />
                        {parseInt(app.id) > 8 && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => handleDeleteApp(app.id)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-950/30"
                          >
                            <Trash2 size={16} />
                          </Button>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-6 p-3 sm:p-4 bg-yellow-50 dark:bg-yellow-950/30 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                  <p className="text-sm text-yellow-800 dark:text-yellow-200">
                    <strong>💡 Tips:</strong> Blokir aplikasi yang paling sering mengganggumu 
                    saat belajar untuk hasil maksimal!
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Lainnya Tab */}
          <TabsContent value="lainnya" className="space-y-6">
            <Card className="dark:bg-gray-900 dark:border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe size={20} />
                  Bahasa & Tema
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="mb-2 block">Bahasa</Label>
                  <select
                    value={settings.language}
                    onChange={(e) => handleUpdateSettings("language", e.target.value)}
                    className="w-full border dark:border-gray-700 dark:bg-gray-800 dark:text-white rounded-lg px-3 py-2"
                  >
                    <option value="id">🇮🇩 Bahasa Indonesia</option>
                    <option value="en">🇬🇧 English</option>
                  </select>
                </div>

                <div>
                  <Label className="mb-2 block">Tema</Label>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">
                    Gunakan toggle di navbar untuk ganti tema
                  </p>
                  <div className="flex gap-2">
                    <div className="flex-1 p-4 border-2 border-blue-500 dark:border-blue-600 rounded-lg bg-gradient-to-br from-blue-50 to-purple-50">
                      <p className="text-sm font-semibold text-blue-900">☀️ Light Mode</p>
                    </div>
                    <div className="flex-1 p-4 border-2 border-purple-500 dark:border-purple-600 rounded-lg bg-gradient-to-br from-gray-900 to-slate-900">
                      <p className="text-sm font-semibold text-purple-100">🌙 Dark Mode</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Danger Zone */}
            <Card className="border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950/30">
              <CardHeader>
                <CardTitle className="text-lg text-red-900 dark:text-red-200">
                  Danger Zone
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  variant="destructive"
                  size="sm"
                  className="w-full"
                  onClick={handleResetStats}
                >
                  <RotateCcw className="mr-2" size={16} />
                  Reset Semua Statistik
                </Button>

                <p className="text-xs text-red-800 dark:text-red-200">
                  ⚠️ Tindakan ini tidak dapat dibatalkan!
                </p>
              </CardContent>
            </Card>

            {/* Info */}
            <Card className="bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
              <CardContent className="p-4">
                <h4 className="font-bold text-blue-900 dark:text-blue-200 mb-2">
                  ℹ️ Tentang OptiFokus
                </h4>
                <p className="text-xs text-blue-800 dark:text-blue-300 mb-2">
                  Versi: 1.0.0
                </p>
                <p className="text-xs text-blue-800 dark:text-blue-300">
                  Aplikasi anti-distraksi untuk membantu mahasiswa dan pelajar 
                  fokus belajar dengan sistem gamifikasi dan quiz contextual.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Add Custom App Dialog */}
      <Dialog open={showAddApp} onOpenChange={setShowAddApp}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Tambah Aplikasi Custom</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label className="mb-2 block">Nama Aplikasi</Label>
              <Input
                placeholder="Contoh: Netflix, Spotify, dll"
                value={newAppName}
                onChange={(e) => setNewAppName(e.target.value)}
              />
            </div>

            <div>
              <Label className="mb-2 block">Pilih Icon</Label>
              <div className="grid grid-cols-6 gap-2">
                {emojiOptions.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => setNewAppIcon(emoji)}
                    className={`p-3 text-2xl rounded-lg border-2 transition-all ${
                      newAppIcon === emoji
                        ? "border-blue-500 bg-blue-50 dark:bg-blue-950/30 scale-110"
                        : "border-gray-200 dark:border-gray-700 hover:border-blue-300"
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={handleAddCustomApp} className="flex-1">
                Tambahkan
              </Button>
              <Button variant="outline" onClick={() => setShowAddApp(false)}>
                Batal
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}