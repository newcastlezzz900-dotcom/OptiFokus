import { useState } from "react";
import { useNavigate } from "react-router";
import { AppLayout } from "@/app/components/AppLayout";
import { AdaptiveQuiz } from "@/app/components/AdaptiveQuiz";
import { LossAversionWarning } from "@/app/components/LossAversionWarning";
import { SilentSocialPressure } from "@/app/components/SilentSocialPressure";
import { Card, CardContent } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/app/components/ui/tabs";
import {
  AlertTriangle,
  Lock,
  Brain,
  Users,
  TrendingDown,
  ArrowLeft,
  ShieldAlert,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { getUserStats, updateUserStats } from "@/app/lib/store";

type UnlockStage = "warning" | "socialPressure" | "quiz" | "unlocked";

export function EmergencyUnlock() {
  const navigate = useNavigate();
  const [stage, setStage] = useState<UnlockStage>("warning");
  const [acceptedWarning, setAcceptedWarning] = useState(false);

  const handleAcceptWarning = () => {
    setAcceptedWarning(true);
    setStage("socialPressure");
  };

  const handleProceedToQuiz = () => {
    setStage("quiz");
  };

  const handleQuizSuccess = () => {
    // Apply penalties
    const stats = getUserStats();
    updateUserStats({
      points: Math.max(0, stats.points - 50),
      streak: 0, // Reset streak
      distractionsBlocked: stats.distractionsBlocked,
      totalFocusMinutes: stats.totalFocusMinutes,
      meetings: stats.meetings,
      lastActiveDate: new Date().toISOString().split("T")[0],
    });

    setStage("unlocked");
    toast.success("Aplikasi dibuka. Streak dan poin telah dikurangi.");
    
    // Redirect after 3 seconds
    setTimeout(() => {
      navigate("/");
    }, 3000);
  };

  const handleQuizFail = () => {
    toast.error("Quiz gagal! Kamu harus menjawab 70% benar untuk unlock.");
    setTimeout(() => {
      setStage("warning");
      setAcceptedWarning(false);
    }, 2000);
  };

  const handleGoBack = () => {
    navigate(-1);
  };

  return (
    <AppLayout showChat={false}>
      {/* Dramatic Background */}
      <div className="fixed inset-0 -z-10 bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 dark:from-gray-950 dark:via-red-950/20 dark:to-orange-950/20" />
      <div className="fixed inset-0 -z-10 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5Q0EzQUYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDEzNGgxMnYxMkgzNnptMjQtMjRoMTJ2MTJINjB6bS0yNCAwaDEydjEySDM2em0wLTI0aDEydjEySDM2em0tMjQgMGgxMnYxMkgxMnptMC0yNGgxMnYxMkgxMnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 relative">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <Button
            onClick={handleGoBack}
            variant="ghost"
            className="mb-4"
          >
            <ArrowLeft size={18} className="mr-2" />
            Kembali Fokus
          </Button>

          <div className="flex items-center gap-4 mb-2">
            <div className="p-4 bg-red-500 rounded-full animate-pulse">
              <ShieldAlert size={32} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-red-900 dark:text-red-200">
                Emergency Unlock
              </h1>
              <p className="text-red-700 dark:text-red-300">
                Buka aplikasi yang diblokir dengan konsekuensi berat
              </p>
            </div>
          </div>
        </motion.div>

        {/* Progress Indicator */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            {[
              { key: "warning", icon: AlertTriangle, label: "Peringatan" },
              { key: "socialPressure", icon: Users, label: "Komunitas" },
              { key: "quiz", icon: Brain, label: "Quiz" },
              { key: "unlocked", icon: Lock, label: "Unlock" },
            ].map((item, index) => {
              const Icon = item.icon;
              const isActive = 
                (stage === "warning" && index === 0) ||
                (stage === "socialPressure" && index === 1) ||
                (stage === "quiz" && index === 2) ||
                (stage === "unlocked" && index === 3);
              const isCompleted = 
                (stage === "socialPressure" && index < 1) ||
                (stage === "quiz" && index < 2) ||
                (stage === "unlocked" && index < 3);

              return (
                <div key={item.key} className="flex flex-col items-center flex-1">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                    isActive
                      ? "bg-red-500 border-red-600 text-white scale-110"
                      : isCompleted
                      ? "bg-green-500 border-green-600 text-white"
                      : "bg-gray-200 dark:bg-gray-700 border-gray-300 dark:border-gray-600 text-gray-500"
                  }`}>
                    <Icon size={18} />
                  </div>
                  <span className={`text-xs mt-1 ${
                    isActive ? "font-bold text-red-900 dark:text-red-200" : "text-gray-500"
                  }`}>
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <motion.div
              className="absolute inset-y-0 left-0 bg-gradient-to-r from-red-500 to-orange-500"
              initial={{ width: "0%" }}
              animate={{
                width:
                  stage === "warning" ? "25%" :
                  stage === "socialPressure" ? "50%" :
                  stage === "quiz" ? "75%" :
                  "100%"
              }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        {/* Content Stages */}
        <AnimatePresence mode="wait">
          {stage === "warning" && (
            <motion.div
              key="warning"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-6"
            >
              <LossAversionWarning />

              <div className="flex gap-4">
                <Button
                  onClick={handleGoBack}
                  variant="outline"
                  className="flex-1 h-14 border-2 border-green-500 text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-950/30"
                >
                  ✓ Tetap Fokus (Rekomendasi)
                </Button>
                <Button
                  onClick={handleAcceptWarning}
                  variant="destructive"
                  className="flex-1 h-14 bg-gradient-to-r from-red-600 to-orange-600"
                >
                  Tetap Lanjut Unlock
                </Button>
              </div>
            </motion.div>
          )}

          {stage === "socialPressure" && (
            <motion.div
              key="socialPressure"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-6"
            >
              <SilentSocialPressure />

              <div className="flex gap-4">
                <Button
                  onClick={handleGoBack}
                  variant="outline"
                  className="flex-1 h-14 border-2 border-green-500 text-green-700 dark:text-green-300"
                >
                  Kembali Fokus
                </Button>
                <Button
                  onClick={handleProceedToQuiz}
                  variant="destructive"
                  className="flex-1 h-14 bg-gradient-to-r from-red-600 to-orange-600"
                >
                  Lanjut ke Quiz
                </Button>
              </div>
            </motion.div>
          )}

          {stage === "quiz" && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
            >
              <Card className="dark:bg-gray-900 dark:border-gray-800">
                <CardContent className="p-6">
                  <div className="mb-6 p-4 bg-purple-50 dark:bg-purple-950/30 rounded-lg border-2 border-purple-200 dark:border-purple-800">
                    <h3 className="font-bold text-purple-900 dark:text-purple-200 mb-2 flex items-center gap-2">
                      <Brain size={20} />
                      Adaptive Micro-Learning Quiz
                    </h3>
                    <p className="text-sm text-purple-800 dark:text-purple-300">
                      Jawab 5 pertanyaan dengan benar (minimal 70%) untuk unlock. 
                      Tingkat kesulitan akan menyesuaikan dengan kemampuanmu.
                    </p>
                  </div>

                  <AdaptiveQuiz
                    onSuccess={handleQuizSuccess}
                    onFail={handleQuizFail}
                    totalQuestions={5}
                  />
                </CardContent>
              </Card>
            </motion.div>
          )}

          {stage === "unlocked" && (
            <motion.div
              key="unlocked"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <Card className="border-4 border-orange-500 bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/30 dark:to-red-950/30">
                <CardContent className="p-12 text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1, rotate: 360 }}
                    transition={{ type: "spring", duration: 1 }}
                    className="text-8xl mb-6"
                  >
                    🔓
                  </motion.div>

                  <h2 className="text-3xl font-bold text-orange-900 dark:text-orange-200 mb-4">
                    Aplikasi Dibuka
                  </h2>
                  
                  <div className="space-y-3 mb-6 text-orange-800 dark:text-orange-300">
                    <p className="text-lg">Konsekuensi yang kamu terima:</p>
                    <div className="p-4 bg-red-100 dark:bg-red-900/30 rounded-lg">
                      <p className="font-bold text-red-900 dark:text-red-200">
                        ❌ Streak direset ke 0 hari
                      </p>
                      <p className="font-bold text-red-900 dark:text-red-200">
                        ❌ Poin dikurangi 50
                      </p>
                      <p className="font-bold text-red-900 dark:text-red-200">
                        ❌ Ranking turun
                      </p>
                    </div>
                  </div>

                  <p className="text-sm text-orange-700 dark:text-orange-400">
                    Kembali ke dashboard dalam 3 detik...
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Help Text */}
        {stage !== "unlocked" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-6"
          >
            <Card className="bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
              <CardContent className="p-4">
                <p className="text-sm text-blue-900 dark:text-blue-200">
                  💡 <strong>Tips:</strong> Jika ini bukan darurat yang sebenarnya, 
                  lebih baik kembali fokus. Kamu akan mendapatkan bonus poin untuk konsistensi!
                </p>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </AppLayout>
  );
}
