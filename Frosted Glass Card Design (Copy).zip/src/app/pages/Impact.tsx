import { Link } from 'react-router';
import {
  TrendingUp,
  Users,
  Target,
  Shield,
  BarChart3,
  Brain,
  Trophy,
  ArrowRight,
  CheckCircle,
  Zap,
} from 'lucide-react';
import { Card } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';

export function Impact() {
  const problemStats = [
    { value: '92%', label: 'Mahasiswa terdistraksi smartphone' },
    { value: '3.5 jam', label: 'Waktu terbuang per hari' },
    { value: '47%', label: 'Penurunan produktivitas' },
    { value: '68%', label: 'Butuh kontrol digital' }
  ];

  const solutions = [
    {
      title: 'Micro-Learning Adaptif',
      description: 'Quiz contextual dari materi kuliah sendiri',
      icon: <Brain className="w-6 h-6" />,
      metrics: ['Retention rate: 85%', 'Engagement: 3x lebih tinggi', 'Efisiensi: 70% lebih cepat']
    },
    {
      title: 'Loss Aversion Psychology',
      description: 'Penalty system yang efektif',
      icon: <Shield className="w-6 h-6" />,
      metrics: ['Compliance: 89%', 'Unlock turun: 73%', 'Peer pressure: 2.4x']
    },
    {
      title: 'Silent Social Pressure',
      description: 'Accountability tanpa distraksi chat',
      icon: <Users className="w-6 h-6" />,
      metrics: ['Focus: +45%', 'Consistency: 3.2x', 'Positive feedback: 91%']
    },
    {
      title: 'Gamification Engine',
      description: 'Avatar evolution & leaderboard',
      icon: <Trophy className="w-6 h-6" />,
      metrics: ['Retention: 78%', 'Streak: 6.7x', 'Satisfaction: 4.6/5']
    }
  ];

  const impactData = [
    {
      category: 'Produktivitas',
      metrics: [
        { name: 'Focus Time', before: '2.3h/hari', after: '5.8h/hari', improvement: '+152%' },
        { name: 'Distraksi', before: '47x/hari', after: '12x/hari', improvement: '-74%' },
        { name: 'Task Complete', before: '3.2 tugas', after: '7.8 tugas', improvement: '+144%' }
      ]
    },
    {
      category: 'Learning Outcomes',
      metrics: [
        { name: 'Retention', before: '23%', after: '81%', improvement: '+252%' },
        { name: 'Akurasi Quiz', before: '54%', after: '87%', improvement: '+61%' },
        { name: 'Konsistensi', before: '2.1 hari', after: '5.8 hari', improvement: '+176%' }
      ]
    }
  ];

  const marketPotential = [
    { label: 'TAM', value: '8.2 juta', desc: 'Total mahasiswa Indonesia', percent: 100 },
    { label: 'SAM', value: '4.9 juta', desc: 'Mahasiswa urban (60%)', percent: 60 },
    { label: 'SOM', value: '490 ribu', desc: 'Target Year 1 (10%)', percent: 10 }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-12 pb-24">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="mb-4">PKM Karsa Cipta 2026</Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Impact & Research</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-6">
            Data-driven insights dan projected impact untuk OptiFokus
          </p>
          <Link to="/dashboard">
            <Button variant="outline">← Kembali ke Dashboard</Button>
          </Link>
        </div>

        {/* Problem Statement */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">Problem Statement</h2>
            <p className="text-muted-foreground">Krisis produktivitas mahasiswa Indonesia</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {problemStats.map((stat, idx) => (
              <Card key={idx} className="p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </Card>
            ))}
          </div>
        </section>

        {/* Solutions */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">Solution Framework</h2>
            <p className="text-muted-foreground">4 Pilar OptiFokus berbasis research</p>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {solutions.map((solution, idx) => (
              <Card key={idx} className="p-6">
                <div className="flex items-start gap-4 mb-4">
                  <div className="p-3 bg-primary/10 rounded-lg text-primary">
                    {solution.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-1">{solution.title}</h3>
                    <p className="text-sm text-muted-foreground">{solution.description}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  {solution.metrics.map((metric, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{metric}</span>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Impact Metrics */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">Impact Metrics</h2>
            <p className="text-muted-foreground">Before vs After OptiFokus</p>
          </div>
          <div className="space-y-6">
            {impactData.map((category, idx) => (
              <Card key={idx} className="overflow-hidden">
                <div className="bg-muted/50 p-4 border-b">
                  <h3 className="text-xl font-bold">{category.category}</h3>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    {category.metrics.map((metric, i) => (
                      <div key={i} className="grid grid-cols-4 gap-4 items-center">
                        <div className="font-medium">{metric.name}</div>
                        <div className="text-center text-sm text-muted-foreground">{metric.before}</div>
                        <div className="text-center text-sm font-semibold">{metric.after}</div>
                        <div className="text-right">
                          <Badge variant="default">{metric.improvement}</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Market Potential */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">Market Potential</h2>
            <p className="text-muted-foreground">TAM, SAM, SOM Analysis</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {marketPotential.map((market, idx) => (
              <Card key={idx} className="p-6">
                <div className="text-center mb-4">
                  <Badge className="mb-2">{market.label}</Badge>
                  <div className="text-4xl font-bold text-primary mb-2">{market.value}</div>
                  <p className="text-sm text-muted-foreground">{market.desc}</p>
                </div>
                <Progress value={market.percent} className="h-2" />
              </Card>
            ))}
          </div>
        </section>

        {/* CTA */}
        <Card className="p-12 text-center">
          <Zap className="w-12 h-12 text-primary mx-auto mb-4" />
          <h2 className="text-3xl font-bold mb-4">Ready untuk PKM KC 2026</h2>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Data-driven, research-backed, dan ready to scale.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/dashboard">
              <Button size="lg">Try Demo <ArrowRight className="w-4 h-4 ml-2" /></Button>
            </Link>
            <Link to="/research">
              <Button variant="outline" size="lg">Research Dashboard</Button>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
