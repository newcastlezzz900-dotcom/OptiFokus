import { useState } from "react";
import { Navbar } from "@/app/components/Navbar";
import { BottomNav } from "@/app/components/BottomNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Textarea } from "@/app/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/app/components/ui/avatar";
import { Badge } from "@/app/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/app/components/ui/tabs";
import {
  MessageCircle,
  ThumbsUp,
  MessageSquare,
  Plus,
  Search,
  TrendingUp,
  BookOpen,
  FlaskConical,
  Brain,
  Code,
  Users,
} from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";

interface CommunityPost {
  id: string;
  author: string;
  avatar: string;
  title: string;
  content: string;
  category: string;
  likes: number;
  replies: number;
  timestamp: string;
  isLiked?: boolean;
}

const categories = [
  { id: "matematika", name: "Matematika", icon: Brain, color: "blue" },
  { id: "fisika", name: "Fisika", icon: FlaskConical, color: "purple" },
  { id: "kimia", name: "Kimia", icon: FlaskConical, color: "green" },
  { id: "biologi", name: "Biologi", icon: BookOpen, color: "emerald" },
  { id: "programming", name: "Programming", icon: Code, color: "orange" },
  { id: "bahasa", name: "Bahasa", icon: MessageCircle, color: "pink" },
];

const mockPosts: CommunityPost[] = [
  {
    id: "1",
    author: "Ahmad Ridwan",
    avatar: "AR",
    title: "Cara mudah memahami turunan fungsi trigonometri?",
    content: "Halo teman-teman, ada yang bisa kasih tips belajar turunan fungsi trigonometri? Aku masih bingung dengan konsepnya...",
    category: "matematika",
    likes: 24,
    replies: 8,
    timestamp: "2 jam yang lalu",
  },
  {
    id: "2",
    author: "Siti Nurhaliza",
    avatar: "SN",
    title: "Rekomendasi buku fisika kuantum untuk pemula",
    content: "Mau belajar fisika kuantum dari dasar, ada rekomendasi buku yang bagus dan mudah dipahami?",
    category: "fisika",
    likes: 18,
    replies: 12,
    timestamp: "5 jam yang lalu",
  },
  {
    id: "3",
    author: "Budi Santoso",
    avatar: "BS",
    title: "Tips belajar React hooks untuk project skripsi",
    content: "Lagi butuh bantuan untuk memahami React hooks, terutama useEffect dan useContext. Ada yang bisa explain dengan cara sederhana?",
    category: "programming",
    likes: 45,
    replies: 23,
    timestamp: "1 hari yang lalu",
  },
];

export function Community() {
  const [posts, setPosts] = useState<CommunityPost[]>(mockPosts);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewPost, setShowNewPost] = useState(false);
  const [newPostTitle, setNewPostTitle] = useState("");
  const [newPostContent, setNewPostContent] = useState("");
  const [newPostCategory, setNewPostCategory] = useState("matematika");

  const filteredPosts = posts.filter((post) => {
    const matchesCategory = selectedCategory === "all" || post.category === selectedCategory;
    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleLike = (postId: string) => {
    setPosts(
      posts.map((post) =>
        post.id === postId
          ? { ...post, likes: post.isLiked ? post.likes - 1 : post.likes + 1, isLiked: !post.isLiked }
          : post
      )
    );
  };

  const handleCreatePost = () => {
    if (!newPostTitle.trim() || !newPostContent.trim()) {
      toast.error("Judul dan konten harus diisi!");
      return;
    }

    const newPost: CommunityPost = {
      id: Date.now().toString(),
      author: "Kamu",
      avatar: "😊",
      title: newPostTitle,
      content: newPostContent,
      category: newPostCategory,
      likes: 0,
      replies: 0,
      timestamp: "Baru saja",
    };

    setPosts([newPost, ...posts]);
    setNewPostTitle("");
    setNewPostContent("");
    setShowNewPost(false);
    toast.success("Post berhasil dibuat! 🎉");
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-20 md:pb-0">
      {/* Beautiful Background */}
      <div className="fixed inset-0 -z-10 bg-gradient-to-br from-rose-50 via-pink-50 to-fuchsia-50 dark:from-gray-950 dark:via-rose-950/20 dark:to-fuchsia-950/20" />
      <div className="fixed inset-0 -z-10 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5Q0EzQUYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDEzNGgxMnYxMkgzNnptMjQtMjRoMTJ2MTJINjB6bS0yNCAwaDEydjEySDM2em0wLTI0aDEydjEySDM2em0tMjQgMGgxMnYxMkgxMnptMC0yNGgxMnYxMkgxMnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-40 dark:opacity-20" />
      
      <Navbar />
      <BottomNav />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 relative">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <Users className="text-blue-600" />
                Community
              </h1>
              <p className="text-gray-600 dark:text-gray-400 text-sm sm:text-base">
                Tanya jawab dan diskusi dengan sesama pelajar
              </p>
            </div>
            <Button
              onClick={() => setShowNewPost(!showNewPost)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 w-full sm:w-auto"
            >
              <Plus className="mr-2" size={18} />
              Buat Post Baru
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <Input
              placeholder="Cari pertanyaan atau topik..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </motion.div>

        {/* New Post Form */}
        {showNewPost && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-6"
          >
            <Card className="dark:bg-gray-900 dark:border-gray-800">
              <CardHeader>
                <CardTitle>Buat Post Baru</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Kategori</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {categories.map((cat) => {
                      const Icon = cat.icon;
                      return (
                        <Button
                          key={cat.id}
                          variant={newPostCategory === cat.id ? "default" : "outline"}
                          size="sm"
                          onClick={() => setNewPostCategory(cat.id)}
                          className="justify-start"
                        >
                          <Icon size={14} className="mr-1" />
                          {cat.name}
                        </Button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Judul</label>
                  <Input
                    placeholder="Tulis judul pertanyaan atau diskusi..."
                    value={newPostTitle}
                    onChange={(e) => setNewPostTitle(e.target.value)}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Konten</label>
                  <Textarea
                    placeholder="Jelaskan pertanyaan atau topik diskusi kamu..."
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    rows={4}
                  />
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleCreatePost} className="flex-1">
                    Posting
                  </Button>
                  <Button variant="outline" onClick={() => setShowNewPost(false)}>
                    Batal
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Categories Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-20 dark:bg-gray-900 dark:border-gray-800">
              <CardHeader>
                <CardTitle className="text-lg">Kategori</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant={selectedCategory === "all" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setSelectedCategory("all")}
                >
                  <TrendingUp size={16} className="mr-2" />
                  Semua Topik
                </Button>

                {categories.map((cat) => {
                  const Icon = cat.icon;
                  return (
                    <Button
                      key={cat.id}
                      variant={selectedCategory === cat.id ? "default" : "ghost"}
                      className="w-full justify-start"
                      onClick={() => setSelectedCategory(cat.id)}
                    >
                      <Icon size={16} className="mr-2" />
                      {cat.name}
                    </Button>
                  );
                })}
              </CardContent>
            </Card>
          </div>

          {/* Posts */}
          <div className="lg:col-span-3 space-y-4">
            {filteredPosts.length === 0 ? (
              <Card className="dark:bg-gray-900 dark:border-gray-800">
                <CardContent className="p-12 text-center">
                  <MessageCircle className="mx-auto text-gray-400 mb-4" size={48} />
                  <p className="text-gray-600 dark:text-gray-400">
                    Belum ada post di kategori ini
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredPosts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="hover:shadow-lg transition-shadow dark:bg-gray-900 dark:border-gray-800 cursor-pointer">
                    <CardContent className="p-4 sm:p-6">
                      <div className="flex items-start gap-3 sm:gap-4">
                        <Avatar className="w-10 h-10 sm:w-12 sm:h-12">
                          <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                            {post.avatar}
                          </AvatarFallback>
                        </Avatar>

                        <div className="flex-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2 mb-2">
                            <p className="font-semibold text-gray-900 dark:text-white text-sm sm:text-base">
                              {post.author}
                            </p>
                            <Badge variant="secondary" className="text-xs">
                              {categories.find((c) => c.id === post.category)?.name}
                            </Badge>
                            <span className="text-xs text-gray-500 dark:text-gray-400">
                              {post.timestamp}
                            </span>
                          </div>

                          <h3 className="font-bold text-base sm:text-lg text-gray-900 dark:text-white mb-2">
                            {post.title}
                          </h3>

                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">
                            {post.content}
                          </p>

                          <div className="flex items-center gap-4">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleLike(post.id);
                              }}
                              className={post.isLiked ? "text-blue-600" : ""}
                            >
                              <ThumbsUp size={16} className="mr-1" fill={post.isLiked ? "currentColor" : "none"} />
                              {post.likes}
                            </Button>

                            <Button size="sm" variant="ghost">
                              <MessageSquare size={16} className="mr-1" />
                              {post.replies} Balasan
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}