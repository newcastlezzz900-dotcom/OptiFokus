import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { Navbar } from "@/app/components/Navbar";
import { BottomNav } from "@/app/components/BottomNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Badge } from "@/app/components/ui/badge";
import { Progress } from "@/app/components/ui/progress";
import { getMateri, Materi } from "@/app/lib/store";
import {
  BookOpen,
  ArrowLeft,
  FileText,
  Download,
  Share2,
  Bookmark,
  Eye,
  Clock,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Printer,
} from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";

export function MateriViewer() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const materiId = searchParams.get("id");
  
  const [materi, setMateri] = useState<Materi | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages] = useState(10); // Mock total pages
  const [zoom, setZoom] = useState(100);
  const [readingTime, setReadingTime] = useState(0);
  const [isBookmarked, setIsBookmarked] = useState(false);

  useEffect(() => {
    if (materiId) {
      const allMateri = getMateri();
      const found = allMateri.find(m => m.id === materiId);
      if (found) {
        setMateri(found);
      }
    }
  }, [materiId]);

  useEffect(() => {
    // Track reading time
    const interval = setInterval(() => {
      setReadingTime(prev => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleDownload = () => {
    toast.success("Materi berhasil didownload!", {
      description: `${materi?.name}.pdf`,
    });
  };

  const handleShare = () => {
    toast.success("Link berhasil disalin!", {
      description: "Bagikan ke teman kamu",
    });
  };

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
    toast.success(isBookmarked ? "Bookmark dihapus" : "Materi dibookmark!");
  };

  if (!materi) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <Card className="p-8">
            <FileText className="w-16 h-16 mx-auto mb-4 text-blue-500" />
            <h2 className="text-2xl font-bold mb-2 text-slate-800 dark:text-white">
              Materi tidak ditemukan
            </h2>
            <Button
              onClick={() => navigate("/upload")}
              className="mt-4 bg-gradient-to-r from-blue-500 to-blue-600"
            >
              <ArrowLeft className="mr-2" size={18} />
              Kembali ke Materi
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950 pb-20 md:pb-0">
      <Navbar />
      <BottomNav />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Header */}
        <motion.div
          className="mb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-between flex-wrap gap-4 mb-4">
            <Button
              onClick={() => navigate("/upload")}
              variant="outline"
              className="border-blue-300 dark:border-blue-700"
            >
              <ArrowLeft className="mr-2" size={18} />
              Kembali
            </Button>

            <div className="flex items-center gap-2">
              <Badge className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-2">
                <Clock className="w-4 h-4 mr-2 inline" />
                {formatTime(readingTime)}
              </Badge>
              <Badge className="bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-2">
                <Eye className="w-4 h-4 mr-2 inline" />
                Halaman {currentPage}/{totalPages}
              </Badge>
            </div>
          </div>

          <div className="flex items-start justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent mb-2">
                {materi.name}
              </h1>
              <p className="text-lg text-slate-600 dark:text-slate-300">
                {materi.description}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Button
                onClick={handleBookmark}
                variant="outline"
                size="sm"
                className={isBookmarked ? "border-yellow-500 text-yellow-600" : ""}
              >
                <Bookmark className="w-4 h-4" fill={isBookmarked ? "currentColor" : "none"} />
              </Button>
              <Button
                onClick={handleShare}
                variant="outline"
                size="sm"
              >
                <Share2 className="w-4 h-4" />
              </Button>
              <Button
                onClick={handleDownload}
                variant="outline"
                size="sm"
              >
                <Download className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Main Content - Materi Reader */}
          <motion.div
            className="lg:col-span-3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="shadow-2xl border-2 border-blue-200 dark:border-blue-900">
              <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                      <BookOpen size={24} />
                    </div>
                    <span>Konten Materi</span>
                  </div>
                  
                  {/* Zoom Controls */}
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-white hover:bg-white/20"
                      onClick={() => setZoom(Math.max(50, zoom - 10))}
                    >
                      <ZoomOut size={18} />
                    </Button>
                    <span className="text-sm">{zoom}%</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-white hover:bg-white/20"
                      onClick={() => setZoom(Math.min(200, zoom + 10))}
                    >
                      <ZoomIn size={18} />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-white hover:bg-white/20"
                      onClick={() => toast.success("Print dialog dibuka")}
                    >
                      <Printer size={18} />
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              
              <CardContent className="p-8" style={{ fontSize: `${zoom}%` }}>
                {/* Mock Content - Replace with actual PDF viewer or content */}
                <div className="prose dark:prose-invert max-w-none">
                  <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">
                    Bab 1: Pendahuluan
                  </h2>
                  
                  <p className="text-slate-700 dark:text-slate-300 mb-4 leading-relaxed">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor 
                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud 
                    exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                  </p>

                  <h3 className="text-xl font-semibold text-slate-800 dark:text-white mb-3 mt-6">
                    1.1 Definisi
                  </h3>
                  
                  <p className="text-slate-700 dark:text-slate-300 mb-4 leading-relaxed">
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu 
                    fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in 
                    culpa qui officia deserunt mollit anim id est laborum.
                  </p>

                  <div className="bg-blue-50 dark:bg-blue-950/30 p-6 rounded-xl border-2 border-blue-200 dark:border-blue-800 my-6">
                    <h4 className="font-bold text-blue-800 dark:text-blue-200 mb-2 flex items-center gap-2">
                      💡 Catatan Penting
                    </h4>
                    <p className="text-blue-700 dark:text-blue-300">
                      Konsep ini sangat penting untuk memahami materi selanjutnya. Pastikan kamu 
                      memahami definisi dengan baik sebelum melanjutkan.
                    </p>
                  </div>

                  <h3 className="text-xl font-semibold text-slate-800 dark:text-white mb-3 mt-6">
                    1.2 Konsep Dasar
                  </h3>
                  
                  <ul className="list-disc list-inside text-slate-700 dark:text-slate-300 space-y-2 mb-4">
                    <li>Konsep pertama yang harus dipahami</li>
                    <li>Konsep kedua yang menjadi fondasi</li>
                    <li>Konsep ketiga yang melengkapi pemahaman</li>
                    <li>Konsep keempat untuk aplikasi praktis</li>
                  </ul>

                  <p className="text-slate-700 dark:text-slate-300 mb-4 leading-relaxed">
                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque 
                    laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi 
                    architecto beatae vitae dicta sunt explicabo.
                  </p>

                  <div className="bg-green-50 dark:bg-green-950/30 p-6 rounded-xl border-2 border-green-200 dark:border-green-800 my-6">
                    <h4 className="font-bold text-green-800 dark:text-green-200 mb-2 flex items-center gap-2">
                      ✅ Contoh Soal
                    </h4>
                    <p className="text-green-700 dark:text-green-300 mb-3">
                      Jika A = 5 dan B = 10, maka berapakah nilai dari C = A + B?
                    </p>
                    <p className="text-green-800 dark:text-green-200 font-semibold">
                      Jawaban: C = 15
                    </p>
                  </div>

                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                    Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia 
                    consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
                  </p>
                </div>
              </CardContent>

              {/* Pagination */}
              <div className="border-t-2 border-blue-200 dark:border-blue-900 p-4">
                <div className="flex items-center justify-between">
                  <Button
                    onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                    variant="outline"
                    className="border-blue-300 dark:border-blue-700"
                  >
                    <ChevronLeft className="mr-2" size={18} />
                    Sebelumnya
                  </Button>

                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600 dark:text-slate-400">
                      Halaman
                    </span>
                    <input
                      type="number"
                      value={currentPage}
                      onChange={(e) => {
                        const page = parseInt(e.target.value);
                        if (page >= 1 && page <= totalPages) {
                          setCurrentPage(page);
                        }
                      }}
                      className="w-16 px-2 py-1 text-center border-2 border-blue-300 dark:border-blue-700 rounded-lg bg-white dark:bg-slate-900"
                      min={1}
                      max={totalPages}
                    />
                    <span className="text-sm text-slate-600 dark:text-slate-400">
                      dari {totalPages}
                    </span>
                  </div>

                  <Button
                    onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage === totalPages}
                    variant="outline"
                    className="border-blue-300 dark:border-blue-700"
                  >
                    Selanjutnya
                    <ChevronRight className="ml-2" size={18} />
                  </Button>
                </div>

                <div className="mt-4">
                  <Progress value={(currentPage / totalPages) * 100} className="h-2" />
                  <p className="text-xs text-center text-slate-500 dark:text-slate-400 mt-2">
                    Progress: {((currentPage / totalPages) * 100).toFixed(0)}% selesai
                  </p>
                </div>
              </div>
            </Card>
          </motion.div>

          {/* Sidebar - Quick Info */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            {/* Reading Stats */}
            <Card className="shadow-xl border-2 border-green-200 dark:border-green-900">
              <CardHeader className="bg-gradient-to-r from-green-500 to-emerald-500 text-white">
                <CardTitle className="text-lg">Statistik Baca</CardTitle>
              </CardHeader>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600 dark:text-slate-400">Waktu Baca</span>
                  <span className="font-bold text-green-600 dark:text-green-400">
                    {formatTime(readingTime)}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600 dark:text-slate-400">Progress</span>
                  <span className="font-bold text-blue-600 dark:text-blue-400">
                    {((currentPage / totalPages) * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600 dark:text-slate-400">Quiz Tersedia</span>
                  <span className="font-bold text-purple-600 dark:text-purple-400">
                    {materi.quizCount}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-xl border-2 border-purple-200 dark:border-purple-900">
              <CardHeader className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="p-4 space-y-2">
                <Button
                  onClick={() => navigate("/quiz")}
                  className="w-full bg-gradient-to-r from-purple-500 to-purple-600"
                >
                  Latihan Quiz
                </Button>
                <Button
                  onClick={handleDownload}
                  variant="outline"
                  className="w-full border-blue-300 dark:border-blue-700"
                >
                  <Download className="mr-2" size={16} />
                  Download PDF
                </Button>
                <Button
                  onClick={() => navigate("/focus")}
                  variant="outline"
                  className="w-full border-green-300 dark:border-green-700"
                >
                  Mulai Fokus
                </Button>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card className="shadow-xl border-2 border-orange-200 dark:border-orange-900">
              <CardContent className="p-4">
                <h4 className="font-bold text-orange-800 dark:text-orange-200 mb-3 flex items-center gap-2">
                  💡 Tips Belajar Efektif
                </h4>
                <ul className="space-y-2 text-sm text-orange-700 dark:text-orange-300">
                  <li>✅ Baca dengan fokus, hindari distraksi</li>
                  <li>✅ Catat poin-poin penting</li>
                  <li>✅ Uji pemahaman dengan quiz</li>
                  <li>✅ Review berkala untuk retention</li>
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
