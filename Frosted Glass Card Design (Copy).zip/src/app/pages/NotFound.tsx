import { Link } from "react-router";
import { Home, AlertCircle, ArrowLeft } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { motion } from "motion/react";

export function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="max-w-lg w-full p-8 sm:p-12 text-center shadow-2xl border-2 border-slate-200 dark:border-slate-800">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          >
            <div className="relative inline-block mb-6">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-slate-500/20 rounded-full blur-2xl" />
              <AlertCircle className="w-20 h-20 sm:w-24 sm:h-24 text-slate-400 dark:text-slate-600 relative" strokeWidth={1.5} />
            </div>
          </motion.div>
          
          <motion.h1
            className="text-7xl sm:text-8xl font-bold bg-gradient-to-br from-slate-700 to-slate-900 dark:from-slate-300 dark:to-slate-500 bg-clip-text text-transparent mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            404
          </motion.h1>
          
          <motion.h2
            className="text-xl sm:text-2xl font-semibold text-slate-800 dark:text-slate-200 mb-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Halaman Tidak Ditemukan
          </motion.h2>
          
          <motion.p
            className="text-slate-600 dark:text-slate-400 mb-8 text-sm sm:text-base"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            Maaf, halaman yang Anda cari tidak ada atau sudah dipindahkan.
            <br />
            <span className="text-xs text-slate-500 dark:text-slate-500 mt-2 block">
              Silakan kembali ke dashboard untuk melanjutkan.
            </span>
          </motion.p>
          
          <motion.div
            className="flex flex-col sm:flex-row gap-3 justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            <Link to="/dashboard" className="flex-1 sm:flex-initial">
              <Button className="w-full bg-gradient-to-r from-slate-700 to-slate-900 hover:from-slate-800 hover:to-slate-950 dark:from-slate-700 dark:to-slate-900">
                <Home className="w-4 h-4 mr-2" />
                Kembali ke Dashboard
              </Button>
            </Link>
            <Link to="/" className="flex-1 sm:flex-initial">
              <Button variant="outline" className="w-full border-slate-300 dark:border-slate-700">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Ke Beranda
              </Button>
            </Link>
          </motion.div>
        </Card>
      </motion.div>
    </div>
  );
}