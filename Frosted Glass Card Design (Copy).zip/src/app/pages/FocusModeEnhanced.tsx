import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router";
import { AppLayout } from "@/app/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Label } from "@/app/components/ui/label";
import { Progress } from "@/app/components/ui/progress";
import { Badge } from "@/app/components/ui/badge";
import { Input } from "@/app/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import {
  getUserStats,
  updateUserStats,
  addFocusSession,
  incrementStreak,
  addMeeting,
  getBlockedApps,
} from "@/app/lib/store";
import {
  logQuizAttempt,
  logDistractionEvent,
  updateLearningProgress,
  getAdaptiveDifficulty,
  logAuditEvent,
} from "@/app/lib/research-store";
import {
  Play,
  Pause,
  RotateCcw,
  Clock,
  CheckCircle2,
  Shield,
  Flame,
  Trophy,
  Target,
  AlertTriangle,
  Lock,
  Instagram,
  Facebook,
  Twitter,
  Youtube,
  X,
  Smartphone,
  Brain,
  Timer,
  Award,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

// Mock quiz questions
const mockQuizQuestions = [
  {
    id: 1,
    question: "Berapa hasil dari integral ∫x² dx?",
    options: ["x³/3 + C", "2x + C", "x³ + C", "x²/2 + C"],
    correct: 0,
    subject: "Kalkulus I",
  },
  {
    id: 2,
    question: "Apa turunan dari fungsi f(x) = 3x³?",
    options: ["3x²", "9x²", "x³", "6x²"],
    correct: 1,
    subject: "Kalkulus I",
  },
  {
    id: 3,
    question: "Limit dari (sin x)/x saat x → 0 adalah?",
    options: ["0", "1", "∞", "Tidak ada"],
    correct: 1,
    subject: "Kalkulus I",
  },
  {
    id: 4,
    question: "Berapa nilai dari log₂ 8?",
    options: ["2", "3", "4", "8"],
    correct: 1,
    subject: "Matematika",
  },
  {
    id: 5,
    question: "Apa itu fungsi bijektif?",
    options: [
      "Fungsi yang injektif dan surjektif",
      "Fungsi yang hanya injektif",
      "Fungsi yang hanya surjektif",
      "Fungsi yang tidak keduanya",
    ],
    correct: 0,
    subject: "Matematika Diskrit",
  },
];

const blockedAppIcons = {
  Instagram: Instagram,
  Facebook: Facebook,
  Twitter: Twitter,
  YouTube: Youtube,
  TikTok: Smartphone,
  WhatsApp: Smartphone,
  Telegram: Smartphone,
  Games: Smartphone,
};

export function FocusModeEnhanced() {
  const navigate = useNavigate();
  const [duration, setDuration] = useState(25);
  const [timeLeft, setTimeLeft] = useState(duration * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState<"focus" | "break">("focus");
  const [sessions, setSessions] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Custom Duration States
  const [isCustomDuration, setIsCustomDuration] = useState(false);
  const [customHours, setCustomHours] = useState(0);
  const [customMinutes, setCustomMinutes] = useState(25);
  const [customSeconds, setCustomSeconds] = useState(0);

  // Blocker Modal States
  const [showBlockerModal, setShowBlockerModal] = useState(false);
  const [blockedAppAttempt, setBlockedAppAttempt] = useState("");
  const [quizState, setQuizState] = useState<"blocked" | "loading" | "quiz" | "failed" | "success">("blocked");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [unlockTimeLeft, setUnlockTimeLeft] = useState(120);
  const [quizQuestions, setQuizQuestions] = useState<typeof mockQuizQuestions>([]);
  const [unlockAttempts, setUnlockAttempts] = useState(0);

  const blockedApps = getBlockedApps().filter((app) => app.isBlocked);

  // Handle custom duration change
  const handleDurationChange = (value: string) => {
    if (value === "custom") {
      setIsCustomDuration(true);
      // Calculate total seconds from custom inputs
      const totalSeconds = customHours * 3600 + customMinutes * 60 + customSeconds;
      setTimeLeft(totalSeconds > 0 ? totalSeconds : 1500); // Default 25 menit = 1500 detik
      setDuration(Math.ceil(totalSeconds / 60)); // Save as minutes for compatibility
    } else {
      setIsCustomDuration(false);
      const minutes = parseInt(value);
      setDuration(minutes);
      setTimeLeft(minutes * 60);
    }
  };

  // Update duration when custom inputs change
  const handleCustomInputChange = (hours: number, minutes: number, seconds: number) => {
    const safeHours = isNaN(hours) || hours < 0 ? 0 : Math.min(hours, 12);
    const safeMinutes = isNaN(minutes) || minutes < 0 ? 0 : Math.min(minutes, 59);
    const safeSeconds = isNaN(seconds) || seconds < 0 ? 0 : Math.min(seconds, 59);
    
    setCustomHours(safeHours);
    setCustomMinutes(safeMinutes);
    setCustomSeconds(safeSeconds);
    
    // Calculate total in seconds
    const totalSeconds = safeHours * 3600 + safeMinutes * 60 + safeSeconds;
    if (totalSeconds > 0) {
      setTimeLeft(totalSeconds);
      setDuration(Math.ceil(totalSeconds / 60)); // For compatibility
    }
  };

  useEffect(() => {
    setTimeLeft(duration * 60);
  }, [duration]);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleTimerComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, timeLeft]);

  // Unlock timer countdown
  useEffect(() => {
    if (quizState === "success" && unlockTimeLeft > 0) {
      const timer = setInterval(() => {
        setUnlockTimeLeft((prev) => {
          if (prev <= 1) {
            // Auto lock again
            setShowBlockerModal(false);
            resetQuizState();
            toast.info("Aplikasi terkunci otomatis kembali");
            return 120;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [quizState, unlockTimeLeft]);

  const handleTimerComplete = () => {
    setIsRunning(false);
    
    if (mode === "focus") {
      const stats = getUserStats();
      updateUserStats({
        totalFocusMinutes: stats.totalFocusMinutes + duration,
        points: stats.points + duration * 10,
      });
      
      addFocusSession({
        date: new Date().toISOString().split("T")[0],
        duration: duration,
        type: "focus",
      });

      incrementStreak();
      addMeeting();
      
      setSessions((prev) => prev + 1);
      
      toast.success("Sesi fokus selesai! 🎉", {
        description: `+${duration * 10} poin, streak maintained!`,
      });
      
      setMode("break");
      setTimeLeft(5 * 60);
    } else {
      toast.info("Break time selesai. Ready untuk sesi berikutnya?");
      setMode("focus");
      setTimeLeft(duration * 60);
    }
  };

  const handleStart = () => {
    setIsRunning(true);
    toast.success("Focus mode dimulai! 🎯", {
      description: `${blockedApps.length} aplikasi diblokir`,
    });
  };

  const handlePause = () => {
    setIsRunning(false);
    toast.info("Timer di-pause");
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(duration * 60);
    setMode("focus");
    toast.info("Timer di-reset");
  };

  // Simulate blocked app click
  const handleBlockedAppClick = (appName: string) => {
    if (!isRunning) {
      toast.error("Mulai focus mode terlebih dahulu");
      return;
    }

    setBlockedAppAttempt(appName);
    setShowBlockerModal(true);
    setQuizState("blocked");
    setUnlockAttempts((prev) => prev + 1);
  };

  const handleStartQuiz = () => {
    setQuizState("loading");
    
    // Simulate AI generating quiz (2 seconds)
    setTimeout(() => {
      // Adaptive difficulty: more attempts = more questions
      const numQuestions = Math.min(3 + Math.floor(unlockAttempts / 2), 5);
      const selectedQuestions = mockQuizQuestions
        .sort(() => Math.random() - 0.5)
        .slice(0, numQuestions);
      
      setQuizQuestions(selectedQuestions);
      setQuizState("quiz");
      setCurrentQuestionIndex(0);
      setCorrectAnswers(0);
    }, 2000);
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    
    setTimeout(() => {
      const isCorrect = answerIndex === quizQuestions[currentQuestionIndex].correct;
      
      if (isCorrect) {
        setCorrectAnswers((prev) => prev + 1);
        
        if (currentQuestionIndex < quizQuestions.length - 1) {
          // Next question
          setCurrentQuestionIndex((prev) => prev + 1);
          setSelectedAnswer(null);
        } else {
          // All questions answered correctly
          const stats = getUserStats();
          const earnedPoints = quizQuestions.length * 10;
          updateUserStats({
            points: stats.points + earnedPoints,
          });
          
          setQuizState("success");
          setUnlockTimeLeft(120); // 2 minutes unlock
          toast.success(`+${earnedPoints} poin! 🎉`);
        }
      } else {
        // Wrong answer - PENALTY
        const stats = getUserStats();
        updateUserStats({
          points: Math.max(0, stats.points - 50),
          currentStreak: 0, // Reset streak
        });
        
        setQuizState("failed");
        toast.error("Jawaban salah! Penalty: -50 poin + reset streak");
      }
    }, 1000);
  };

  const resetQuizState = () => {
    setQuizState("blocked");
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setCorrectAnswers(0);
    setQuizQuestions([]);
  };

  const handleCloseModal = () => {
    setShowBlockerModal(false);
    resetQuizState();
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const progress = ((duration * 60 - timeLeft) / (duration * 60)) * 100;

  return (
    <AppLayout>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-purple-950">
        <div className="max-w-6xl mx-auto px-4 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Focus Mode
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Pomodoro Timer + Smart App Blocker
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Timer */}
            <div className="lg:col-span-2">
              <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-2 border-blue-200 dark:border-blue-900">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Clock className="w-6 h-6 text-blue-600" />
                      {mode === "focus" ? "Focus Time" : "Break Time"}
                    </span>
                    <Badge className={mode === "focus" ? "bg-blue-500" : "bg-green-500"}>
                      Sesi #{sessions + 1}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Duration Selector */}
                  {!isRunning && (
                    <div className="space-y-2">
                      <Label>Durasi Fokus</Label>
                      <Select
                        value={isCustomDuration ? "custom" : duration.toString()}
                        onValueChange={handleDurationChange}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="15">15 menit</SelectItem>
                          <SelectItem value="25">25 menit (Pomodoro)</SelectItem>
                          <SelectItem value="50">50 menit</SelectItem>
                          <SelectItem value="custom">Durasi Kustom</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      {isCustomDuration && (
                        <div className="mt-3 space-y-2">
                          <Label className="text-sm text-gray-600 dark:text-gray-400">
                            Atur durasi fokus kustom Anda:
                          </Label>
                          <div className="flex items-center gap-3">
                            <div className="flex-1">
                              <Label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">
                                Jam
                              </Label>
                              <Input
                                type="number"
                                min="0"
                                max="12"
                                value={customHours}
                                onChange={(e) => handleCustomInputChange(parseInt(e.target.value) || 0, customMinutes, customSeconds)}
                                className="w-full text-center text-lg font-bold"
                                placeholder="0"
                              />
                            </div>
                            <span className="text-2xl font-bold text-gray-400 mt-5">:</span>
                            <div className="flex-1">
                              <Label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">
                                Menit
                              </Label>
                              <Input
                                type="number"
                                min="0"
                                max="59"
                                value={customMinutes}
                                onChange={(e) => handleCustomInputChange(customHours, parseInt(e.target.value) || 0, customSeconds)}
                                className="w-full text-center text-lg font-bold"
                                placeholder="0"
                              />
                            </div>
                            <span className="text-2xl font-bold text-gray-400 mt-5">:</span>
                            <div className="flex-1">
                              <Label className="text-xs text-gray-500 dark:text-gray-400 mb-1 block">
                                Detik
                              </Label>
                              <Input
                                type="number"
                                min="0"
                                max="59"
                                value={customSeconds}
                                onChange={(e) => handleCustomInputChange(customHours, customMinutes, parseInt(e.target.value) || 0)}
                                className="w-full text-center text-lg font-bold"
                                placeholder="0"
                              />
                            </div>
                          </div>
                          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mt-2 px-1">
                            <span>Max: 12 jam</span>
                            <span className="font-semibold">
                              Total: {customHours}j {customMinutes}m {customSeconds}d 
                              <span className="text-blue-600 dark:text-blue-400 ml-1">
                                ({customHours * 3600 + customMinutes * 60 + customSeconds} detik)
                              </span>
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Timer Display */}
                  <div className="text-center py-8">
                    <motion.div
                      animate={{ scale: isRunning ? [1, 1.02, 1] : 1 }}
                      transition={{ duration: 1, repeat: isRunning ? Infinity : 0 }}
                      className="text-8xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4"
                    >
                      {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
                    </motion.div>
                    <Progress value={progress} className="h-3 mb-4" />
                    <p className="text-gray-600 dark:text-gray-400">
                      {mode === "focus" 
                        ? `${blockedApps.length} aplikasi diblokir` 
                        : "Waktu istirahat"
                      }
                    </p>
                  </div>

                  {/* Controls */}
                  <div className="flex gap-3 justify-center">
                    {!isRunning ? (
                      <Button
                        onClick={handleStart}
                        className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8"
                        size="lg"
                      >
                        <Play className="mr-2" />
                        Mulai Fokus
                      </Button>
                    ) : (
                      <Button
                        onClick={handlePause}
                        variant="outline"
                        size="lg"
                        className="px-8"
                      >
                        <Pause className="mr-2" />
                        Pause
                      </Button>
                    )}
                    <Button
                      onClick={handleReset}
                      variant="outline"
                      size="lg"
                    >
                      <RotateCcw className="mr-2" />
                      Reset
                    </Button>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-4 pt-6 border-t dark:border-gray-700">
                    <div className="text-center">
                      <Trophy className="w-6 h-6 text-yellow-500 mx-auto mb-1" />
                      <div className="text-2xl font-bold text-gray-900 dark:text-white">
                        {sessions}
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">
                        Sesi Hari Ini
                      </div>
                    </div>
                    <div className="text-center">
                      <Flame className="w-6 h-6 text-orange-500 mx-auto mb-1" />
                      <div className="text-2xl font-bold text-gray-900 dark:text-white">
                        {getUserStats().currentStreak}
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">
                        Hari Streak
                      </div>
                    </div>
                    <div className="text-center">
                      <Target className="w-6 h-6 text-blue-500 mx-auto mb-1" />
                      <div className="text-2xl font-bold text-gray-900 dark:text-white">
                        {unlockAttempts}
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">
                        Unlock Attempts
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Blocked Apps */}
            <div className="lg:col-span-1">
              <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5 text-red-500" />
                    Aplikasi Diblokir
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {blockedApps.length === 0 ? (
                    <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                      <AlertTriangle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">Belum ada aplikasi diblokir</p>
                      <Button
                        variant="link"
                        onClick={() => navigate("/settings")}
                        className="mt-2"
                      >
                        Setup di Settings →
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                        Klik untuk simulasi blocker quiz:
                      </p>
                      {blockedApps.slice(0, 6).map((app) => {
                        const IconComponent = blockedAppIcons[app.name as keyof typeof blockedAppIcons] || Smartphone;
                        return (
                          <motion.button
                            key={app.id}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => handleBlockedAppClick(app.name)}
                            className="w-full flex items-center justify-between p-3 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors"
                          >
                            <div className="flex items-center gap-3">
                              <IconComponent className="w-5 h-5 text-red-600 dark:text-red-400" />
                              <span className="font-medium text-gray-900 dark:text-white">
                                {app.name}
                              </span>
                            </div>
                            <Lock className="w-4 h-4 text-red-600 dark:text-red-400" />
                          </motion.button>
                        );
                      })}
                      
                      {!isRunning && (
                        <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                          <p className="text-xs text-blue-700 dark:text-blue-300 text-center">
                            💡 Mulai focus mode untuk mengaktifkan blocker
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* BLOCKER MODAL - CORE INNOVATION */}
      <AnimatePresence>
        {showBlockerModal && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
              onClick={handleCloseModal}
            />

            {/* Modal */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
            >
              <div className="w-full max-w-2xl" onClick={(e) => e.stopPropagation()}>
                {/* Blocked State */}
                {quizState === "blocked" && (
                  <Card className="bg-gradient-to-br from-red-900/90 to-pink-900/90 backdrop-blur-xl border-red-500/50">
                    <CardContent className="p-8 text-center">
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="mb-6"
                      >
                        <div className="inline-block p-6 bg-white/10 rounded-full">
                          <Lock className="w-16 h-16 text-white" />
                        </div>
                      </motion.div>

                      <h2 className="text-3xl font-bold text-white mb-4">
                        {blockedAppAttempt} Diblokir!
                      </h2>
                      
                      <div className="bg-white/20 rounded-xl p-6 mb-6">
                        <p className="text-xl text-white mb-4">
                          Selesaikan <span className="font-bold text-yellow-400">
                            {Math.min(3 + Math.floor(unlockAttempts / 2), 5)} soal
                          </span> dari materi <span className="font-bold text-blue-300">Kalkulus I</span> untuk membuka akses selama{" "}
                          <span className="font-bold text-green-300">2 menit</span>
                        </p>
                        <div className="flex items-center justify-center gap-4 text-gray-200">
                          <div className="flex items-center gap-2">
                            <Brain className="w-5 h-5" />
                            <span>Materi Kuliah</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="w-5 h-5" />
                            <span>{Math.min(3 + Math.floor(unlockAttempts / 2), 5)} soal</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-4">
                        <Button
                          onClick={handleCloseModal}
                          variant="outline"
                          className="flex-1 bg-white/10 border-white/30 text-white hover:bg-white/20"
                        >
                          Batal
                        </Button>
                        <Button
                          onClick={handleStartQuiz}
                          className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white hover:from-green-600 hover:to-emerald-600 font-bold"
                        >
                          Mulai Quiz
                        </Button>
                      </div>

                      <p className="text-sm text-gray-300 mt-4">
                        ⚠️ Gagal = Penalty 10 menit + Reset streak + -50 poin
                      </p>
                    </CardContent>
                  </Card>
                )}

                {/* Loading State */}
                {quizState === "loading" && (
                  <Card className="bg-gradient-to-br from-purple-900/90 to-blue-900/90 backdrop-blur-xl border-purple-500/50">
                    <CardContent className="p-12 text-center">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                        className="mb-6"
                      >
                        <Brain className="w-16 h-16 text-purple-400 mx-auto" />
                      </motion.div>
                      <h3 className="text-2xl font-bold text-white mb-2">
                        AI Generating Quiz...
                      </h3>
                      <p className="text-gray-300">
                        Memproses materi Kalkulus I Anda
                      </p>
                      <Progress value={undefined} className="mt-6" />
                    </CardContent>
                  </Card>
                )}

                {/* Quiz State */}
                {quizState === "quiz" && quizQuestions.length > 0 && (
                  <Card className="bg-gradient-to-br from-purple-900/90 to-blue-900/90 backdrop-blur-xl border-purple-500/50">
                    <CardContent className="p-8">
                      <div className="mb-6">
                        <div className="flex items-center justify-between mb-2">
                          <Badge className="bg-blue-500 text-white">
                            Soal {currentQuestionIndex + 1}/{quizQuestions.length}
                          </Badge>
                          <Badge className="bg-purple-500 text-white">
                            {quizQuestions[currentQuestionIndex].subject}
                          </Badge>
                        </div>
                        <Progress value={((currentQuestionIndex + 1) / quizQuestions.length) * 100} className="h-2" />
                      </div>

                      <h3 className="text-2xl font-bold text-white mb-6">
                        {quizQuestions[currentQuestionIndex].question}
                      </h3>

                      <div className="space-y-3">
                        {quizQuestions[currentQuestionIndex].options.map((option, index) => {
                          const isSelected = selectedAnswer === index;
                          const isCorrect = index === quizQuestions[currentQuestionIndex].correct;
                          const showResult = selectedAnswer !== null;

                          return (
                            <motion.button
                              key={index}
                              whileHover={{ scale: selectedAnswer === null ? 1.02 : 1 }}
                              whileTap={{ scale: selectedAnswer === null ? 0.98 : 1 }}
                              onClick={() => selectedAnswer === null && handleAnswerSelect(index)}
                              disabled={selectedAnswer !== null}
                              className={`w-full p-4 rounded-xl text-left font-medium transition-all ${
                                showResult && isSelected
                                  ? isCorrect
                                    ? 'bg-green-500 text-white border-2 border-green-300'
                                    : 'bg-red-500 text-white border-2 border-red-300'
                                  : 'bg-white/10 text-white border-2 border-white/20 hover:bg-white/20'
                              } ${selectedAnswer !== null && 'cursor-not-allowed opacity-60'}`}
                            >
                              <span className="mr-3 font-bold">
                                {String.fromCharCode(65 + index)}.
                              </span>
                              {option}
                              {showResult && isSelected && (
                                <span className="float-right">
                                  {isCorrect ? "✓" : "✗"}
                                </span>
                              )}
                            </motion.button>
                          );
                        })}
                      </div>

                      <div className="mt-6 text-center text-gray-300 text-sm flex items-center justify-center gap-2">
                        <AlertTriangle className="w-4 h-4" />
                        Pilih jawaban dengan hati-hati
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Failed State */}
                {quizState === "failed" && (
                  <Card className="bg-gradient-to-br from-red-900/90 to-orange-900/90 backdrop-blur-xl border-red-500/50">
                    <CardContent className="p-8 text-center">
                      <motion.div
                        initial={{ scale: 0, rotate: -180 }}
                        animate={{ scale: 1, rotate: 0 }}
                        className="mb-6"
                      >
                        <div className="inline-block p-6 bg-red-500/20 rounded-full">
                          <X className="w-16 h-16 text-red-400" />
                        </div>
                      </motion.div>

                      <h2 className="text-3xl font-bold text-white mb-4">
                        Jawaban Salah!
                      </h2>

                      <div className="bg-white/10 rounded-xl p-6 mb-6 space-y-3">
                        <div className="flex items-center justify-center gap-2 text-red-300">
                          <Timer className="w-5 h-5" />
                          <span className="text-lg font-bold">Penalty: 10 menit lockout</span>
                        </div>
                        <div className="flex items-center justify-center gap-2 text-orange-300">
                          <X className="w-5 h-5" />
                          <span className="text-lg font-bold">Streak harian di-reset</span>
                        </div>
                        <div className="flex items-center justify-center gap-2 text-yellow-300">
                          <AlertTriangle className="w-5 h-5" />
                          <span className="text-lg font-bold">-50 poin</span>
                        </div>
                      </div>

                      <Button
                        onClick={handleCloseModal}
                        className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white hover:from-orange-600 hover:to-red-600 font-bold"
                      >
                        Tutup
                      </Button>

                      <p className="text-sm text-gray-300 mt-4">
                        💡 Tip: Pelajari kembali materi sebelum mencoba unlock
                      </p>
                    </CardContent>
                  </Card>
                )}

                {/* Success State */}
                {quizState === "success" && (
                  <Card className="bg-gradient-to-br from-green-900/90 to-emerald-900/90 backdrop-blur-xl border-green-500/50">
                    <CardContent className="p-8 text-center">
                      <motion.div
                        initial={{ scale: 0, rotate: 180 }}
                        animate={{ scale: 1, rotate: 0 }}
                        className="mb-6"
                      >
                        <div className="inline-block p-6 bg-green-500/20 rounded-full">
                          <CheckCircle2 className="w-16 h-16 text-green-400" />
                        </div>
                      </motion.div>

                      <h2 className="text-3xl font-bold text-white mb-4">
                        Berhasil! 🎉
                      </h2>

                      <div className="bg-white/10 rounded-xl p-6 mb-6">
                        <p className="text-xl text-white mb-4">
                          {blockedAppAttempt} dibuka untuk{" "}
                          <span className="font-bold text-green-300">
                            {Math.floor(unlockTimeLeft / 60)}:{(unlockTimeLeft % 60).toString().padStart(2, '0')}
                          </span>
                        </p>
                        
                        <div className="mb-4">
                          <div className="flex items-center justify-center gap-2 mb-2">
                            <Timer className="w-5 h-5 text-blue-300" />
                            <span className="text-gray-200">Waktu tersisa</span>
                          </div>
                          <Progress value={(unlockTimeLeft / 120) * 100} className="h-3" />
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div className="bg-white/5 rounded-lg p-3">
                            <div className="text-2xl mb-1">+{quizQuestions.length * 10}</div>
                            <div className="text-gray-300">Poin</div>
                          </div>
                          <div className="bg-white/5 rounded-lg p-3">
                            <div className="text-2xl mb-1">🔥</div>
                            <div className="text-gray-300">Streak tetap</div>
                          </div>
                        </div>
                      </div>

                      <Button
                        onClick={handleCloseModal}
                        className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:from-blue-600 hover:to-purple-600 font-bold"
                      >
                        Gunakan Akses
                      </Button>

                      <p className="text-sm text-gray-300 mt-4">
                        ⚠️ Aplikasi akan otomatis terkunci lagi setelah waktu habis
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </AppLayout>
  );
}