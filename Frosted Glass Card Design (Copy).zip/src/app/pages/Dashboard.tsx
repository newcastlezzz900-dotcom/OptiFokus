import { useState, useEffect } from "react";
import { Link } from "react-router";
import { Navbar } from "@/app/components/Navbar";
import { BottomNav } from "@/app/components/BottomNav";
import { AvatarEvolutionNew } from "@/app/components/AvatarEvolutionNew";
import { FloatingChatButton } from "@/app/components/FloatingChatButton";
import { WelcomeBanner } from "@/app/components/WelcomeBanner";
import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Badge } from "@/app/components/ui/badge";
import { Progress } from "@/app/components/ui/progress";
import {
  Focus,
  Upload,
  Calendar,
  Users,
  BarChart3,
  Trophy,
  Flame,
  Target,
  Clock,
  BookOpen,
  ArrowRight,
  TrendingUp,
  Zap,
  Brain,
} from "lucide-react";
import { motion } from "motion/react";

export function Dashboard() {
  const [stats, setStats] = useState({
    focusTimeToday: 3.2,
    focusGoal: 6,
    streak: 7,
    quizAccuracy: 87,
    level: 12,
    xp: 1840,
    xpToNext: 2000,
  });

  useEffect(() => {
    const hasSeenWelcome = localStorage.getItem("hasSeenWelcome");
    if (!hasSeenWelcome) {
      localStorage.setItem("hasSeenWelcome", "true");
    }
  }, []);

  const quickActions = [
    {
      title: "Mulai Fokus",
      description: "Aktifkan mode fokus",
      icon: <Focus className="w-6 h-6" />,
      path: "/focus",
      gradient: "from-blue-500 to-blue-600",
      iconBg: "bg-blue-500",
    },
    {
      title: "Upload Materi",
      description: "Tambah materi baru",
      icon: <Upload className="w-6 h-6" />,
      path: "/upload",
      gradient: "from-purple-500 to-purple-600",
      iconBg: "bg-purple-500",
    },
    {
      title: "Jadwal",
      description: "Atur sesi belajar",
      icon: <Calendar className="w-6 h-6" />,
      path: "/schedule",
      gradient: "from-green-500 to-green-600",
      iconBg: "bg-green-500",
    },
    {
      title: "Silent Room",
      description: "Belajar bareng teman",
      icon: <Users className="w-6 h-6" />,
      path: "/silent-room",
      gradient: "from-orange-500 to-orange-600",
      iconBg: "bg-orange-500",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-24">
        {/* Hero Header Section */}
        <motion.div 
          className="mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-start justify-between flex-wrap gap-4 mb-6">
            <div>
              <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent mb-3">
                Dashboard OptiFokus
              </h1>
              <p className="text-lg text-slate-600 dark:text-slate-300">
                Selamat datang kembali! 🚀 Mari capai target hari ini.
              </p>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-5 py-2.5 text-base shadow-lg">
                <Flame className="w-5 h-5 mr-2 inline" />
                {stats.streak} hari streak
              </Badge>
              <Badge className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-5 py-2.5 text-base shadow-lg">
                <Target className="w-5 h-5 mr-2 inline" />
                Level {stats.level}
              </Badge>
            </div>
          </div>
        </motion.div>

        {/* Stats Overview - Colorful Cards */}
        <motion.div 
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
        >
          {/* Streak Card */}
          <Card className="p-6 bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/20 dark:to-red-950/20 border-2 border-orange-200 dark:border-orange-900/50 shadow-xl hover:shadow-2xl transition-all hover:scale-105">
            <div className="flex flex-col items-center text-center gap-3">
              <div className="p-4 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl shadow-lg">
                <Flame className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="text-sm text-orange-600 dark:text-orange-400 font-semibold mb-1">Streak</p>
                <p className="text-4xl font-bold text-orange-700 dark:text-orange-300">{stats.streak}</p>
                <p className="text-xs text-orange-600 dark:text-orange-400 mt-1">hari beruntun 🔥</p>
              </div>
            </div>
          </Card>

          {/* Level Card */}
          <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 border-2 border-blue-200 dark:border-blue-900/50 shadow-xl hover:shadow-2xl transition-all hover:scale-105">
            <div className="flex flex-col items-center text-center gap-3">
              <div className="p-4 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-2xl shadow-lg">
                <Target className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="text-sm text-blue-600 dark:text-blue-400 font-semibold mb-1">Level</p>
                <p className="text-4xl font-bold text-blue-700 dark:text-blue-300">{stats.level}</p>
                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">Phoenix Alpha 🦅</p>
              </div>
            </div>
          </Card>

          {/* Focus Time Card */}
          <Card className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 border-2 border-green-200 dark:border-green-900/50 shadow-xl hover:shadow-2xl transition-all hover:scale-105">
            <div className="flex flex-col items-center text-center gap-3">
              <div className="p-4 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl shadow-lg">
                <Clock className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="text-sm text-green-600 dark:text-green-400 font-semibold mb-1">Fokus Hari Ini</p>
                <p className="text-4xl font-bold text-green-700 dark:text-green-300">{stats.focusTimeToday}h</p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">dari {stats.focusGoal}h target ⏱️</p>
              </div>
            </div>
          </Card>

          {/* Accuracy Card */}
          <Card className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border-2 border-purple-200 dark:border-purple-900/50 shadow-xl hover:shadow-2xl transition-all hover:scale-105">
            <div className="flex flex-col items-center text-center gap-3">
              <div className="p-4 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl shadow-lg">
                <Trophy className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="text-sm text-purple-600 dark:text-purple-400 font-semibold mb-1">Akurasi Quiz</p>
                <p className="text-4xl font-bold text-purple-700 dark:text-purple-300">{stats.quizAccuracy}%</p>
                <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">rata-rata 🎯</p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Quick Actions - Hero CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="mb-8"
        >
          <Card className="p-6 sm:p-8 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm shadow-2xl border-2 border-blue-200 dark:border-blue-900">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-slate-800 dark:text-white">Quick Actions</h3>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {quickActions.map((action, idx) => (
                <Link key={idx} to={action.path}>
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`p-6 rounded-2xl bg-gradient-to-br ${action.gradient} shadow-lg hover:shadow-2xl transition-all cursor-pointer`}
                  >
                    <div className="flex flex-col items-center text-center gap-3 text-white">
                      <div className="p-4 bg-white/20 rounded-xl backdrop-blur-sm">
                        {action.icon}
                      </div>
                      <div>
                        <div className="font-bold text-lg mb-1">{action.title}</div>
                        <div className="text-sm opacity-90">{action.description}</div>
                      </div>
                      <ArrowRight className="w-5 h-5 mt-2" />
                    </div>
                  </motion.div>
                </Link>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Avatar & Progress Section */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Avatar Card */}
          <Card className="p-6 bg-white dark:bg-slate-900 shadow-xl border-2 border-blue-200 dark:border-blue-900">
            <h3 className="font-bold text-xl mb-4 text-slate-800 dark:text-white flex items-center gap-2">
              <Brain className="w-6 h-6 text-blue-500" />
              Avatar Kamu
            </h3>
            <div className="mb-6 flex justify-center">
              <AvatarEvolutionNew streak={stats.streak} />
            </div>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-slate-600 dark:text-slate-400 font-medium">Level {stats.level}</span>
                  <span className="font-bold text-blue-600 dark:text-blue-400">{stats.xp} / {stats.xpToNext} XP</span>
                </div>
                <Progress value={(stats.xp / stats.xpToNext) * 100} className="h-3" />
                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1 text-center">
                  {stats.xpToNext - stats.xp} XP lagi untuk naik level! 🚀
                </p>
              </div>
            </div>
          </Card>

          {/* Progress Today */}
          <Card className="lg:col-span-2 p-6 bg-white dark:bg-slate-900 shadow-xl border-2 border-green-200 dark:border-green-900">
            <h3 className="font-bold text-xl mb-4 text-slate-800 dark:text-white flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-green-500" />
              Progress Hari Ini
            </h3>
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <div className="flex justify-between text-sm mb-3">
                  <span className="text-slate-600 dark:text-slate-400 font-semibold">Waktu Fokus</span>
                  <span className="font-bold text-green-600 dark:text-green-400">
                    {stats.focusTimeToday} / {stats.focusGoal} jam
                  </span>
                </div>
                <Progress value={(stats.focusTimeToday / stats.focusGoal) * 100} className="h-4 mb-2" />
                <p className="text-xs text-green-600 dark:text-green-400">
                  {((stats.focusTimeToday / stats.focusGoal) * 100).toFixed(0)}% dari target ✅
                </p>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-3">
                  <span className="text-slate-600 dark:text-slate-400 font-semibold">Akurasi Quiz</span>
                  <span className="font-bold text-purple-600 dark:text-purple-400">
                    {stats.quizAccuracy} / 100%
                  </span>
                </div>
                <Progress value={stats.quizAccuracy} className="h-4 mb-2" />
                <p className="text-xs text-purple-600 dark:text-purple-400">
                  Excellent performance! 🎯
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Aktivitas Terakhir */}
        <Card className="p-6 sm:p-8 bg-white dark:bg-slate-900 shadow-xl border-2 border-slate-200 dark:border-slate-800 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-2xl text-slate-800 dark:text-white flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-blue-500" />
              Aktivitas Terakhir
            </h3>
            <Link to="/analytics">
              <Button variant="outline" className="border-blue-300 dark:border-blue-700 hover:bg-blue-50 dark:hover:bg-blue-950">
                Lihat Semua
              </Button>
            </Link>
          </div>
          <div className="space-y-3">
            <div className="flex items-start gap-4 p-4 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg flex-shrink-0">
                <Focus className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-800 dark:text-white">Sesi Fokus Selesai</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">50 menit - Materi Kalkulus</p>
              </div>
              <span className="text-sm text-slate-500 dark:text-slate-400 flex-shrink-0">2 jam lalu</span>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900">
              <div className="p-3 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl shadow-lg flex-shrink-0">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-800 dark:text-white">Quiz Selesai</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">8/10 benar - Fisika Mekanika</p>
              </div>
              <span className="text-sm text-slate-500 dark:text-slate-400 flex-shrink-0">5 jam lalu</span>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-xl bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-900">
              <div className="p-3 bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg flex-shrink-0">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-800 dark:text-white">Level Up!</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">Naik ke Level 12</p>
              </div>
              <span className="text-sm text-slate-500 dark:text-slate-400 flex-shrink-0">1 hari lalu</span>
            </div>
          </div>
        </Card>

        {/* Secondary Navigation */}
        <div className="grid sm:grid-cols-3 gap-4">
          <Link to="/leaderboard">
            <Card className="p-6 hover:shadow-xl transition-all cursor-pointer bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 border-2 border-yellow-200 dark:border-yellow-900 hover:scale-105">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl shadow-lg">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="font-bold text-lg text-slate-800 dark:text-white">Leaderboard</p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Lihat ranking</p>
                </div>
              </div>
            </Card>
          </Link>
          <Link to="/analytics">
            <Card className="p-6 hover:shadow-xl transition-all cursor-pointer bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 border-2 border-blue-200 dark:border-blue-900 hover:scale-105">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-xl shadow-lg">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="font-bold text-lg text-slate-800 dark:text-white">Analytics</p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Statistik lengkap</p>
                </div>
              </div>
            </Card>
          </Link>
          <Link to="/accountability">
            <Card className="p-6 hover:shadow-xl transition-all cursor-pointer bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border-2 border-purple-200 dark:border-purple-900 hover:scale-105">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl shadow-lg">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="font-bold text-lg text-slate-800 dark:text-white">Accountability</p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Partner & Privacy</p>
                </div>
              </div>
            </Card>
          </Link>
        </div>
      </div>

      <BottomNav />
      <FloatingChatButton />
      <WelcomeBanner />
    </div>
  );
}