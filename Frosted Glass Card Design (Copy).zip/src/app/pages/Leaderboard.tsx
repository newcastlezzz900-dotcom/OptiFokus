import { useState } from "react";
import { AppLayout } from "@/app/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Avatar, AvatarFallback } from "@/app/components/ui/avatar";
import { Badge } from "@/app/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/app/components/ui/tabs";
import { getUserStats } from "@/app/lib/store";
import { Trophy, Medal, Crown, TrendingUp, Flame, Zap } from "lucide-react";
import { motion } from "motion/react";

interface LeaderboardUser {
  id: string;
  name: string;
  points: number;
  streak: number;
  focusMinutes: number;
  avatar: string;
  rank: number;
}

// Mock global leaderboard data
const generateMockLeaderboard = (): LeaderboardUser[] => {
  const names = [
    "Ahmad", "Budi", "Citra", "Dina", "Eka", "Fajar", "Gita", "Hadi",
    "Indah", "Joko", "Kiki", "Lina", "Made", "Nina", "Omar", "Putri",
    "Qori", "Rani", "Siti", "Tono"
  ];
  
  const users: LeaderboardUser[] = names.map((name, index) => ({
    id: `user-${index}`,
    name,
    points: Math.floor(Math.random() * 10000) + 1000,
    streak: Math.floor(Math.random() * 150) + 1,
    focusMinutes: Math.floor(Math.random() * 5000) + 500,
    avatar: name.charAt(0),
    rank: 0,
  }));

  // Add current user
  const currentUser = getUserStats();
  users.push({
    id: "current-user",
    name: "Kamu",
    points: currentUser.points,
    streak: currentUser.streak,
    focusMinutes: currentUser.totalFocusMinutes,
    avatar: "😊",
    rank: 0,
  });

  return users;
};

export function Leaderboard() {
  const [activeTab, setActiveTab] = useState<"points" | "streak" | "focus">("points");
  
  const allUsers = generateMockLeaderboard();
  
  // Sort based on active tab
  const sortedUsers = [...allUsers].sort((a, b) => {
    if (activeTab === "points") return b.points - a.points;
    if (activeTab === "streak") return b.streak - a.streak;
    return b.focusMinutes - a.focusMinutes;
  }).map((user, index) => ({ ...user, rank: index + 1 }));

  const currentUserRank = sortedUsers.find(u => u.id === "current-user");

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="text-yellow-500" size={24} fill="currentColor" />;
    if (rank === 2) return <Medal className="text-gray-400" size={24} />;
    if (rank === 3) return <Medal className="text-orange-600" size={24} />;
    return null;
  };

  const getRankBg = (rank: number) => {
    if (rank === 1) return "bg-gradient-to-r from-yellow-500 to-orange-500";
    if (rank === 2) return "bg-gradient-to-r from-gray-400 to-gray-500";
    if (rank === 3) return "bg-gradient-to-r from-orange-600 to-orange-700";
    return "bg-gradient-to-r from-blue-500 to-purple-600";
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-6 sm:mb-8"
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <Trophy className="text-yellow-500" size={32} />
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">
              Leaderboard Global
            </h1>
          </div>
          <p className="text-gray-600 dark:text-gray-400">
            Kompetisi dengan user OptiFokus di seluruh dunia!
          </p>
        </motion.div>

        {/* Current User Rank Card */}
        {currentUserRank && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-6"
          >
            <Card className="border-2 border-blue-500 dark:border-blue-600 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/50 dark:to-purple-950/50">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 sm:gap-4">
                    <div className={`w-12 h-12 sm:w-16 sm:h-16 rounded-full ${getRankBg(currentUserRank.rank)} flex items-center justify-center text-white font-bold text-lg sm:text-xl shadow-lg`}>
                      #{currentUserRank.rank}
                    </div>
                    <div>
                      <p className="font-bold text-lg sm:text-xl text-gray-900 dark:text-white">
                        Peringkat Kamu
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {currentUserRank.points.toLocaleString()} poin
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className="mb-1" variant="secondary">
                      <Flame size={12} className="mr-1" />
                      {currentUserRank.streak} hari
                    </Badge>
                    <p className="text-xs text-gray-600 dark:text-gray-400">
                      {Math.floor(currentUserRank.focusMinutes / 60)}j {currentUserRank.focusMinutes % 60}m
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Tabs */}
        <Card className="dark:bg-gray-900 dark:border-gray-800">
          <CardHeader className="pb-3">
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="points" className="text-xs sm:text-sm">
                  <Trophy size={14} className="mr-1 sm:mr-2" />
                  Poin
                </TabsTrigger>
                <TabsTrigger value="streak" className="text-xs sm:text-sm">
                  <Flame size={14} className="mr-1 sm:mr-2" />
                  Streak
                </TabsTrigger>
                <TabsTrigger value="focus" className="text-xs sm:text-sm">
                  <Zap size={14} className="mr-1 sm:mr-2" />
                  Fokus
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>
          
          <CardContent className="p-2 sm:p-6">
            {/* Top 3 Podium */}
            <div className="flex items-end justify-center gap-2 sm:gap-4 mb-6 sm:mb-8">
              {[sortedUsers[1], sortedUsers[0], sortedUsers[2]].map((user, idx) => {
                if (!user) return null;
                const actualRank = user.rank;
                return (
                  <motion.div
                    key={user.id}
                    initial={{ opacity: 0, y: 50 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className={`flex flex-col items-center ${idx === 1 ? 'order-2' : ''}`}
                  >
                    <div className="relative mb-2">
                      {getRankIcon(actualRank) && (
                        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                          {getRankIcon(actualRank)}
                        </div>
                      )}
                      <Avatar className={`${idx === 1 ? 'w-16 h-16 sm:w-20 sm:h-20' : 'w-12 h-12 sm:w-16 sm:h-16'} border-4 ${
                        actualRank === 1 ? 'border-yellow-500' :
                        actualRank === 2 ? 'border-gray-400' :
                        'border-orange-600'
                      }`}>
                        <AvatarFallback className={getRankBg(actualRank)}>
                          <span className="text-white font-bold">
                            {user.avatar}
                          </span>
                        </AvatarFallback>
                      </Avatar>
                    </div>
                    <p className="font-bold text-xs sm:text-sm text-gray-900 dark:text-white">{user.name}</p>
                    <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">
                      {activeTab === "points" && `${user.points.toLocaleString()} pts`}
                      {activeTab === "streak" && `${user.streak} hari`}
                      {activeTab === "focus" && `${Math.floor(user.focusMinutes / 60)}j`}
                    </p>
                    <div className={`mt-2 ${getRankBg(actualRank)} rounded-t-lg ${
                      idx === 1 ? 'h-24 sm:h-32 w-16 sm:w-24' : 'h-16 sm:h-24 w-12 sm:w-20'
                    }`} />
                  </motion.div>
                );
              })}
            </div>

            {/* Rest of leaderboard */}
            <div className="space-y-2">
              {sortedUsers.slice(3, 20).map((user, index) => (
                <motion.div
                  key={user.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`flex items-center justify-between p-3 sm:p-4 rounded-lg transition-colors ${
                    user.id === "current-user"
                      ? "bg-blue-50 dark:bg-blue-950/30 border-2 border-blue-500"
                      : "bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-750"
                  }`}
                >
                  <div className="flex items-center gap-2 sm:gap-3">
                    <div className="w-8 sm:w-10 text-center">
                      <span className="font-bold text-gray-600 dark:text-gray-400">
                        #{user.rank}
                      </span>
                    </div>
                    <Avatar className="w-8 h-8 sm:w-10 sm:h-10">
                      <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-xs sm:text-sm">
                        {user.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold text-sm sm:text-base text-gray-900 dark:text-white">
                        {user.name}
                      </p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">
                        {activeTab === "streak" && `${user.streak} hari streak`}
                        {activeTab === "focus" && `${Math.floor(user.focusMinutes / 60)}j ${user.focusMinutes % 60}m fokus`}
                        {activeTab === "points" && `${user.points.toLocaleString()} poin`}
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="font-bold text-sm sm:text-lg text-blue-600 dark:text-blue-400">
                      {activeTab === "points" && user.points.toLocaleString()}
                      {activeTab === "streak" && user.streak}
                      {activeTab === "focus" && Math.floor(user.focusMinutes / 60)}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {activeTab === "points" && "poin"}
                      {activeTab === "streak" && "hari"}
                      {activeTab === "focus" && "jam"}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Info */}
        <Card className="mt-6 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950/30 dark:to-blue-950/30 border-purple-200 dark:border-purple-800">
          <CardContent className="p-4 text-center">
            <TrendingUp className="mx-auto text-purple-600 dark:text-purple-400 mb-2" size={32} />
            <p className="text-sm text-purple-900 dark:text-purple-200">
              <strong>💪 Tetap semangat!</strong> Konsisten belajar setiap hari untuk naik peringkat
            </p>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}