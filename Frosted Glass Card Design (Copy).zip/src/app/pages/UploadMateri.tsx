import { useState } from "react";
import { useNavigate } from "react-router";
import { AppLayout } from "@/app/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Textarea } from "@/app/components/ui/textarea";
import {
  getMateri,
  addMateri,
  addQuizQuestions,
  generateMockQuiz,
} from "@/app/lib/store";
import { 
  Upload, 
  FileText, 
  CheckCircle2, 
  Sparkles, 
  BookOpen,
  Zap,
  Brain,
  ChevronRight,
  Eye,
  Trash2,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

export function UploadMateri() {
  const navigate = useNavigate();
  const [materiList, setMateriList] = useState(getMateri());
  const [materiName, setMateriName] = useState("");
  const [materiDescription, setMateriDescription] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [fileName, setFileName] = useState("");

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      if (materiName.trim() === "") {
        setMateriName(file.name.replace(/\.[^/.]+$/, ""));
      }
      toast.success("File dipilih!", {
        description: file.name,
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!materiName.trim()) {
      toast.error("Nama materi harus diisi!");
      return;
    }

    setIsUploading(true);

    // Simulate upload dan AI processing
    setTimeout(() => {
      const materiId = addMateri({
        name: materiName,
        uploadDate: new Date().toISOString(),
        fileType: "PDF",
      });

      // Generate mock quiz
      const questions = generateMockQuiz(materiName, materiId);
      addQuizQuestions(questions);

      setMateriList(getMateri());
      setMateriName("");
      setMateriDescription("");
      setFileName("");
      setIsUploading(false);

      toast.success("Materi berhasil diupload! 🎉", {
        description: `${questions.length} soal quiz telah dibuat`,
      });
    }, 2000);
  };

  return (
    <AppLayout>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Hero Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 dark:from-blue-400 dark:to-blue-600 bg-clip-text text-transparent">
                  Cara Kerja AI Quiz Generator
                </h1>
                <p className="text-lg text-slate-600 dark:text-slate-300 mt-1">
                  Belajar Tanpa Distraksi!
                </p>
              </div>
            </div>

            {/* How It Works */}
            <Card className="bg-gradient-to-r from-blue-500 to-blue-600 border-none shadow-xl">
              <CardContent className="p-6">
                <div className="grid sm:grid-cols-4 gap-4 text-white">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mb-3 backdrop-blur-sm">
                      <span className="text-xl font-bold">1</span>
                    </div>
                    <h3 className="font-semibold mb-1">Upload file materi kuliah/sekolah kamu (PDF/PPT)</h3>
                  </div>
                  
                  <div className="flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mb-3 backdrop-blur-sm">
                      <span className="text-xl font-bold">2</span>
                    </div>
                    <h3 className="font-semibold mb-1">AI akan menganalisis konten materi</h3>
                  </div>
                  
                  <div className="flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mb-3 backdrop-blur-sm">
                      <span className="text-xl font-bold">3</span>
                    </div>
                    <h3 className="font-semibold mb-1">Quiz otomatis dibuat berdasarkan materi tersebut</h3>
                  </div>
                  
                  <div className="flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mb-3 backdrop-blur-sm">
                      <span className="text-xl font-bold">4</span>
                    </div>
                    <h3 className="font-semibold mb-1">Gunakan quiz untuk unlock aplikasi yang diblokir</h3>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Upload Form */}
            <motion.div
              className="lg:col-span-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="shadow-xl border-2 border-blue-100 dark:border-blue-900">
                <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                      <Upload size={24} />
                    </div>
                    <span>Upload File Materi</span>
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="p-6">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* File Upload - Enhanced */}
                    <div>
                      <Label htmlFor="file" className="text-base font-semibold mb-3 block">
                        File Materi (PDF/PPT)
                      </Label>
                      <div className="mt-2">
                        <label
                          htmlFor="file"
                          className={`flex flex-col items-center justify-center w-full h-40 border-2 border-dashed rounded-2xl cursor-pointer transition-all ${
                            fileName 
                              ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/30' 
                              : 'border-blue-300 dark:border-blue-700 bg-white dark:bg-slate-900 hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30'
                          }`}
                        >
                          <AnimatePresence mode="wait">
                            {fileName ? (
                              <motion.div
                                key="uploaded"
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="text-center"
                              >
                                <CheckCircle2 className="text-blue-500 mx-auto mb-3" size={48} />
                                <span className="text-sm font-semibold text-blue-600 dark:text-blue-400">
                                  {fileName}
                                </span>
                                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                                  Klik untuk ganti file
                                </p>
                              </motion.div>
                            ) : (
                              <motion.div
                                key="empty"
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="text-center"
                              >
                                <Upload className="text-blue-500 mx-auto mb-3" size={48} />
                                <span className="text-base font-semibold text-blue-600 dark:text-blue-400">
                                  Klik untuk upload file
                                </span>
                                <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                                  PDF, PPT, PPTX (Max 10MB)
                                </p>
                              </motion.div>
                            )}
                          </AnimatePresence>
                          <input
                            id="file"
                            type="file"
                            className="hidden"
                            accept=".pdf,.ppt,.pptx"
                            onChange={handleFileUpload}
                          />
                        </label>
                      </div>
                    </div>

                    {/* Nama Materi */}
                    <div>
                      <Label htmlFor="name" className="text-base font-semibold">
                        Nama Materi
                      </Label>
                      <Input
                        id="name"
                        placeholder="Contoh: Pertemuan 2 Evolusi dan Kinerja Komputer"
                        value={materiName}
                        onChange={(e) => setMateriName(e.target.value)}
                        required
                        className="mt-2 h-12 text-base"
                      />
                    </div>

                    {/* Deskripsi (Optional) */}
                    <div>
                      <Label htmlFor="description" className="text-base font-semibold">
                        Deskripsi (Opsional)
                      </Label>
                      <Textarea
                        id="description"
                        placeholder="Tambahkan catatan tentang materi ini..."
                        value={materiDescription}
                        onChange={(e) => setMateriDescription(e.target.value)}
                        rows={4}
                        className="mt-2 text-base"
                      />
                    </div>

                    {/* Submit Button */}
                    <Button
                      type="submit"
                      disabled={isUploading}
                      className="w-full h-14 text-lg bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all"
                    >
                      {isUploading ? (
                        <>
                          <Sparkles className="mr-2 animate-spin" size={24} />
                          AI sedang membuat quiz...
                        </>
                      ) : (
                        <>
                          <Upload className="mr-2" size={24} />
                          Upload & Generate Quiz
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            {/* Info Sidebar */}
            <motion.div
              className="lg:col-span-1 space-y-6"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              {/* Contextual Learning Info */}
              <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/30 dark:to-orange-950/30 border-yellow-200 dark:border-yellow-800 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <Brain className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
                    <h3 className="font-bold text-yellow-900 dark:text-yellow-300">
                      💡 Contextual Learning
                    </h3>
                  </div>
                  <p className="text-sm text-yellow-800 dark:text-yellow-200 leading-relaxed">
                    Quiz dibuat dari materi kamu sendiri, jadi lebih relevan dan membantu belajar!
                  </p>
                </CardContent>
              </Card>

              {/* Materi Tersimpan */}
              <Card className="shadow-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <BookOpen className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    <span>📚 Materi Tersimpan</span>
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="p-4">
                  {materiList.length === 0 ? (
                    <div className="text-center py-8">
                      <FileText className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Belum ada materi
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-80 overflow-y-auto">
                      {materiList.map((materi, idx) => (
                        <motion.div
                          key={materi.id}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.1 }}
                          className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors border border-slate-200 dark:border-slate-800"
                        >
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-blue-500 rounded-lg flex-shrink-0">
                              <FileText className="w-4 h-4 text-white" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-sm text-slate-900 dark:text-white truncate">
                                {materi.name}
                              </p>
                              <p className="text-xs text-slate-500 dark:text-slate-400">
                                <CheckCircle2 className="w-3 h-3 inline text-green-500 mr-1" />
                                {materi.quizCount} quiz siap
                              </p>
                            </div>
                          </div>
                          <div className="flex gap-2 mt-3">
                            <Button
                              onClick={() => navigate(`/materi?id=${materi.id}`)}
                              size="sm"
                              variant="outline"
                              className="flex-1 border-blue-300 dark:border-blue-700 hover:bg-blue-50 dark:hover:bg-blue-950"
                            >
                              <Eye className="w-3 h-3 mr-1" />
                              Baca Materi
                            </Button>
                            <Button
                              onClick={() => {
                                toast.success("Materi dihapus");
                                setMateriList(materiList.filter(m => m.id !== materi.id));
                              }}
                              size="sm"
                              variant="outline"
                              className="border-red-300 dark:border-red-700 text-red-600 dark:text-red-400"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}