import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Navbar } from "@/app/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Progress } from "@/app/components/ui/progress";
import { Badge } from "@/app/components/ui/badge";
import {
  getQuizQuestions,
  getMateri,
  addPoints,
  updateUserStats,
  getUserStats,
  QuizQuestion,
  getQuizHistory,
  addQuizHistory,
} from "@/app/lib/store";
import { 
  Brain, 
  CheckCircle2, 
  XCircle, 
  Trophy, 
  ArrowRight,
  Zap,
  Target,
  TrendingUp,
  Clock
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

export function QuizChallenge() {
  const navigate = useNavigate();
  const [materi] = useState(getMateri());
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [quizComplete, setQuizComplete] = useState(false);
  const [wrongQuestions, setWrongQuestions] = useState<string[]>([]);

  useEffect(() => {
    const allQuestions = getQuizQuestions();
    if (allQuestions.length > 0) {
      // Adaptive Difficulty: Prioritaskan soal yang pernah salah (Spaced Repetition)
      const history = getQuizHistory();
      const wrongIds = history.filter(h => !h.correct).map(h => h.questionId);
      
      // Pisahkan soal yang pernah salah vs belum pernah
      const wrongQs = allQuestions.filter(q => wrongIds.includes(q.id));
      const otherQs = allQuestions.filter(q => !wrongIds.includes(q.id));
      
      // Prioritaskan wrong questions (60%), sisanya random
      const selectedWrong = wrongQs.slice(0, 3);
      const selectedOther = [...otherQs].sort(() => Math.random() - 0.5).slice(0, 2);
      
      const finalQuestions = [...selectedWrong, ...selectedOther]
        .sort(() => Math.random() - 0.5)
        .slice(0, 5);
      
      setQuestions(finalQuestions);
    }
  }, []);

  const handleAnswerSelect = (answerIndex: number) => {
    if (showResult) return;
    setSelectedAnswer(answerIndex);
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) {
      toast.error("Pilih jawaban terlebih dahulu!");
      return;
    }

    const currentQ = questions[currentQuestion];
    const isCorrect = selectedAnswer === currentQ.correctAnswer;
    
    // Record to history untuk spaced repetition
    addQuizHistory({
      questionId: currentQ.id,
      date: new Date().toISOString(),
      correct: isCorrect,
    });
    
    if (isCorrect) {
      setScore(score + 1);
      toast.success("Jawaban benar! 🎉", {
        description: "+20 poin",
      });
    } else {
      setWrongQuestions([...wrongQuestions, currentQ.id]);
      toast.error("Jawaban salah", {
        description: "Soal ini akan muncul lagi nanti (Spaced Repetition)",
      });
    }

    setShowResult(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      // Quiz complete
      const stats = getUserStats();
      const earnedPoints = score * 20;
      
      updateUserStats({
        points: stats.points + earnedPoints,
        distractionsBlocked: stats.distractionsBlocked + 1,
      });

      setQuizComplete(true);
      
      if (score >= 3) {
        toast.success("Quiz selesai! Akses dibuka! 🎉", {
          description: `Kamu mendapat ${earnedPoints} poin`,
        });
      } else {
        toast.error("Quiz gagal!", {
          description: "Perlu minimal 3 jawaban benar untuk unlock",
        });
      }
    }
  };

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950">
        <Navbar />
        <div className="max-w-2xl mx-auto px-4 py-16 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="p-8 shadow-xl">
              <Brain className="w-16 h-16 mx-auto mb-4 text-blue-500" />
              <h2 className="text-2xl font-bold mb-2 text-slate-800 dark:text-white">
                Belum Ada Quiz
              </h2>
              <p className="text-slate-600 dark:text-slate-400 mb-6">
                Upload materi terlebih dahulu untuk membuat quiz
              </p>
              <Button
                onClick={() => navigate("/upload")}
                className="bg-gradient-to-r from-blue-500 to-blue-600"
              >
                Upload Materi
              </Button>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  if (quizComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950">
        <Navbar />
        <div className="max-w-2xl mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <Card className="p-8 shadow-2xl border-2 border-blue-200 dark:border-blue-900">
              <div className="text-center">
                {score >= 3 ? (
                  <>
                    <Trophy className="w-20 h-20 mx-auto mb-4 text-yellow-500" />
                    <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-blue-800 dark:from-blue-400 dark:to-blue-600 bg-clip-text text-transparent">
                      Selamat! 🎉
                    </h2>
                    <p className="text-lg text-slate-600 dark:text-slate-400 mb-6">
                      Kamu berhasil unlock akses!
                    </p>
                  </>
                ) : (
                  <>
                    <XCircle className="w-20 h-20 mx-auto mb-4 text-red-500" />
                    <h2 className="text-3xl font-bold mb-2 text-slate-800 dark:text-white">
                      Coba Lagi
                    </h2>
                    <p className="text-lg text-slate-600 dark:text-slate-400 mb-6">
                      Perlu minimal 3 jawaban benar
                    </p>
                  </>
                )}
                
                <div className="grid grid-cols-3 gap-4 mb-8">
                  <div className="p-4 bg-blue-50 dark:bg-blue-950/30 rounded-xl border-2 border-blue-200 dark:border-blue-900">
                    <Target className="w-6 h-6 mx-auto mb-2 text-blue-500" />
                    <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{score}/5</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">Benar</p>
                  </div>
                  <div className="p-4 bg-green-50 dark:bg-green-950/30 rounded-xl border-2 border-green-200 dark:border-green-900">
                    <Trophy className="w-6 h-6 mx-auto mb-2 text-green-500" />
                    <p className="text-2xl font-bold text-green-600 dark:text-green-400">{score * 20}</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">Poin</p>
                  </div>
                  <div className="p-4 bg-purple-50 dark:bg-purple-950/30 rounded-xl border-2 border-purple-200 dark:border-purple-900">
                    <TrendingUp className="w-6 h-6 mx-auto mb-2 text-purple-500" />
                    <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">{((score/5)*100).toFixed(0)}%</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">Akurasi</p>
                  </div>
                </div>

                {wrongQuestions.length > 0 && (
                  <div className="mb-6 p-4 bg-orange-50 dark:bg-orange-950/30 rounded-xl border border-orange-200 dark:border-orange-800">
                    <Zap className="w-5 h-5 inline mr-2 text-orange-500" />
                    <span className="text-sm text-orange-700 dark:text-orange-300 font-medium">
                      {wrongQuestions.length} soal salah akan diprioritaskan di quiz berikutnya (Spaced Repetition)
                    </span>
                  </div>
                )}
                
                <div className="flex gap-3">
                  <Button
                    onClick={() => navigate("/dashboard")}
                    variant="outline"
                    className="flex-1"
                  >
                    Ke Dashboard
                  </Button>
                  <Button
                    onClick={() => window.location.reload()}
                    className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600"
                  >
                    Quiz Lagi
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 dark:from-slate-950 dark:via-blue-950 dark:to-slate-950">
      <Navbar />
      
      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          className="mb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 dark:from-blue-400 dark:to-blue-600 bg-clip-text text-transparent">
                Quiz Challenge
              </h1>
              <p className="text-slate-600 dark:text-slate-300">
                Adaptive Difficulty dengan Spaced Repetition
              </p>
            </div>
            <Badge className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-2 text-lg">
              <Clock className="w-4 h-4 mr-2 inline" />
              {currentQuestion + 1} / {questions.length}
            </Badge>
          </div>
          
          <Progress value={progress} className="h-3" />
        </motion.div>

        {/* Question Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="shadow-2xl border-2 border-blue-200 dark:border-blue-900">
              <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                    <Brain size={24} />
                  </div>
                  <div className="flex-1">
                    <span>Soal #{currentQuestion + 1}</span>
                    <Badge className="ml-3 bg-white/20 border-white/30">
                      {currentQ.difficulty === "easy" && "⭐ Mudah"}
                      {currentQ.difficulty === "medium" && "⭐⭐ Sedang"}
                      {currentQ.difficulty === "hard" && "⭐⭐⭐ Sulit"}
                    </Badge>
                  </div>
                </CardTitle>
              </CardHeader>
              
              <CardContent className="p-6 sm:p-8">
                <h3 className="text-xl sm:text-2xl font-bold mb-6 text-slate-800 dark:text-white leading-relaxed">
                  {currentQ.question}
                </h3>
                
                <div className="space-y-3">
                  {currentQ.options.map((option, index) => {
                    const isSelected = selectedAnswer === index;
                    const isCorrect = index === currentQ.correctAnswer;
                    const showCorrect = showResult && isCorrect;
                    const showWrong = showResult && isSelected && !isCorrect;
                    
                    return (
                      <motion.button
                        key={index}
                        onClick={() => handleAnswerSelect(index)}
                        disabled={showResult}
                        whileHover={{ scale: showResult ? 1 : 1.02 }}
                        whileTap={{ scale: showResult ? 1 : 0.98 }}
                        className={`w-full p-4 rounded-xl text-left transition-all border-2 ${
                          showCorrect
                            ? "bg-green-50 dark:bg-green-950/30 border-green-500 text-green-700 dark:text-green-300"
                            : showWrong
                            ? "bg-red-50 dark:bg-red-950/30 border-red-500 text-red-700 dark:text-red-300"
                            : isSelected
                            ? "bg-blue-50 dark:bg-blue-950/30 border-blue-500 text-blue-700 dark:text-blue-300"
                            : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-600 text-slate-700 dark:text-slate-300"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                            showCorrect
                              ? "bg-green-500 text-white"
                              : showWrong
                              ? "bg-red-500 text-white"
                              : isSelected
                              ? "bg-blue-500 text-white"
                              : "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400"
                          }`}>
                            {showCorrect ? (
                              <CheckCircle2 size={18} />
                            ) : showWrong ? (
                              <XCircle size={18} />
                            ) : (
                              String.fromCharCode(65 + index)
                            )}
                          </div>
                          <span className="flex-1 font-medium">{option}</span>
                        </div>
                      </motion.button>
                    );
                  })}
                </div>
                
                <div className="mt-8">
                  {!showResult ? (
                    <Button
                      onClick={handleSubmitAnswer}
                      disabled={selectedAnswer === null}
                      className="w-full h-14 text-lg bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-lg"
                    >
                      <CheckCircle2 className="mr-2" size={20} />
                      Submit Jawaban
                    </Button>
                  ) : (
                    <Button
                      onClick={handleNextQuestion}
                      className="w-full h-14 text-lg bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 shadow-lg"
                    >
                      {currentQuestion < questions.length - 1 ? (
                        <>
                          Soal Berikutnya
                          <ArrowRight className="ml-2" size={20} />
                        </>
                      ) : (
                        <>
                          Selesai Quiz
                          <Trophy className="ml-2" size={20} />
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* Info Box - Spaced Repetition */}
        <motion.div
          className="mt-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 dark:from-orange-950/20 dark:to-yellow-950/20 border-orange-200 dark:border-orange-800">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Zap className="w-5 h-5 text-orange-600 dark:text-orange-400 flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-semibold text-orange-800 dark:text-orange-300 mb-1">
                    💡 Adaptive Difficulty + Spaced Repetition
                  </p>
                  <p className="text-orange-700 dark:text-orange-400">
                    Soal yang pernah salah akan muncul lagi untuk meningkatkan retention! Sistem menyesuaikan kesulitan berdasarkan performa kamu.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
