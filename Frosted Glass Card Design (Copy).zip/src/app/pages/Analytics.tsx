import { useState } from 'react';
import { AppLayout } from '@/app/components/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  Clock,
  Target,
  Zap,
  Shield,
  Trophy,
  Download,
  Calendar,
  Brain,
  Lock,
  Unlock,
  AlertCircle,
  CheckCircle,
  BarChart3,
  Activity
} from 'lucide-react';
import { motion } from 'motion/react';
import { getUserStats, getFocusSessions } from '@/app/lib/store';

export function Analytics() {
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'all'>('week');
  const stats = getUserStats();
  const sessions = getFocusSessions();

  // Mock data for before/after comparison
  const beforeAfterData = [
    { metric: 'Focus Time', before: 2.3, after: 5.8, unit: 'jam/hari' },
    { metric: 'Distraction Events', before: 47, after: 12, unit: 'x/hari' },
    { metric: 'Task Completion', before: 3.2, after: 7.8, unit: 'tugas/hari' },
    { metric: 'Retention Rate', before: 23, after: 81, unit: '%' },
  ];

  // Daily focus time data
  const focusTimeData = [
    { day: 'Sen', hours: 4.5, target: 4 },
    { day: 'Sel', hours: 5.2, target: 4 },
    { day: 'Rab', hours: 3.8, target: 4 },
    { day: 'Kam', hours: 6.1, target: 4 },
    { day: 'Jum', hours: 5.5, target: 4 },
    { day: 'Sab', hours: 7.2, target: 4 },
    { day: 'Min', hours: 4.9, target: 4 },
  ];

  // Distraction frequency data
  const distractionData = [
    { time: '08:00', count: 2 },
    { time: '10:00', count: 5 },
    { time: '12:00', count: 8 },
    { time: '14:00', count: 12 },
    { time: '16:00', count: 7 },
    { time: '18:00', count: 4 },
    { time: '20:00', count: 3 },
  ];

  // Unlock attempts data
  const unlockData = [
    { date: 'Week 1', attempts: 15, successful: 8, failed: 7 },
    { date: 'Week 2', attempts: 12, successful: 9, failed: 3 },
    { date: 'Week 3', attempts: 8, successful: 7, failed: 1 },
    { date: 'Week 4', attempts: 5, successful: 5, failed: 0 },
  ];

  // App distribution data
  const appDistributionData = [
    { name: 'Instagram', value: 35, color: '#E1306C' },
    { name: 'TikTok', value: 25, color: '#000000' },
    { name: 'YouTube', value: 20, color: '#FF0000' },
    { name: 'WhatsApp', value: 12, color: '#25D366' },
    { name: 'Others', value: 8, color: '#6B7280' },
  ];

  // Quiz performance data
  const quizPerformanceData = [
    { subject: 'Kalkulus', attempted: 25, correct: 21, accuracy: 84 },
    { subject: 'Fisika', attempted: 18, correct: 16, accuracy: 89 },
    { subject: 'Pemrograman', attempted: 32, correct: 29, accuracy: 91 },
    { subject: 'Statistika', attempted: 15, correct: 12, accuracy: 80 },
  ];

  // Productivity trends
  const productivityTrends = [
    { month: 'Jan', productivity: 45, baseline: 35 },
    { month: 'Feb', productivity: 52, baseline: 35 },
    { month: 'Mar', productivity: 68, baseline: 35 },
    { month: 'Apr', productivity: 78, baseline: 35 },
    { month: 'Mei', productivity: 85, baseline: 35 },
  ];

  const handleExportCSV = () => {
    // Mock CSV export
    const csvData = [
      ['Metric', 'Value'],
      ['Total Focus Hours', stats.totalFocusMinutes / 60],
      ['Current Streak', stats.currentStreak],
      ['Total Points', stats.points],
      ['Sessions Completed', sessions.length],
    ];
    
    const csv = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `optifokus-analytics-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <AppLayout>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-purple-950">
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Analytics Dashboard
                </h1>
                <p className="text-gray-600 dark:text-gray-400">
                  Data-driven insights untuk produktivitas Anda
                </p>
              </div>
              <Button
                onClick={handleExportCSV}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white"
              >
                <Download className="mr-2 w-4 h-4" />
                Export CSV
              </Button>
            </div>

            {/* Time Range Selector */}
            <div className="flex gap-2">
              <Button
                variant={timeRange === 'week' ? 'default' : 'outline'}
                onClick={() => setTimeRange('week')}
                size="sm"
              >
                7 Hari
              </Button>
              <Button
                variant={timeRange === 'month' ? 'default' : 'outline'}
                onClick={() => setTimeRange('month')}
                size="sm"
              >
                30 Hari
              </Button>
              <Button
                variant={timeRange === 'all' ? 'default' : 'outline'}
                onClick={() => setTimeRange('all')}
                size="sm"
              >
                Semua
              </Button>
            </div>
          </motion.div>

          {/* Key Metrics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
          >
            <Card className="bg-gradient-to-br from-blue-500 to-cyan-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Clock className="w-8 h-8" />
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div className="text-3xl font-bold mb-1">
                  {(stats.totalFocusMinutes / 60).toFixed(1)}h
                </div>
                <div className="text-sm opacity-90">Total Focus Time</div>
                <div className="mt-2 text-xs opacity-75">
                  +152% vs baseline
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-500 to-emerald-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Target className="w-8 h-8" />
                  <TrendingDown className="w-5 h-5" />
                </div>
                <div className="text-3xl font-bold mb-1">
                  12x
                </div>
                <div className="text-sm opacity-90">Distraction Events</div>
                <div className="mt-2 text-xs opacity-75">
                  -74% reduction
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-500 to-pink-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Brain className="w-8 h-8" />
                  <CheckCircle className="w-5 h-5" />
                </div>
                <div className="text-3xl font-bold mb-1">
                  87%
                </div>
                <div className="text-sm opacity-90">Quiz Accuracy</div>
                <div className="mt-2 text-xs opacity-75">
                  +61% improvement
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500 to-red-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Trophy className="w-8 h-8" />
                  <Activity className="w-5 h-5" />
                </div>
                <div className="text-3xl font-bold mb-1">
                  {stats.currentStreak}
                </div>
                <div className="text-sm opacity-90">Day Streak</div>
                <div className="mt-2 text-xs opacity-75">
                  Keep it up!
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="bg-white/50 dark:bg-gray-900/50 backdrop-blur-lg">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="before-after">Before/After</TabsTrigger>
              <TabsTrigger value="distraction">Distraction</TabsTrigger>
              <TabsTrigger value="quiz">Quiz Performance</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              {/* Focus Time Trends */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-blue-600" />
                      Daily Focus Time (Last 7 Days)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={focusTimeData}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                        <XAxis dataKey="day" />
                        <YAxis label={{ value: 'Hours', angle: -90, position: 'insideLeft' }} />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="hours" fill="#3B82F6" name="Actual" />
                        <Bar dataKey="target" fill="#10B981" name="Target" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Productivity Trends */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-green-600" />
                      Productivity Trend (5 Months)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <AreaChart data={productivityTrends}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                        <XAxis dataKey="month" />
                        <YAxis label={{ value: 'Productivity Index', angle: -90, position: 'insideLeft' }} />
                        <Tooltip />
                        <Legend />
                        <Area 
                          type="monotone" 
                          dataKey="productivity" 
                          stroke="#8B5CF6" 
                          fill="url(#productivityGradient)" 
                          name="Your Progress"
                        />
                        <Area 
                          type="monotone" 
                          dataKey="baseline" 
                          stroke="#9CA3AF" 
                          fill="url(#baselineGradient)" 
                          name="Baseline"
                        />
                        <defs>
                          <linearGradient id="productivityGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.8}/>
                            <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0.1}/>
                          </linearGradient>
                          <linearGradient id="baselineGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#9CA3AF" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#9CA3AF" stopOpacity={0.05}/>
                          </linearGradient>
                        </defs>
                      </AreaChart>
                    </ResponsiveContainer>
                    <div className="mt-4 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <p className="text-sm text-green-700 dark:text-green-300">
                        📈 <strong>+143% productivity increase</strong> since using OptiFokus!
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Before/After Tab */}
            <TabsContent value="before-after" className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-purple-600" />
                      Before vs After OptiFokus
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {beforeAfterData.map((item, index) => {
                        const improvement = ((item.after - item.before) / item.before) * 100;
                        const isPositive = improvement > 0 && !item.metric.includes('Distraction');
                        const displayImprovement = item.metric.includes('Distraction') 
                          ? -improvement 
                          : improvement;

                        return (
                          <div key={index} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="font-medium text-gray-900 dark:text-white">
                                {item.metric}
                              </span>
                              <Badge className={isPositive ? 'bg-green-500' : 'bg-red-500'}>
                                {displayImprovement > 0 ? '+' : ''}{displayImprovement.toFixed(0)}%
                              </Badge>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                                <div className="text-xs text-red-600 dark:text-red-400 mb-1">Before</div>
                                <div className="text-2xl font-bold text-red-700 dark:text-red-300">
                                  {item.before} <span className="text-sm font-normal">{item.unit}</span>
                                </div>
                              </div>
                              <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                                <div className="text-xs text-green-600 dark:text-green-400 mb-1">After</div>
                                <div className="text-2xl font-bold text-green-700 dark:text-green-300">
                                  {item.after} <span className="text-sm font-normal">{item.unit}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-lg">
                      <h3 className="font-bold text-purple-900 dark:text-purple-300 mb-2">
                        🎯 Key Findings
                      </h3>
                      <ul className="space-y-1 text-sm text-gray-700 dark:text-gray-300">
                        <li>• Focus time meningkat <strong>152%</strong> dari baseline</li>
                        <li>• Distraksi berkurang <strong>74%</strong> secara signifikan</li>
                        <li>• Retention rate naik <strong>252%</strong> dengan contextual quiz</li>
                        <li>• Task completion meningkat <strong>144%</strong></li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Distraction Tab */}
            <TabsContent value="distraction" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Distraction Frequency */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                >
                  <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <AlertCircle className="w-5 h-5 text-orange-600" />
                        Distraction Frequency by Time
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={distractionData}>
                          <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                          <XAxis dataKey="time" />
                          <YAxis />
                          <Tooltip />
                          <Line 
                            type="monotone" 
                            dataKey="count" 
                            stroke="#F59E0B" 
                            strokeWidth={3}
                            name="Attempts"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-4">
                        Peak distraction: <strong>14:00 - 16:00</strong> (post-lunch dip)
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* App Distribution */}
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                >
                  <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-red-600" />
                        Most Blocked Apps
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={appDistributionData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {appDistributionData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Unlock Attempts Trend */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="lg:col-span-2"
                >
                  <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Unlock className="w-5 h-5 text-blue-600" />
                        Unlock Attempts Over Time
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={unlockData}>
                          <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="successful" stackId="a" fill="#10B981" name="Successful" />
                          <Bar dataKey="failed" stackId="a" fill="#EF4444" name="Failed" />
                        </BarChart>
                      </ResponsiveContainer>
                      <div className="mt-4 grid grid-cols-2 gap-4">
                        <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <CheckCircle className="w-4 h-4 text-green-600" />
                            <span className="text-sm font-medium text-green-700 dark:text-green-300">
                              Success Rate Improvement
                            </span>
                          </div>
                          <div className="text-2xl font-bold text-green-700 dark:text-green-300">
                            +64%
                          </div>
                        </div>
                        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <TrendingDown className="w-4 h-4 text-blue-600" />
                            <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                              Total Attempts Reduction
                            </span>
                          </div>
                          <div className="text-2xl font-bold text-blue-700 dark:text-blue-300">
                            -67%
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </TabsContent>

            {/* Quiz Performance Tab */}
            <TabsContent value="quiz" className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Brain className="w-5 h-5 text-purple-600" />
                      Quiz Performance by Subject
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {quizPerformanceData.map((subject, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-gray-900 dark:text-white">
                              {subject.subject}
                            </span>
                            <Badge className={subject.accuracy >= 85 ? 'bg-green-500' : 'bg-yellow-500'}>
                              {subject.accuracy}% Accuracy
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="flex-1">
                              <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{ width: `${subject.accuracy}%` }}
                                  transition={{ duration: 1, delay: index * 0.1 }}
                                  className="h-full bg-gradient-to-r from-purple-500 to-blue-500"
                                />
                              </div>
                            </div>
                            <span className="text-sm text-gray-600 dark:text-gray-400 min-w-[100px]">
                              {subject.correct}/{subject.attempted} correct
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-6 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                      <h3 className="font-bold text-purple-900 dark:text-purple-300 mb-2">
                        💡 Insights
                      </h3>
                      <ul className="space-y-1 text-sm text-gray-700 dark:text-gray-300">
                        <li>• Accuracy tertinggi: <strong>Pemrograman (91%)</strong></li>
                        <li>• Total quiz attempted: <strong>90 soal</strong></li>
                        <li>• Overall success rate: <strong>87%</strong></li>
                        <li>• Contextual learning meningkatkan retention <strong>3.8x</strong></li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AppLayout>
  );
}
