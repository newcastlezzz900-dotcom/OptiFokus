import { RouterProvider } from "react-router";
import { router } from "./routes.tsx";
import { Toaster } from "@/app/components/ui/sonner";
import { ThemeProvider } from "@/app/components/ThemeProvider";

export default function App() {
  return (
    <ThemeProvider>
      <RouterProvider router={router} />
      <Toaster />
    </ThemeProvider>
  );
}