/**
 * OptiFokus Research-Grade Data Store
 * PKM KC & PIMNAS 2025 - Scientific Data Collection System
 */

// ==================== STORAGE KEYS ====================
const RESEARCH_KEYS = {
  // Core tracking
  USER_RESEARCH_ID: "optifokus_research_id",
  EXPERIMENT_CONFIG: "optifokus_experiment_config",
  QUIZ_ATTEMPTS: "optifokus_quiz_attempts",
  DISTRACTION_EVENTS: "optifokus_distraction_events",
  LEARNING_PROGRESS: "optifokus_learning_progress",
  ADAPTIVE_DIFFICULTY: "optifokus_adaptive_difficulty",
  
  // Predictive model
  USAGE_PATTERNS: "optifokus_usage_patterns",
  DISTRACTION_PREDICTIONS: "optifokus_predictions",
  
  // Social accountability
  SOCIAL_SESSIONS: "optifokus_social_sessions",
  PEER_INFLUENCE: "optifokus_peer_influence",
  
  // Anti-gaming
  AUDIT_TRAIL: "optifokus_audit_trail",
  BEHAVIOR_FLAGS: "optifokus_behavior_flags",
  
  // Research export
  RESEARCH_METRICS: "optifokus_research_metrics",
  AB_TEST_GROUP: "optifokus_ab_group",
};

// ==================== TYPES ====================

export interface ResearchUserID {
  userId: string;
  cohort: "control" | "treatment_A" | "treatment_B";
  enrollmentDate: string;
  consentGiven: boolean;
  demographics: {
    age?: number;
    gender?: string;
    major?: string;
    semester?: number;
    gpa?: number;
  };
}

export interface ExperimentConfig {
  enabled: boolean;
  variant: "control" | "treatment_A" | "treatment_B";
  features: {
    ubcq: boolean; // Unlock-by-Contextual-Quiz
    adaptive: boolean; // Adaptive Difficulty
    pdd: boolean; // Predictive Distraction Detection
    ssa: boolean; // Silent Social Accountability
    ace: boolean; // Auto-Curriculum Extractor
  };
  startDate: string;
  endDate: string;
}

export interface QuizAttempt {
  id: string;
  timestamp: string;
  appAttempted: string;
  questionId: string;
  questionText: string;
  userAnswer: number;
  correctAnswer: number;
  isCorrect: boolean;
  responseTime: number; // milliseconds
  difficulty: "easy" | "medium" | "hard";
  adaptiveScore: number; // 0-1 confidence score
  materiSource: string;
  attemptNumber: number; // n-th attempt in session
}

export interface DistractionEvent {
  id: string;
  timestamp: string;
  eventType: "app_click" | "notification" | "tab_switch" | "manual_unlock";
  appName: string;
  wasBlocked: boolean;
  unlockMethod?: "quiz_success" | "quiz_fail" | "emergency" | "timeout";
  contextBefore: {
    focusMinutes: number;
    timeOfDay: string;
    dayOfWeek: string;
    recentActivity: string;
  };
  predicted: boolean; // Was this predicted by PDD?
  predictionAccuracy?: number;
}

export interface LearningProgress {
  materiId: string;
  materiName: string;
  totalQuestions: number;
  correctAnswers: number;
  averageResponseTime: number;
  difficultyDistribution: {
    easy: { attempts: number; correct: number };
    medium: { attempts: number; correct: number };
    hard: { attempts: number; correct: number };
  };
  masteryLevel: number; // 0-100
  lastStudied: string;
  spacedRepetitionDue?: string;
}

export interface AdaptiveDifficultyState {
  userId: string;
  currentDifficulty: number; // 0-1 (0=easy, 1=hard)
  performanceHistory: {
    timestamp: string;
    difficulty: number;
    success: boolean;
    responseTime: number;
  }[];
  adaptationRate: number; // How fast difficulty changes
  stabilityScore: number; // How stable is performance
  recommendedDifficulty: number;
}

export interface UsagePattern {
  timestamp: string;
  hourOfDay: number;
  dayOfWeek: number;
  duration: number;
  distractionCount: number;
  focusScore: number; // 0-100
  contextualFactors: {
    hasUpcomingDeadline: boolean;
    timeUntilDeadline?: number; // hours
    studyMaterial?: string;
    previousDayPerformance: number;
  };
}

export interface DistractionPrediction {
  timestamp: string;
  predictedTime: string; // When distraction likely to happen
  probability: number; // 0-1
  triggerFactors: string[]; // ["time_of_day", "notification_pattern", etc]
  preventionSuggested: boolean;
  preventionAccepted?: boolean;
  actualDistraction?: boolean; // For validation
}

export interface SocialSession {
  sessionId: string;
  startTime: string;
  endTime?: string;
  roomName: string;
  participants: {
    userId: string;
    joinTime: string;
    leaveTime?: string;
    focusDuration: number;
    distractions: number;
  }[];
  groupStreak: number;
  socialPressureEvents: {
    timestamp: string;
    eventType: "peer_success" | "peer_failure" | "group_milestone";
    impact: "positive" | "negative" | "neutral";
  }[];
}

export interface PeerInfluence {
  sessionId: string;
  peerUserId: string;
  influenceType: "success_motivate" | "failure_demotivate" | "milestone_inspire";
  timeAfterEvent: number; // minutes
  userBehaviorChange: "improved" | "declined" | "neutral";
  measurableEffect: number; // quantified change in focus score
}

export interface AuditTrailEvent {
  id: string;
  timestamp: string;
  eventType: 
    | "app_start"
    | "focus_start"
    | "focus_end"
    | "quiz_attempt"
    | "emergency_unlock"
    | "settings_change"
    | "data_export"
    | "suspicious_activity";
  userId: string;
  metadata: Record<string, any>;
  deviceInfo: {
    userAgent: string;
    screenResolution: string;
    timezone: string;
  };
  integrityHash: string; // For tamper detection
}

export interface BehaviorFlag {
  id: string;
  timestamp: string;
  flagType: 
    | "rapid_clicking" 
    | "answer_pattern" 
    | "timing_anomaly" 
    | "device_switch"
    | "external_help_suspected";
  severity: "low" | "medium" | "high";
  evidence: string[];
  autoDetected: boolean;
  resolved: boolean;
  resolutionNote?: string;
}

export interface ResearchMetrics {
  // Pre-study baseline
  baseline: {
    averageFocusTime: number;
    distractionsPerDay: number;
    taskCompletionRate: number;
    academicPerformance?: number;
    selfReportedFocus: number; // 1-10 scale
  };
  
  // During study
  current: {
    averageFocusTime: number;
    distractionsPerDay: number;
    taskCompletionRate: number;
    quizAccuracy: number;
    adaptiveDifficultyLevel: number;
  };
  
  // Calculated improvements
  improvements: {
    focusTimeChange: number; // percentage
    distractionReduction: number; // percentage
    taskCompletionImprovement: number;
    learningRetention: number; // based on quiz performance
  };
  
  // Statistical
  dataPoints: number;
  studyDays: number;
  complianceRate: number; // % of days with data
  lastUpdated: string;
}

// ==================== INITIALIZATION ====================

export const initResearchStore = () => {
  // Generate unique research ID
  if (!localStorage.getItem(RESEARCH_KEYS.USER_RESEARCH_ID)) {
    const researchId: ResearchUserID = {
      userId: `OPF_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      cohort: Math.random() < 0.33 ? "control" : Math.random() < 0.5 ? "treatment_A" : "treatment_B",
      enrollmentDate: new Date().toISOString(),
      consentGiven: false,
      demographics: {},
    };
    localStorage.setItem(RESEARCH_KEYS.USER_RESEARCH_ID, JSON.stringify(researchId));
  }

  // Initialize experiment config
  if (!localStorage.getItem(RESEARCH_KEYS.EXPERIMENT_CONFIG)) {
    const config: ExperimentConfig = {
      enabled: true,
      variant: "treatment_A",
      features: {
        ubcq: true,
        adaptive: true,
        pdd: true,
        ssa: true,
        ace: true,
      },
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
    };
    localStorage.setItem(RESEARCH_KEYS.EXPERIMENT_CONFIG, JSON.stringify(config));
  }

  // Initialize empty arrays
  const arrayKeys = [
    RESEARCH_KEYS.QUIZ_ATTEMPTS,
    RESEARCH_KEYS.DISTRACTION_EVENTS,
    RESEARCH_KEYS.LEARNING_PROGRESS,
    RESEARCH_KEYS.USAGE_PATTERNS,
    RESEARCH_KEYS.DISTRACTION_PREDICTIONS,
    RESEARCH_KEYS.SOCIAL_SESSIONS,
    RESEARCH_KEYS.AUDIT_TRAIL,
    RESEARCH_KEYS.BEHAVIOR_FLAGS,
  ];

  arrayKeys.forEach(key => {
    if (!localStorage.getItem(key)) {
      localStorage.setItem(key, JSON.stringify([]));
    }
  });

  // Initialize adaptive difficulty
  if (!localStorage.getItem(RESEARCH_KEYS.ADAPTIVE_DIFFICULTY)) {
    const adaptiveState: AdaptiveDifficultyState = {
      userId: getResearchUserId(),
      currentDifficulty: 0.5, // Start medium
      performanceHistory: [],
      adaptationRate: 0.1,
      stabilityScore: 1.0,
      recommendedDifficulty: 0.5,
    };
    localStorage.setItem(RESEARCH_KEYS.ADAPTIVE_DIFFICULTY, JSON.stringify(adaptiveState));
  }

  // Initialize research metrics
  if (!localStorage.getItem(RESEARCH_KEYS.RESEARCH_METRICS)) {
    const metrics: ResearchMetrics = {
      baseline: {
        averageFocusTime: 0,
        distractionsPerDay: 0,
        taskCompletionRate: 0,
        selfReportedFocus: 5,
      },
      current: {
        averageFocusTime: 0,
        distractionsPerDay: 0,
        taskCompletionRate: 0,
        quizAccuracy: 0,
        adaptiveDifficultyLevel: 0.5,
      },
      improvements: {
        focusTimeChange: 0,
        distractionReduction: 0,
        taskCompletionImprovement: 0,
        learningRetention: 0,
      },
      dataPoints: 0,
      studyDays: 0,
      complianceRate: 100,
      lastUpdated: new Date().toISOString(),
    };
    localStorage.setItem(RESEARCH_KEYS.RESEARCH_METRICS, JSON.stringify(metrics));
  }
};

// ==================== GETTERS ====================

export const getResearchUserId = (): string => {
  const data = localStorage.getItem(RESEARCH_KEYS.USER_RESEARCH_ID);
  if (!data) {
    initResearchStore();
    return getResearchUserId();
  }
  const parsed: ResearchUserID = JSON.parse(data);
  return parsed.userId;
};

export const getExperimentConfig = (): ExperimentConfig => {
  const data = localStorage.getItem(RESEARCH_KEYS.EXPERIMENT_CONFIG);
  return data ? JSON.parse(data) : null;
};

export const getQuizAttempts = (): QuizAttempt[] => {
  const data = localStorage.getItem(RESEARCH_KEYS.QUIZ_ATTEMPTS);
  return data ? JSON.parse(data) : [];
};

export const getDistractionEvents = (): DistractionEvent[] => {
  const data = localStorage.getItem(RESEARCH_KEYS.DISTRACTION_EVENTS);
  return data ? JSON.parse(data) : [];
};

export const getLearningProgress = (): LearningProgress[] => {
  const data = localStorage.getItem(RESEARCH_KEYS.LEARNING_PROGRESS);
  return data ? JSON.parse(data) : [];
};

export const getAdaptiveDifficulty = (): AdaptiveDifficultyState => {
  const data = localStorage.getItem(RESEARCH_KEYS.ADAPTIVE_DIFFICULTY);
  return data ? JSON.parse(data) : null;
};

export const getUsagePatterns = (): UsagePattern[] => {
  const data = localStorage.getItem(RESEARCH_KEYS.USAGE_PATTERNS);
  return data ? JSON.parse(data) : [];
};

export const getDistractionPredictions = (): DistractionPrediction[] => {
  const data = localStorage.getItem(RESEARCH_KEYS.DISTRACTION_PREDICTIONS);
  return data ? JSON.parse(data) : [];
};

export const getAuditTrail = (): AuditTrailEvent[] => {
  const data = localStorage.getItem(RESEARCH_KEYS.AUDIT_TRAIL);
  return data ? JSON.parse(data) : [];
};

export const getBehaviorFlags = (): BehaviorFlag[] => {
  const data = localStorage.getItem(RESEARCH_KEYS.BEHAVIOR_FLAGS);
  return data ? JSON.parse(data) : [];
};

export const getResearchMetrics = (): ResearchMetrics => {
  const data = localStorage.getItem(RESEARCH_KEYS.RESEARCH_METRICS);
  return data ? JSON.parse(data) : null;
};

// ==================== SETTERS ====================

export const logQuizAttempt = (attempt: Omit<QuizAttempt, "id">) => {
  const attempts = getQuizAttempts();
  const newAttempt: QuizAttempt = {
    ...attempt,
    id: `QA_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
  };
  attempts.push(newAttempt);
  localStorage.setItem(RESEARCH_KEYS.QUIZ_ATTEMPTS, JSON.stringify(attempts));
  
  // Update adaptive difficulty
  updateAdaptiveDifficulty(newAttempt.isCorrect, newAttempt.responseTime, newAttempt.difficulty);
  
  // Log to audit trail
  logAuditEvent({
    eventType: "quiz_attempt",
    metadata: {
      questionId: attempt.questionId,
      isCorrect: attempt.isCorrect,
      responseTime: attempt.responseTime,
    },
  });
};

export const logDistractionEvent = (event: Omit<DistractionEvent, "id">) => {
  const events = getDistractionEvents();
  const newEvent: DistractionEvent = {
    ...event,
    id: `DE_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
  };
  events.push(newEvent);
  localStorage.setItem(RESEARCH_KEYS.DISTRACTION_EVENTS, JSON.stringify(events));
  
  // Update usage patterns
  logUsagePattern(event);
  
  // Check for behavior flags
  checkBehaviorAnomaly(events);
};

export const updateLearningProgress = (materiId: string, isCorrect: boolean, responseTime: number, difficulty: string) => {
  const progress = getLearningProgress();
  let materiProgress = progress.find(p => p.materiId === materiId);
  
  if (!materiProgress) {
    materiProgress = {
      materiId,
      materiName: "Unknown",
      totalQuestions: 0,
      correctAnswers: 0,
      averageResponseTime: 0,
      difficultyDistribution: {
        easy: { attempts: 0, correct: 0 },
        medium: { attempts: 0, correct: 0 },
        hard: { attempts: 0, correct: 0 },
      },
      masteryLevel: 0,
      lastStudied: new Date().toISOString(),
    };
    progress.push(materiProgress);
  }
  
  // Update stats
  materiProgress.totalQuestions += 1;
  if (isCorrect) materiProgress.correctAnswers += 1;
  materiProgress.averageResponseTime = 
    (materiProgress.averageResponseTime * (materiProgress.totalQuestions - 1) + responseTime) / materiProgress.totalQuestions;
  
  // Update difficulty distribution
  const diffKey = difficulty as "easy" | "medium" | "hard";
  materiProgress.difficultyDistribution[diffKey].attempts += 1;
  if (isCorrect) materiProgress.difficultyDistribution[diffKey].correct += 1;
  
  // Calculate mastery level (0-100)
  const accuracy = materiProgress.correctAnswers / materiProgress.totalQuestions;
  const speedBonus = Math.max(0, 1 - (materiProgress.averageResponseTime / 30000)); // 30s baseline
  materiProgress.masteryLevel = Math.round((accuracy * 0.7 + speedBonus * 0.3) * 100);
  
  materiProgress.lastStudied = new Date().toISOString();
  
  localStorage.setItem(RESEARCH_KEYS.LEARNING_PROGRESS, JSON.stringify(progress));
};

export const updateAdaptiveDifficulty = (success: boolean, responseTime: number, currentDifficultyLevel: string) => {
  const state = getAdaptiveDifficulty();
  
  // Convert difficulty to number
  const difficultyMap = { easy: 0.3, medium: 0.5, hard: 0.8 };
  const numericDifficulty = difficultyMap[currentDifficultyLevel as keyof typeof difficultyMap] || 0.5;
  
  // Add to history
  state.performanceHistory.push({
    timestamp: new Date().toISOString(),
    difficulty: numericDifficulty,
    success,
    responseTime,
  });
  
  // Keep last 20 attempts
  if (state.performanceHistory.length > 20) {
    state.performanceHistory = state.performanceHistory.slice(-20);
  }
  
  // Calculate new difficulty using adaptive algorithm
  const recentPerformance = state.performanceHistory.slice(-5);
  const successRate = recentPerformance.filter(p => p.success).length / recentPerformance.length;
  const avgResponseTime = recentPerformance.reduce((sum, p) => sum + p.responseTime, 0) / recentPerformance.length;
  
  // Adaptive logic:
  // - If success rate > 80% and fast response -> increase difficulty
  // - If success rate < 40% -> decrease difficulty
  // - Otherwise, maintain
  let adjustment = 0;
  if (successRate > 0.8 && avgResponseTime < 15000) {
    adjustment = state.adaptationRate; // Increase
  } else if (successRate < 0.4) {
    adjustment = -state.adaptationRate; // Decrease
  }
  
  state.currentDifficulty = Math.max(0.1, Math.min(0.9, state.currentDifficulty + adjustment));
  state.recommendedDifficulty = state.currentDifficulty;
  
  // Calculate stability (variance of recent performance)
  const variance = recentPerformance.reduce((sum, p) => {
    return sum + Math.pow((p.success ? 1 : 0) - successRate, 2);
  }, 0) / recentPerformance.length;
  state.stabilityScore = Math.max(0, 1 - variance * 2);
  
  localStorage.setItem(RESEARCH_KEYS.ADAPTIVE_DIFFICULTY, JSON.stringify(state));
};

export const logUsagePattern = (event: DistractionEvent) => {
  const patterns = getUsagePatterns();
  const now = new Date();
  
  const pattern: UsagePattern = {
    timestamp: event.timestamp,
    hourOfDay: now.getHours(),
    dayOfWeek: now.getDay(),
    duration: event.contextBefore.focusMinutes,
    distractionCount: 1,
    focusScore: event.wasBlocked ? 80 : 40,
    contextualFactors: {
      hasUpcomingDeadline: false, // Would be calculated
      previousDayPerformance: 70, // Would be calculated
    },
  };
  
  patterns.push(pattern);
  
  // Keep last 100 patterns
  if (patterns.length > 100) {
    patterns.splice(0, patterns.length - 100);
  }
  
  localStorage.setItem(RESEARCH_KEYS.USAGE_PATTERNS, JSON.stringify(patterns));
};

export const predictDistraction = (): DistractionPrediction | null => {
  const patterns = getUsagePatterns();
  if (patterns.length < 10) return null; // Need data
  
  const now = new Date();
  const currentHour = now.getHours();
  const currentDay = now.getDay();
  
  // Analyze patterns
  const similarTimePatterns = patterns.filter(p => 
    Math.abs(p.hourOfDay - currentHour) <= 1 &&
    p.dayOfWeek === currentDay
  );
  
  if (similarTimePatterns.length === 0) return null;
  
  const avgDistractions = similarTimePatterns.reduce((sum, p) => sum + p.distractionCount, 0) / similarTimePatterns.length;
  const probability = Math.min(0.95, avgDistractions / 5); // Normalize
  
  if (probability < 0.3) return null; // Too low to predict
  
  const prediction: DistractionPrediction = {
    timestamp: now.toISOString(),
    predictedTime: new Date(now.getTime() + 15 * 60 * 1000).toISOString(), // 15 min ahead
    probability,
    triggerFactors: ["time_of_day", "historical_pattern"],
    preventionSuggested: probability > 0.6,
  };
  
  const predictions = getDistractionPredictions();
  predictions.push(prediction);
  localStorage.setItem(RESEARCH_KEYS.DISTRACTION_PREDICTIONS, JSON.stringify(predictions));
  
  return prediction;
};

export const logAuditEvent = (event: Omit<AuditTrailEvent, "id" | "timestamp" | "userId" | "deviceInfo" | "integrityHash">) => {
  const trail = getAuditTrail();
  
  const newEvent: AuditTrailEvent = {
    ...event,
    id: `AE_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: new Date().toISOString(),
    userId: getResearchUserId(),
    deviceInfo: {
      userAgent: navigator.userAgent,
      screenResolution: `${window.screen.width}x${window.screen.height}`,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    },
    integrityHash: btoa(JSON.stringify(event)), // Simple hash
  };
  
  trail.push(newEvent);
  
  // Keep last 1000 events
  if (trail.length > 1000) {
    trail.splice(0, trail.length - 1000);
  }
  
  localStorage.setItem(RESEARCH_KEYS.AUDIT_TRAIL, JSON.stringify(trail));
};

export const checkBehaviorAnomaly = (events: DistractionEvent[]) => {
  const recentEvents = events.slice(-10);
  const flags = getBehaviorFlags();
  
  // Check for rapid clicking (>5 events in 30 seconds)
  const last30s = recentEvents.filter(e => 
    Date.now() - new Date(e.timestamp).getTime() < 30000
  );
  
  if (last30s.length > 5) {
    const flag: BehaviorFlag = {
      id: `BF_${Date.now()}`,
      timestamp: new Date().toISOString(),
      flagType: "rapid_clicking",
      severity: "medium",
      evidence: [`${last30s.length} clicks in 30 seconds`],
      autoDetected: true,
      resolved: false,
    };
    flags.push(flag);
    localStorage.setItem(RESEARCH_KEYS.BEHAVIOR_FLAGS, JSON.stringify(flags));
  }
};

export const updateResearchMetrics = () => {
  const metrics = getResearchMetrics();
  const quizAttempts = getQuizAttempts();
  const distractions = getDistractionEvents();
  
  // Calculate current metrics
  const totalCorrect = quizAttempts.filter(q => q.isCorrect).length;
  const quizAccuracy = quizAttempts.length > 0 ? totalCorrect / quizAttempts.length : 0;
  
  const today = new Date().toISOString().split("T")[0];
  const todayDistractions = distractions.filter(d => d.timestamp.startsWith(today)).length;
  
  metrics.current.quizAccuracy = quizAccuracy * 100;
  metrics.current.distractionReduction = todayDistractions;
  metrics.dataPoints = quizAttempts.length + distractions.length;
  metrics.lastUpdated = new Date().toISOString();
  
  // Calculate improvements
  if (metrics.baseline.distractionsPerDay > 0) {
    metrics.improvements.distractionReduction = 
      ((metrics.baseline.distractionsPerDay - metrics.current.distractionsPerDay) / metrics.baseline.distractionsPerDay) * 100;
  }
  
  metrics.improvements.learningRetention = quizAccuracy * 100;
  
  localStorage.setItem(RESEARCH_KEYS.RESEARCH_METRICS, JSON.stringify(metrics));
};

// ==================== RESEARCH EXPORT ====================

export const exportResearchData = (): string => {
  const data = {
    userId: getResearchUserId(),
    exportDate: new Date().toISOString(),
    config: getExperimentConfig(),
    quizAttempts: getQuizAttempts(),
    distractionEvents: getDistractionEvents(),
    learningProgress: getLearningProgress(),
    adaptiveDifficulty: getAdaptiveDifficulty(),
    usagePatterns: getUsagePatterns(),
    predictions: getDistractionPredictions(),
    auditTrail: getAuditTrail(),
    behaviorFlags: getBehaviorFlags(),
    metrics: getResearchMetrics(),
  };
  
  return JSON.stringify(data, null, 2);
};

export const exportResearchCSV = (): string => {
  const quizAttempts = getQuizAttempts();
  
  let csv = "timestamp,app_attempted,is_correct,response_time,difficulty,adaptive_score\n";
  
  quizAttempts.forEach(attempt => {
    csv += `${attempt.timestamp},${attempt.appAttempted},${attempt.isCorrect},${attempt.responseTime},${attempt.difficulty},${attempt.adaptiveScore}\n`;
  });
  
  return csv;
};

// Initialize on import
initResearchStore();
