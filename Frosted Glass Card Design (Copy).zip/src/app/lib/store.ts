// Storage keys
const STORAGE_KEYS = {
  USER_STATS: "optifokus_user_stats",
  BLOCKED_APPS: "optifokus_blocked_apps",
  FOCUS_SESSIONS: "optifokus_focus_sessions",
  QUIZ_QUESTIONS: "optifokus_quiz_questions",
  MATERI: "optifokus_materi",
  SCHEDULES: "optifokus_schedules",
  USER_SETTINGS: "optifokus_user_settings",
  FIRST_USE_DATE: "optifokus_first_use_date",
  QUIZ_HISTORY: "optifokus_quiz_history", // NEW: untuk spaced repetition
  ACCOUNTABILITY_PARTNER: "optifokus_accountability_partner", // NEW
  STAKE_SESSIONS: "optifokus_stake_sessions", // NEW: loss aversion
};

// Types
export interface UserStats {
  points: number;
  streak: number;
  totalFocusMinutes: number;
  distractionsBlocked: number;
  meetings: number;
  lastActiveDate: string;
}

export interface BlockedApp {
  id: string;
  name: string;
  icon: string;
  isBlocked: boolean;
}

export interface FocusSession {
  id: string;
  date: string;
  duration: number;
  type: "focus" | "break";
}

export interface QuizQuestion {
  id: string;
  materiId: string;
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: "easy" | "medium" | "hard";
}

export interface Materi {
  id: string;
  name: string;
  description: string;
  fileName: string;
  uploadDate: string;
  quizCount: number;
}

export interface Schedule {
  id: string;
  mataPelajaran: string;
  hari: string;
  jamMulai: string;
  jamSelesai: string;
  ruangan?: string;
  dosen?: string;
  color: string;
  createdAt: string;
}

export interface UserSettings {
  notifications: boolean;
  soundEffects: boolean;
  autoBreak: boolean;
  breakDuration: number;
  dailyGoal: number;
  theme: "light" | "dark" | "system";
  language: "id" | "en";
  userName: string;
  userAvatar: string;
}

// NEW INTERFACES for PKM KC
export interface QuizHistory {
  questionId: string;
  date: string;
  correct: boolean;
}

export interface AccountabilityPartner {
  name: string;
  email: string;
  phone: string;
}

export interface StakeSession {
  id: string;
  points: number;
  date: string;
  success: boolean;
}

// Initialize storage
const initStorage = () => {
  if (!localStorage.getItem(STORAGE_KEYS.USER_STATS)) {
    const initialStats: UserStats = {
      points: 0,
      streak: 0,
      totalFocusMinutes: 0,
      distractionsBlocked: 0,
      meetings: 0,
      lastActiveDate: new Date().toISOString().split("T")[0],
    };
    localStorage.setItem(STORAGE_KEYS.USER_STATS, JSON.stringify(initialStats));
  }

  if (!localStorage.getItem(STORAGE_KEYS.BLOCKED_APPS)) {
    const defaultApps: BlockedApp[] = [
      { id: "1", name: "Instagram", icon: "📷", isBlocked: false },
      { id: "2", name: "TikTok", icon: "🎵", isBlocked: false },
      { id: "3", name: "YouTube", icon: "📺", isBlocked: false },
      { id: "4", name: "Twitter", icon: "🐦", isBlocked: false },
      { id: "5", name: "Facebook", icon: "👥", isBlocked: false },
      { id: "6", name: "WhatsApp", icon: "💬", isBlocked: false },
      { id: "7", name: "Games", icon: "🎮", isBlocked: false },
      { id: "8", name: "Netflix", icon: "🎬", isBlocked: false },
    ];
    localStorage.setItem(STORAGE_KEYS.BLOCKED_APPS, JSON.stringify(defaultApps));
  }

  if (!localStorage.getItem(STORAGE_KEYS.FOCUS_SESSIONS)) {
    localStorage.setItem(STORAGE_KEYS.FOCUS_SESSIONS, JSON.stringify([]));
  }

  if (!localStorage.getItem(STORAGE_KEYS.QUIZ_QUESTIONS)) {
    localStorage.setItem(STORAGE_KEYS.QUIZ_QUESTIONS, JSON.stringify([]));
  }

  if (!localStorage.getItem(STORAGE_KEYS.MATERI)) {
    localStorage.setItem(STORAGE_KEYS.MATERI, JSON.stringify([]));
  }

  if (!localStorage.getItem(STORAGE_KEYS.SCHEDULES)) {
    localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify([]));
  }

  if (!localStorage.getItem(STORAGE_KEYS.USER_SETTINGS)) {
    const defaultSettings: UserSettings = {
      notifications: true,
      soundEffects: true,
      autoBreak: true,
      breakDuration: 5,
      dailyGoal: 120,
      theme: "system",
      language: "id",
      userName: "Pengguna",
      userAvatar: "😊",
    };
    localStorage.setItem(STORAGE_KEYS.USER_SETTINGS, JSON.stringify(defaultSettings));
  }

  if (!localStorage.getItem(STORAGE_KEYS.FIRST_USE_DATE)) {
    localStorage.setItem(STORAGE_KEYS.FIRST_USE_DATE, new Date().toISOString());
  }

  if (!localStorage.getItem(STORAGE_KEYS.QUIZ_HISTORY)) {
    localStorage.setItem(STORAGE_KEYS.QUIZ_HISTORY, JSON.stringify([]));
  }

  if (!localStorage.getItem(STORAGE_KEYS.ACCOUNTABILITY_PARTNER)) {
    const defaultPartner: AccountabilityPartner = {
      name: "",
      email: "",
      phone: "",
    };
    localStorage.setItem(STORAGE_KEYS.ACCOUNTABILITY_PARTNER, JSON.stringify(defaultPartner));
  }

  if (!localStorage.getItem(STORAGE_KEYS.STAKE_SESSIONS)) {
    localStorage.setItem(STORAGE_KEYS.STAKE_SESSIONS, JSON.stringify([]));
  }
};

// Initialize on load
initStorage();

// User Stats Functions
export const getUserStats = (): UserStats => {
  const stats = localStorage.getItem(STORAGE_KEYS.USER_STATS);
  return stats ? JSON.parse(stats) : {
    points: 0,
    streak: 0,
    totalFocusMinutes: 0,
    distractionsBlocked: 0,
    meetings: 0,
    lastActiveDate: new Date().toISOString().split("T")[0],
  };
};

export const updateUserStats = (stats: Partial<UserStats>) => {
  const current = getUserStats();
  const updated = { ...current, ...stats };
  localStorage.setItem(STORAGE_KEYS.USER_STATS, JSON.stringify(updated));
};

export const addPoints = (points: number) => {
  const stats = getUserStats();
  stats.points += points;
  updateUserStats(stats);
};

export const incrementStreak = () => {
  const stats = getUserStats();
  const today = new Date().toISOString().split("T")[0];
  
  if (stats.lastActiveDate !== today) {
    stats.streak += 1;
    stats.lastActiveDate = today;
    updateUserStats(stats);
  }
};

export const addMeeting = () => {
  const stats = getUserStats();
  stats.meetings += 1;
  updateUserStats(stats);
};

// Blocked Apps Functions
export const getBlockedApps = (): BlockedApp[] => {
  const apps = localStorage.getItem(STORAGE_KEYS.BLOCKED_APPS);
  return apps ? JSON.parse(apps) : [];
};

export const updateBlockedApps = (apps: BlockedApp[]) => {
  localStorage.setItem(STORAGE_KEYS.BLOCKED_APPS, JSON.stringify(apps));
};

export const toggleAppBlock = (appId: string) => {
  const apps = getBlockedApps();
  const updated = apps.map((app) =>
    app.id === appId ? { ...app, isBlocked: !app.isBlocked } : app
  );
  updateBlockedApps(updated);
};

// Focus Sessions Functions
export const getFocusSessions = (): FocusSession[] => {
  const sessions = localStorage.getItem(STORAGE_KEYS.FOCUS_SESSIONS);
  return sessions ? JSON.parse(sessions) : [];
};

export const addFocusSession = (session: Omit<FocusSession, "id">) => {
  const sessions = getFocusSessions();
  const newSession: FocusSession = {
    ...session,
    id: Date.now().toString(),
  };
  sessions.push(newSession);
  localStorage.setItem(STORAGE_KEYS.FOCUS_SESSIONS, JSON.stringify(sessions));
};

// Quiz Functions
export const getQuizQuestions = (): QuizQuestion[] => {
  const questions = localStorage.getItem(STORAGE_KEYS.QUIZ_QUESTIONS);
  return questions ? JSON.parse(questions) : [];
};

export const addQuizQuestions = (questions: QuizQuestion[]) => {
  const existing = getQuizQuestions();
  const updated = [...existing, ...questions];
  localStorage.setItem(STORAGE_KEYS.QUIZ_QUESTIONS, JSON.stringify(updated));
};

export const generateMockQuiz = (materiId: string): QuizQuestion[] => {
  const mockQuestions: QuizQuestion[] = [
    {
      id: Date.now().toString(),
      materiId,
      question: "Apa definisi dari turunan dalam kalkulus?",
      options: [
        "Tingkat perubahan fungsi",
        "Integral fungsi",
        "Limit fungsi",
        "Fungsi invers"
      ],
      correctAnswer: 0,
      difficulty: "medium",
    },
    {
      id: (Date.now() + 1).toString(),
      materiId,
      question: "Berapa hasil dari d/dx (x²)?",
      options: ["x", "2x", "x²", "2"],
      correctAnswer: 1,
      difficulty: "easy",
    },
    {
      id: (Date.now() + 2).toString(),
      materiId,
      question: "Apa yang dimaksud dengan chain rule?",
      options: [
        "Aturan perkalian",
        "Aturan pembagian",
        "Aturan rantai untuk fungsi komposisi",
        "Aturan pangkat"
      ],
      correctAnswer: 2,
      difficulty: "medium",
    },
    {
      id: (Date.now() + 3).toString(),
      materiId,
      question: "Berapa turunan dari sin(x)?",
      options: ["cos(x)", "-cos(x)", "sin(x)", "-sin(x)"],
      correctAnswer: 0,
      difficulty: "easy",
    },
    {
      id: (Date.now() + 4).toString(),
      materiId,
      question: "Apa aplikasi turunan dalam kehidupan nyata?",
      options: [
        "Menghitung kecepatan",
        "Menghitung luas",
        "Menghitung volume",
        "Menghitung keliling"
      ],
      correctAnswer: 0,
      difficulty: "medium",
    },
  ];

  return mockQuestions;
};

export const getQuizHistory = (): QuizHistory[] => {
  const history = localStorage.getItem(STORAGE_KEYS.QUIZ_HISTORY);
  return history ? JSON.parse(history) : [];
};

export const addQuizHistory = (history: QuizHistory) => {
  const existing = getQuizHistory();
  const updated = [...existing, history];
  localStorage.setItem(STORAGE_KEYS.QUIZ_HISTORY, JSON.stringify(updated));
};

// Materi Functions
export const getMateri = (): Materi[] => {
  const materi = localStorage.getItem(STORAGE_KEYS.MATERI);
  return materi ? JSON.parse(materi) : [];
};

export const addMateri = (materi: Omit<Materi, "id" | "uploadDate">) => {
  const existing = getMateri();
  const newMateri: Materi = {
    ...materi,
    id: Date.now().toString(),
    uploadDate: new Date().toISOString(),
  };
  existing.push(newMateri);
  localStorage.setItem(STORAGE_KEYS.MATERI, JSON.stringify(existing));
  return newMateri;
};

// Schedule Functions
export const getSchedules = (): Schedule[] => {
  const schedules = localStorage.getItem(STORAGE_KEYS.SCHEDULES);
  return schedules ? JSON.parse(schedules) : [];
};

export const addSchedule = (schedule: Omit<Schedule, "id" | "createdAt">) => {
  const schedules = getSchedules();
  const newSchedule: Schedule = {
    ...schedule,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
  };
  schedules.push(newSchedule);
  localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(schedules));
  return newSchedule;
};

export const updateSchedule = (id: string, schedule: Partial<Schedule>) => {
  const schedules = getSchedules();
  const updated = schedules.map((s) =>
    s.id === id ? { ...s, ...schedule } : s
  );
  localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(updated));
};

export const deleteSchedule = (id: string) => {
  const schedules = getSchedules();
  const filtered = schedules.filter((s) => s.id !== id);
  localStorage.setItem(STORAGE_KEYS.SCHEDULES, JSON.stringify(filtered));
};

// User Settings Functions
export const getUserSettings = (): UserSettings => {
  const settings = localStorage.getItem(STORAGE_KEYS.USER_SETTINGS);
  return settings ? JSON.parse(settings) : {
    notifications: true,
    soundEffects: true,
    autoBreak: true,
    breakDuration: 5,
    dailyGoal: 120,
    theme: "system",
    language: "id",
    userName: "Pengguna",
    userAvatar: "😊",
  };
};

export const updateUserSettings = (settings: Partial<UserSettings>) => {
  const current = getUserSettings();
  const updated = { ...current, ...settings };
  localStorage.setItem(STORAGE_KEYS.USER_SETTINGS, JSON.stringify(updated));
};

// Get usage duration
export const getUsageDuration = (): "new" | "intermediate" | "veteran" => {
  const firstUse = localStorage.getItem(STORAGE_KEYS.FIRST_USE_DATE);
  if (!firstUse) return "new";

  const firstUseDate = new Date(firstUse);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - firstUseDate.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 30) return "new"; // < 1 bulan = merah
  if (diffDays < 365) return "intermediate"; // 1-12 bulan = kuning
  return "veteran"; // > 1 tahun = hijau
};

export const getUserBadgeColor = (): string => {
  const duration = getUsageDuration();
  if (duration === "new") return "bg-red-500";
  if (duration === "intermediate") return "bg-yellow-500";
  return "bg-green-500";
};

export const getUserBadgeLabel = (): string => {
  const duration = getUsageDuration();
  if (duration === "new") return "Pemula";
  if (duration === "intermediate") return "Berkembang";
  return "Veteran";
};

// Accountability Partner Functions
export const getAccountabilityPartner = (): AccountabilityPartner => {
  const partner = localStorage.getItem(STORAGE_KEYS.ACCOUNTABILITY_PARTNER);
  return partner ? JSON.parse(partner) : {
    name: "",
    email: "",
    phone: "",
  };
};

export const updateAccountabilityPartner = (partner: Partial<AccountabilityPartner>) => {
  const current = getAccountabilityPartner();
  const updated = { ...current, ...partner };
  localStorage.setItem(STORAGE_KEYS.ACCOUNTABILITY_PARTNER, JSON.stringify(updated));
};

// Stake Sessions Functions
export const getStakeSessions = (): StakeSession[] => {
  const sessions = localStorage.getItem(STORAGE_KEYS.STAKE_SESSIONS);
  return sessions ? JSON.parse(sessions) : [];
};

export const addStakeSession = (session: Omit<StakeSession, "id">) => {
  const sessions = getStakeSessions();
  const newSession: StakeSession = {
    ...session,
    id: Date.now().toString(),
  };
  sessions.push(newSession);
  localStorage.setItem(STORAGE_KEYS.STAKE_SESSIONS, JSON.stringify(sessions));
};

export const updateStakeSession = (id: string, session: Partial<StakeSession>) => {
  const sessions = getStakeSessions();
  const updated = sessions.map((s) =>
    s.id === id ? { ...s, ...session } : s
  );
  localStorage.setItem(STORAGE_KEYS.STAKE_SESSIONS, JSON.stringify(updated));
};

export const deleteStakeSession = (id: string) => {
  const sessions = getStakeSessions();
  const filtered = sessions.filter((s) => s.id !== id);
  localStorage.setItem(STORAGE_KEYS.STAKE_SESSIONS, JSON.stringify(filtered));
};