import { motion } from "motion/react";
import { Sparkles, Flame, Zap, Crown, Star } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";

interface AvatarEvolutionProps {
  streak: number;
  onCustomize?: (customization: AvatarCustomization) => void;
}

export interface AvatarCustomization {
  accessory?: string;
  color?: string;
  effect?: string;
}

// Streak thresholds: 5,10,20,30,40,60,100, lalu per 100
const getStreakTier = (streak: number): number => {
  if (streak < 5) return 0;
  if (streak < 10) return 1;
  if (streak < 20) return 2;
  if (streak < 30) return 3;
  if (streak < 40) return 4;
  if (streak < 60) return 5;
  if (streak < 100) return 6;
  // Setelah 100, setiap 100 streak = 1 tier
  return 6 + Math.floor((streak - 100) / 100) + 1;
};

const getNextStreakThreshold = (streak: number): number => {
  if (streak < 5) return 5;
  if (streak < 10) return 10;
  if (streak < 20) return 20;
  if (streak < 30) return 30;
  if (streak < 40) return 40;
  if (streak < 60) return 60;
  if (streak < 100) return 100;
  // Setelah 100, next adalah kelipatan 100
  return Math.ceil((streak + 1) / 100) * 100;
};

const getAvatarData = (tier: number) => {
  const avatars = [
    {
      name: "Telur Awal",
      emoji: "🥚",
      color: "#94a3b8",
      size: 60,
      description: "Baru mulai journey fokus",
      unlocks: ["Hanya avatar dasar"],
    },
    {
      name: "Telur Berapi 🔥",
      emoji: "🔥",
      color: "#f97316",
      size: 70,
      description: "5 hari streak - Api mulai menyala!",
      unlocks: ["Warna api merah", "Efek percikan"],
    },
    {
      name: "Api Membara 🔥🔥",
      emoji: "🔥",
      color: "#ea580c",
      size: 80,
      description: "10 hari - Api semakin besar!",
      unlocks: ["Warna api orange", "Efek asap", "Frame sederhana"],
    },
    {
      name: "Phoenix Muda 🦅",
      emoji: "🦅",
      color: "#dc2626",
      size: 90,
      description: "20 hari - Burung phoenix muncul!",
      unlocks: ["Warna phoenix", "Sayap api", "Frame emas"],
    },
    {
      name: "Phoenix Alpha 🦅✨",
      emoji: "🦅",
      color: "#b91c1c",
      size: 100,
      description: "30 hari - Phoenix dewasa!",
      unlocks: ["Warna phoenix premium", "Aura emas", "Crown sederhana", "Background custom"],
    },
    {
      name: "Phoenix Supreme 👑",
      emoji: "👑",
      color: "#991b1b",
      size: 110,
      description: "40 hari - Raja Phoenix!",
      unlocks: ["Semua warna premium", "Crown emas", "Aura rainbow", "Partikel bintang"],
    },
    {
      name: "Phoenix Legendary ⭐",
      emoji: "⭐",
      color: "#7c2d12",
      size: 120,
      description: "60 hari - Legenda dimulai!",
      unlocks: ["Full customization", "Efek petir", "Multiple accessories", "Animated background"],
    },
    {
      name: "Phoenix Ultimate 💎",
      emoji: "💎",
      color: "#78350f",
      size: 130,
      description: "100+ hari - Pencapaian tertinggi!",
      unlocks: ["Ultimate customization", "Semua efek", "Exclusive items", "Mythical aura"],
    },
  ];

  return avatars[Math.min(tier, avatars.length - 1)];
};

export function AvatarEvolutionNew({ streak, onCustomize }: AvatarEvolutionProps) {
  const [showCustomize, setShowCustomize] = useState(false);
  const [customization, setCustomization] = useState<AvatarCustomization>({
    accessory: "none",
    color: "default",
    effect: "none",
  });

  const tier = getStreakTier(streak);
  const avatar = getAvatarData(tier);
  
  // Safety check - should never happen but prevents crash
  if (!avatar) {
    return null;
  }
  
  const nextThreshold = getNextStreakThreshold(streak);
  const progress = tier === 0 
    ? (streak / nextThreshold) * 100
    : ((streak - (tier >= 7 ? 100 + (tier - 7) * 100 : [0, 5, 10, 20, 30, 40, 60][tier])) / 
       (nextThreshold - (tier >= 7 ? 100 + (tier - 7) * 100 : [0, 5, 10, 20, 30, 40, 60][tier]))) * 100;

  const canCustomize = tier >= 1; // Mulai bisa customize dari tier 1 (streak 5)

  return (
    <div className="relative">
      <div className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/30 dark:to-red-950/30 rounded-2xl p-6 sm:p-8 text-center border-2 border-orange-200 dark:border-orange-800">
        {/* Avatar Container */}
        <motion.div
          className="relative inline-block mb-4"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", duration: 0.6 }}
        >
          {/* Glow Effect */}
          <motion.div
            className="absolute inset-0 rounded-full blur-2xl opacity-50"
            style={{ backgroundColor: avatar.color }}
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />

          {/* Main Avatar Circle */}
          <motion.div
            className="relative rounded-full flex items-center justify-center"
            style={{
              width: avatar.size,
              height: avatar.size,
              backgroundColor: avatar.color,
              boxShadow: `0 10px 40px ${avatar.color}80`,
            }}
            whileHover={{ scale: 1.1 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <span className="text-4xl sm:text-5xl">{avatar.emoji}</span>
          </motion.div>

          {/* Flame effects for streak */}
          {streak >= 5 && (
            <motion.div
              className="absolute -top-2 -right-2"
              animate={{
                y: [0, -5, 0],
                rotate: [0, 10, -10, 0],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
              }}
            >
              <Flame className="text-orange-500" size={24} fill="currentColor" />
            </motion.div>
          )}

          {/* Sparkles for higher tiers */}
          {tier >= 4 && (
            <>
              <motion.div
                className="absolute -top-3 -left-3"
                animate={{
                  rotate: 360,
                  scale: [1, 1.3, 1],
                }}
                transition={{
                  rotate: { duration: 3, repeat: Infinity, ease: "linear" },
                  scale: { duration: 1.5, repeat: Infinity },
                }}
              >
                <Sparkles className="text-yellow-400" size={20} />
              </motion.div>
              <motion.div
                className="absolute -bottom-3 -right-3"
                animate={{
                  rotate: -360,
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  rotate: { duration: 4, repeat: Infinity, ease: "linear" },
                  scale: { duration: 2, repeat: Infinity },
                }}
              >
                <Star className="text-yellow-300" size={18} fill="currentColor" />
              </motion.div>
            </>
          )}

          {/* Crown for highest tiers */}
          {tier >= 6 && (
            <motion.div
              className="absolute -top-6 left-1/2 transform -translate-x-1/2"
              animate={{
                y: [0, -3, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
              }}
            >
              <Crown className="text-yellow-500" size={28} fill="currentColor" />
            </motion.div>
          )}
        </motion.div>

        {/* Avatar Info */}
        <motion.div
          className="space-y-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div>
            <h3 className="text-xl sm:text-2xl font-bold" style={{ color: avatar.color }}>
              {avatar.name}
            </h3>
            <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1">
              {avatar.description}
            </p>
          </div>
          
          <div className="flex flex-wrap items-center justify-center gap-2">
            <span className="bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-300 px-3 py-1 rounded-full text-xs sm:text-sm font-semibold flex items-center gap-1">
              <Flame size={14} />
              {streak} Hari Streak
            </span>
            <span className="bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 px-3 py-1 rounded-full text-xs sm:text-sm">
              Tier {tier}
            </span>
          </div>

          {/* Customize Button */}
          {canCustomize && (
            <Button
              size="sm"
              onClick={() => setShowCustomize(true)}
              className="mt-2"
              variant="outline"
            >
              <Sparkles size={14} className="mr-1" />
              Customize Avatar
            </Button>
          )}
        </motion.div>

        {/* Progress to Next Tier */}
        {tier < 7 || streak < nextThreshold ? (
          <motion.div
            className="mt-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <div className="flex items-center justify-between text-xs text-gray-600 dark:text-gray-400 mb-2">
              <span>Next tier</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-orange-500 to-red-500"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
              {nextThreshold - streak} hari lagi untuk tier berikutnya
            </p>
          </motion.div>
        ) : (
          <motion.div
            className="mt-4 text-yellow-600 dark:text-yellow-400 font-bold text-sm"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            ⭐ MAX TIER UNLOCKED! ⭐
          </motion.div>
        )}

        {/* Unlocks */}
        <div className="mt-4 p-3 bg-white/50 dark:bg-black/20 rounded-lg">
          <p className="text-xs font-semibold text-gray-700 dark:text-gray-300 mb-2">🔓 Unlocked Features:</p>
          <div className="flex flex-wrap gap-1 justify-center">
            {avatar.unlocks.map((unlock, i) => (
              <span
                key={i}
                className="text-xs bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 px-2 py-1 rounded"
              >
                {unlock}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Customization Dialog */}
      <Dialog open={showCustomize} onOpenChange={setShowCustomize}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Customize Avatar 🎨</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Accessory</label>
              <div className="grid grid-cols-3 gap-2">
                {tier >= 1 && (
                  <button className="p-3 border-2 rounded-lg hover:border-blue-500 transition">
                    🔥 Fire
                  </button>
                )}
                {tier >= 3 && (
                  <button className="p-3 border-2 rounded-lg hover:border-blue-500 transition">
                    👑 Crown
                  </button>
                )}
                {tier >= 5 && (
                  <button className="p-3 border-2 rounded-lg hover:border-blue-500 transition">
                    ⚡ Lightning
                  </button>
                )}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Color Theme</label>
              <div className="grid grid-cols-4 gap-2">
                {tier >= 2 && (
                  <>
                    <button className="w-full h-10 rounded-lg bg-gradient-to-br from-red-500 to-orange-500" />
                    <button className="w-full h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-500" />
                  </>
                )}
                {tier >= 4 && (
                  <>
                    <button className="w-full h-10 rounded-lg bg-gradient-to-br from-green-500 to-teal-500" />
                    <button className="w-full h-10 rounded-lg bg-gradient-to-br from-yellow-500 to-pink-500" />
                  </>
                )}
              </div>
            </div>

            <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
              💡 Unlock lebih banyak customization dengan meningkatkan streak!
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}