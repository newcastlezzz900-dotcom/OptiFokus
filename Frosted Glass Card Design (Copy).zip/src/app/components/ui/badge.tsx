import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "./utils";

const badgeVariants = cva(
  "inline-flex items-center justify-center rounded-full border px-3 py-1 text-xs font-semibold w-fit whitespace-nowrap shrink-0 [&>svg]:size-3 gap-1.5 [&>svg]:pointer-events-none shadow-sm transition-all",
  {
    variants: {
      variant: {
        default:
          "border-transparent bg-gradient-to-r from-[hsl(237_92%_62%)] to-[hsl(250_70%_55%)] text-white dark:from-[hsl(237_92%_68%)] dark:to-[hsl(250_80%_62%)]",
        secondary:
          "border-transparent bg-gradient-to-r from-[hsl(195_100%_60%)] to-[hsl(180_100%_40%)] text-white dark:from-[hsl(195_100%_65%)] dark:to-[hsl(180_100%_45%)]",
        destructive:
          "border-transparent bg-gradient-to-r from-[hsl(355_85%_58%)] to-[hsl(355_85%_48%)] text-white",
        success:
          "border-transparent bg-gradient-to-r from-[hsl(145_70%_50%)] to-[hsl(145_70%_40%)] text-white",
        warning:
          "border-transparent bg-gradient-to-r from-[hsl(35_100%_55%)] to-[hsl(35_100%_45%)] text-white",
        outline:
          "border-2 border-[hsl(var(--border))] bg-transparent text-[hsl(var(--foreground))]",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

const Badge = React.forwardRef<
  HTMLSpanElement,
  React.ComponentPropsWithoutRef<"span"> &
    VariantProps<typeof badgeVariants> & { asChild?: boolean }
>(({ className, variant, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "span";

  return (
    <Comp
      ref={ref}
      data-slot="badge"
      className={cn(badgeVariants({ variant }), className)}
      {...props}
    />
  );
});
Badge.displayName = "Badge";

export { Badge, badgeVariants };