import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "./utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-semibold transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:ring-2 focus-visible:ring-offset-2 active:scale-[0.98]",
  {
    variants: {
      variant: {
        default:
          "bg-gradient-to-r from-[hsl(237_92%_62%)] to-[hsl(250_70%_55%)] text-white hover:from-[hsl(237_92%_58%)] hover:to-[hsl(250_70%_51%)] shadow-md hover:shadow-lg dark:from-[hsl(237_92%_68%)] dark:to-[hsl(250_80%_62%)]",
        destructive:
          "bg-gradient-to-r from-[hsl(355_85%_58%)] to-[hsl(355_85%_48%)] text-white hover:from-[hsl(355_85%_54%)] hover:to-[hsl(355_85%_44%)] shadow-md hover:shadow-lg",
        outline:
          "border-2 border-[hsl(var(--border))] bg-transparent hover:bg-[hsl(var(--accent)_/_0.1)] hover:border-[hsl(var(--primary))]",
        secondary:
          "bg-gradient-to-r from-[hsl(195_100%_60%)] to-[hsl(180_100%_40%)] text-white hover:from-[hsl(195_100%_56%)] hover:to-[hsl(180_100%_36%)] shadow-md hover:shadow-lg dark:from-[hsl(195_100%_65%)] dark:to-[hsl(180_100%_45%)]",
        ghost:
          "hover:bg-[hsl(var(--accent)_/_0.15)] hover:text-[hsl(var(--primary))]",
        link: "text-[hsl(var(--primary))] underline-offset-4 hover:underline",
        success:
          "bg-gradient-to-r from-[hsl(145_70%_50%)] to-[hsl(145_70%_40%)] text-white hover:from-[hsl(145_70%_46%)] hover:to-[hsl(145_70%_36%)] shadow-md hover:shadow-lg",
        warning:
          "bg-gradient-to-r from-[hsl(35_100%_55%)] to-[hsl(35_100%_45%)] text-white hover:from-[hsl(35_100%_51%)] hover:to-[hsl(35_100%_41%)] shadow-md hover:shadow-lg",
      },
      size: {
        default: "h-10 px-5 py-2.5 has-[>svg]:px-4",
        sm: "h-9 rounded-lg gap-1.5 px-3.5 has-[>svg]:px-3 text-xs",
        lg: "h-12 rounded-lg px-7 has-[>svg]:px-5 text-base",
        icon: "size-10 rounded-lg",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

const Button = React.forwardRef<
  HTMLButtonElement,
  React.ComponentPropsWithoutRef<"button"> &
    VariantProps<typeof buttonVariants> & {
      asChild?: boolean;
    }
>(({ className, variant, size, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button";

  return (
    <Comp
      ref={ref}
      data-slot="button"
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  );
});
Button.displayName = "Button";

export { Button, buttonVariants };