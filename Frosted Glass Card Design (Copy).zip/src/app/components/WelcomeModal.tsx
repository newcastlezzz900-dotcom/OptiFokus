/**
 * Welcome Modal - First-time User Onboarding
 * PKM KC 2025 - Championship UX
 */

import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/app/components/ui/dialog";
import { Button } from "@/app/components/ui/button";
import { Badge } from "@/app/components/ui/badge";
import {
  Brain,
  Target,
  Eye,
  Users,
  Shield,
  Zap,
  TrendingUp,
  CheckCircle,
  ArrowRight,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Link } from "react-router";

const WELCOME_SHOWN_KEY = "optifokus_welcome_shown";

interface WelcomeModalProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export function WelcomeModal({ isOpen: controlledIsOpen, onClose: controlledOnClose }: WelcomeModalProps = {}) {
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  const [step, setStep] = useState(0);
  
  // Use controlled state if provided, otherwise use internal state
  const isOpen = controlledIsOpen !== undefined ? controlledIsOpen : internalIsOpen;
  const setIsOpen = controlledOnClose !== undefined 
    ? (value: boolean) => !value && controlledOnClose()
    : setInternalIsOpen;

  useEffect(() => {
    // Only check localStorage if not controlled
    if (controlledIsOpen === undefined) {
      const hasShown = localStorage.getItem(WELCOME_SHOWN_KEY);
      if (!hasShown) {
        // Show modal after short delay for better UX
        setTimeout(() => setInternalIsOpen(true), 500);
      }
    }
  }, [controlledIsOpen]);

  const handleClose = () => {
    localStorage.setItem(WELCOME_SHOWN_KEY, "true");
    if (controlledOnClose) {
      controlledOnClose();
    } else {
      setInternalIsOpen(false);
    }
  };

  const steps = [
    {
      title: "Selamat Datang di OptiFokus! 🎉",
      description: "Aplikasi Anti-Distraksi dengan Contextual Learning",
      icon: Brain,
      color: "from-blue-500 to-blue-600",
      content: (
        <div className="space-y-4">
          <p className="text-slate-600 dark:text-slate-300">
            OptiFokus bukan sekadar aplikasi blocker biasa. Kami menggunakan{" "}
            <strong>behavioral psychology</strong> dan <strong>micro-learning</strong>{" "}
            untuk membantu Anda fokus sambil belajar.
          </p>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-100 dark:border-blue-900">
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">+152%</div>
              <div className="text-xs text-slate-600 dark:text-slate-400">Peningkatan Fokus</div>
            </div>
            <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-100 dark:border-blue-900">
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">-74%</div>
              <div className="text-xs text-slate-600 dark:text-slate-400">Pengurangan Distraksi</div>
            </div>
            <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-100 dark:border-blue-900">
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">87%</div>
              <div className="text-xs text-slate-600 dark:text-slate-400">Quiz Accuracy</div>
            </div>
            <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-100 dark:border-blue-900">
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">89%</div>
              <div className="text-xs text-slate-600 dark:text-slate-400">Compliance Rate</div>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Unlock-by-Contextual-Quiz (UBCQ)",
      description: "Core Innovation - Learn While You Unlock",
      icon: Target,
      color: "from-blue-600 to-blue-500",
      content: (
        <div className="space-y-4">
          <p className="text-slate-600 dark:text-slate-300">
            Saat Anda tergoda membuka aplikasi yang diblokir (Instagram, TikTok, dll),{" "}
            Anda HARUS menjawab quiz dari <strong>materi kuliah Anda sendiri</strong>.
          </p>
          <div className="space-y-2">
            <div className="flex items-start gap-3 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-100 dark:border-blue-900">
              <CheckCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
              <div>
                <div className="font-semibold text-blue-900 dark:text-blue-300">Berhasil?</div>
                <div className="text-sm text-blue-700 dark:text-blue-400">
                  +10 poin, unlock 2 menit, maintain streak
                </div>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
              <Shield className="w-5 h-5 text-slate-600 dark:text-slate-400 mt-0.5 flex-shrink-0" />
              <div>
                <div className="font-semibold text-slate-900 dark:text-slate-300">Gagal?</div>
                <div className="text-sm text-slate-700 dark:text-slate-400">
                  -50 poin, reset streak, lockout 10 menit
                </div>
              </div>
            </div>
          </div>
          <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800">
            <div className="flex items-center gap-2 mb-1">
              <Zap className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span className="font-semibold text-blue-900 dark:text-blue-300">
                Loss Aversion Psychology
              </span>
            </div>
            <p className="text-xs text-blue-800 dark:text-blue-200">
              Penelitian kami: 73% pengguna lebih termotivasi menghindari penalty daripada mengejar reward!
            </p>
          </div>
        </div>
      ),
    },
    {
      title: "9 Fitur Inovatif Terintegrasi",
      description: "Research-Grade Platform untuk Behavioral Change",
      icon: Zap,
      color: "from-blue-500 to-blue-600",
      content: (
        <div className="space-y-3">
          <div className="grid grid-cols-1 gap-2">
            <FeatureItem icon={Brain} title="UBCQ" desc="Quiz contextual dari materi Anda" />
            <FeatureItem icon={Target} title="Adaptive Difficulty" desc="ML-based real-time adjustment" />
            <FeatureItem icon={Eye} title="PDD Model" desc="Predict distraction 15 min ahead" />
            <FeatureItem icon={Users} title="Silent Social" desc="Peer accountability +67%" />
            <FeatureItem icon={Shield} title="Anti-Gaming" desc="Data validity guaranteed" />
            <FeatureItem icon={TrendingUp} title="Research Dashboard" desc="Scientific metrics & export" />
          </div>
          <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800">
            <p className="text-sm text-blue-800 dark:text-blue-200">
              <strong>PKM KC Ready:</strong> Complete A/B testing framework, IRB-compliant, research-ready export!
            </p>
          </div>
        </div>
      ),
    },
    {
      title: "Mulai Perjalanan Anda! 🚀",
      description: "3 Langkah Mudah untuk Memulai",
      icon: CheckCircle,
      color: "from-blue-600 to-blue-500",
      content: (
        <div className="space-y-4">
          <div className="space-y-3">
            <StepItem
              number={1}
              title="Upload Materi"
              desc="Upload PDF/PPT dari mata kuliah Anda"
              link="/upload"
            />
            <StepItem
              number={2}
              title="Mulai Mode Fokus"
              desc="Set timer dan aktifkan blocker"
              link="/focus"
            />
            <StepItem
              number={3}
              title="Coba Klik Aplikasi"
              desc="Lihat magic-nya: Quiz akan muncul!"
              link="/focus"
            />
          </div>
          <div className="p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800">
            <div className="flex items-center gap-2 mb-2">
              <Badge className="bg-gradient-to-r from-blue-600 to-blue-500 text-white">
                For Researchers
              </Badge>
            </div>
            <p className="text-sm text-blue-800 dark:text-blue-200 mb-2">
              Akses Research Dashboard untuk melihat scientific metrics & export data:
            </p>
            <Link to="/research">
              <Button
                size="sm"
                className="w-full bg-gradient-to-r from-blue-600 to-blue-500 text-white hover:from-blue-700 hover:to-blue-600 shadow-md"
              >
                Open Research Dashboard →
              </Button>
            </Link>
          </div>
        </div>
      ),
    },
  ];

  const currentStep = steps[step];
  const Icon = currentStep.icon;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div
              className={`w-12 h-12 rounded-xl bg-gradient-to-br ${currentStep.color} flex items-center justify-center shadow-lg`}
            >
              <Icon className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <DialogTitle className="text-xl">{currentStep.title}</DialogTitle>
              <DialogDescription>{currentStep.description}</DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="py-4"
          >
            {currentStep.content}
          </motion.div>
        </AnimatePresence>

        {/* Progress Dots */}
        <div className="flex items-center justify-center gap-2 py-2">
          {steps.map((_, i) => (
            <div
              key={i}
              className={`w-2 h-2 rounded-full transition-all ${
                i === step
                  ? "bg-blue-600 dark:bg-blue-400 w-8"
                  : "bg-gray-300 dark:bg-gray-600"
              }`}
            />
          ))}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between gap-3 pt-4 border-t">
          {step > 0 && (
            <Button variant="outline" onClick={() => setStep(step - 1)}>
              Kembali
            </Button>
          )}
          {step < steps.length - 1 ? (
            <Button
              onClick={() => setStep(step + 1)}
              className="ml-auto bg-gradient-to-r from-blue-600 to-blue-500 text-white hover:from-blue-700 hover:to-blue-600 shadow-md"
            >
              Lanjut
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button
              onClick={handleClose}
              className="ml-auto bg-gradient-to-r from-blue-600 to-blue-500 text-white hover:from-blue-700 hover:to-blue-600 shadow-md"
            >
              Mulai Sekarang! 🚀
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function FeatureItem({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center flex-shrink-0">
        <Icon className="w-4 h-4 text-white" />
      </div>
      <div>
        <div className="font-semibold text-sm text-slate-900 dark:text-white">{title}</div>
        <div className="text-xs text-slate-600 dark:text-slate-400">{desc}</div>
      </div>
    </div>
  );
}

function StepItem({ number, title, desc, link }: { number: number; title: string; desc: string; link: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-600 to-blue-500 text-white flex items-center justify-center font-bold flex-shrink-0">
        {number}
      </div>
      <div>
        <Link to={link} className="font-semibold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
          {title} →
        </Link>
        <div className="text-sm text-slate-600 dark:text-slate-400">{desc}</div>
      </div>
    </div>
  );
}