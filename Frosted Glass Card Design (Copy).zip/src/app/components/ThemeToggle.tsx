import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/app/components/ui/button";
import { useEffect, useState } from "react";

export function ThemeToggle() {
  const { theme, setTheme, systemTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <Button variant="ghost" size="icon" className="w-9 h-9">
        <Sun size={18} />
      </Button>
    );
  }

  const currentTheme = theme === "system" ? systemTheme : theme;

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setTheme(currentTheme === "dark" ? "light" : "dark")}
      className="w-9 h-9 hover:bg-muted"
      title={currentTheme === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode"}
    >
      {currentTheme === "dark" ? (
        <Sun size={18} className="text-muted-foreground" />
      ) : (
        <Moon size={18} className="text-muted-foreground" />
      )}
    </Button>
  );
}