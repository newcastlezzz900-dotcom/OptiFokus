import { useState, useEffect } from "react";
import { Card, CardContent } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Progress } from "@/app/components/ui/progress";
import { motion, AnimatePresence } from "motion/react";
import { Brain, Zap, AlertTriangle, TrendingDown, Users } from "lucide-react";
import { toast } from "sonner";

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: "easy" | "medium" | "hard";
  timeLimit: number; // in seconds
}

interface AdaptiveQuizProps {
  onSuccess: () => void;
  onFail: () => void;
  totalQuestions?: number;
}

// Mock quiz data - in real app this would come from user's uploaded materials
const QUIZ_POOL: QuizQuestion[] = [
  // Easy questions (5 seconds)
  {
    id: "e1",
    question: "Berapa hasil dari 5 + 3?",
    options: ["6", "7", "8", "9"],
    correctAnswer: 2,
    difficulty: "easy",
    timeLimit: 5,
  },
  {
    id: "e2",
    question: "Apa ibu kota Indonesia?",
    options: ["Bandung", "Surabaya", "Jakarta", "Medan"],
    correctAnswer: 2,
    difficulty: "easy",
    timeLimit: 5,
  },
  {
    id: "e3",
    question: "Berapa jumlah hari dalam seminggu?",
    options: ["5", "6", "7", "8"],
    correctAnswer: 2,
    difficulty: "easy",
    timeLimit: 5,
  },
  // Medium questions (8 seconds)
  {
    id: "m1",
    question: "Turunan dari f(x) = x² adalah?",
    options: ["x", "2x", "x²", "2"],
    correctAnswer: 1,
    difficulty: "medium",
    timeLimit: 8,
  },
  {
    id: "m2",
    question: "Rumus kimia air adalah?",
    options: ["H2O", "CO2", "O2", "H2O2"],
    correctAnswer: 0,
    difficulty: "medium",
    timeLimit: 8,
  },
  {
    id: "m3",
    question: "Siapa penemu teori relativitas?",
    options: ["Newton", "Einstein", "Galileo", "Tesla"],
    correctAnswer: 1,
    difficulty: "medium",
    timeLimit: 8,
  },
  // Hard questions (10 seconds)
  {
    id: "h1",
    question: "Integral dari ∫2x dx adalah?",
    options: ["x²", "x² + C", "2x²", "x² + 2C"],
    correctAnswer: 1,
    difficulty: "hard",
    timeLimit: 10,
  },
  {
    id: "h2",
    question: "Hukum Newton ke-2 menyatakan?",
    options: [
      "F = m × a",
      "E = mc²",
      "F = G × (m1×m2)/r²",
      "P = F/A"
    ],
    correctAnswer: 0,
    difficulty: "hard",
    timeLimit: 10,
  },
  {
    id: "h3",
    question: "Berapa kecepatan cahaya di ruang hampa?",
    options: [
      "3 × 10⁸ m/s",
      "3 × 10⁶ m/s",
      "3 × 10⁹ m/s",
      "3 × 10⁷ m/s"
    ],
    correctAnswer: 0,
    difficulty: "hard",
    timeLimit: 10,
  },
];

export function AdaptiveQuiz({ onSuccess, onFail, totalQuestions = 5 }: AdaptiveQuizProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard">("medium");
  const [timeLeft, setTimeLeft] = useState(8);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [isAnswering, setIsAnswering] = useState(false);
  const [showResult, setShowResult] = useState(false);

  // Initialize adaptive questions
  useEffect(() => {
    const selectedQuestions = selectAdaptiveQuestions(difficulty, totalQuestions);
    setQuestions(selectedQuestions);
    if (selectedQuestions.length > 0) {
      setTimeLeft(selectedQuestions[0].timeLimit);
    }
  }, []);

  // Timer
  useEffect(() => {
    if (isAnswering || showResult || questions.length === 0) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentQuestionIndex, isAnswering, showResult, questions]);

  const selectAdaptiveQuestions = (diff: "easy" | "medium" | "hard", count: number) => {
    const pool = QUIZ_POOL.filter((q) => q.difficulty === diff);
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, Math.min(count, shuffled.length));
  };

  const handleTimeout = () => {
    toast.error("Waktu habis!");
    handleNext(null);
  };

  const handleAnswerSelect = (index: number) => {
    if (isAnswering) return;
    setSelectedAnswer(index);
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null || isAnswering) return;
    
    setIsAnswering(true);
    const currentQuestion = questions[currentQuestionIndex];
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer;

    if (isCorrect) {
      setScore(score + 1);
      toast.success("Benar! 🎉");
      
      // Adaptive difficulty: increase if doing well
      if (score + 1 >= Math.ceil(totalQuestions / 2) && difficulty !== "hard") {
        const newDiff = difficulty === "easy" ? "medium" : "hard";
        adaptDifficulty(newDiff);
      }
    } else {
      toast.error("Salah!");
      
      // Adaptive difficulty: decrease if struggling
      if (score < currentQuestionIndex / 2 && difficulty !== "easy") {
        const newDiff = difficulty === "hard" ? "medium" : "easy";
        adaptDifficulty(newDiff);
      }
    }

    setTimeout(() => handleNext(isCorrect), 1000);
  };

  const adaptDifficulty = (newDiff: "easy" | "medium" | "hard") => {
    setDifficulty(newDiff);
    // Replace remaining questions with new difficulty
    const remainingCount = totalQuestions - (currentQuestionIndex + 1);
    if (remainingCount > 0) {
      const newQuestions = selectAdaptiveQuestions(newDiff, remainingCount);
      setQuestions([
        ...questions.slice(0, currentQuestionIndex + 1),
        ...newQuestions,
      ]);
    }
  };

  const handleNext = (wasCorrect: boolean | null) => {
    setIsAnswering(false);
    setSelectedAnswer(null);

    if (currentQuestionIndex + 1 >= questions.length) {
      // Quiz finished
      setShowResult(true);
      const passThreshold = Math.ceil(totalQuestions * 0.7); // 70% to pass
      
      setTimeout(() => {
        if (score >= passThreshold) {
          onSuccess();
        } else {
          onFail();
        }
      }, 2000);
    } else {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setTimeLeft(questions[currentQuestionIndex + 1].timeLimit);
    }
  };

  if (questions.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Loading quiz...</p>
      </div>
    );
  }

  if (showResult) {
    const passThreshold = Math.ceil(totalQuestions * 0.7);
    const passed = score >= passThreshold;

    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center py-8"
      >
        <div className={`text-6xl mb-4 ${passed ? "animate-bounce" : ""}`}>
          {passed ? "🎉" : "😔"}
        </div>
        <h3 className={`text-2xl font-bold mb-2 ${
          passed ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"
        }`}>
          {passed ? "Quiz Selesai!" : "Belum Berhasil"}
        </h3>
        <p className="text-gray-600 dark:text-gray-400 mb-4">
          Skor kamu: {score}/{totalQuestions} ({Math.round((score / totalQuestions) * 100)}%)
        </p>
        <p className="text-sm text-gray-500">
          {passed 
            ? "Aplikasi akan terbuka dalam 2 detik..." 
            : "Kamu harus menjawab minimal 70% benar. Coba lagi!"}
        </p>
      </motion.div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / totalQuestions) * 100;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="text-purple-600" size={24} />
          <div>
            <h3 className="font-bold text-gray-900 dark:text-white">
              Micro-Learning Quiz
            </h3>
            <p className="text-xs text-gray-500">
              Difficulty: <span className={`font-semibold ${
                difficulty === "easy" ? "text-green-600" :
                difficulty === "medium" ? "text-yellow-600" :
                "text-red-600"
              }`}>
                {difficulty === "easy" ? "Mudah" : difficulty === "medium" ? "Sedang" : "Sulit"}
              </span>
            </p>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            Soal {currentQuestionIndex + 1} dari {totalQuestions}
          </div>
          <div className={`text-2xl font-bold ${
            timeLeft <= 3 ? "text-red-600 animate-pulse" : "text-blue-600"
          }`}>
            {timeLeft}s
          </div>
        </div>
      </div>

      {/* Progress */}
      <div>
        <Progress value={progress} className="h-2" />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>Skor: {score}/{currentQuestionIndex}</span>
          <span>{Math.round(progress)}%</span>
        </div>
      </div>

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestion.id}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
        >
          <Card className="border-2 border-purple-200 dark:border-purple-800">
            <CardContent className="p-6">
              <div className="flex items-start gap-3 mb-6">
                <Zap className="text-yellow-600 mt-1 flex-shrink-0" size={20} />
                <h4 className="text-lg font-semibold text-gray-900 dark:text-white">
                  {currentQuestion.question}
                </h4>
              </div>

              <div className="space-y-3">
                {currentQuestion.options.map((option, index) => (
                  <motion.button
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleAnswerSelect(index)}
                    disabled={isAnswering}
                    className={`w-full p-4 rounded-lg border-2 text-left transition-all ${
                      selectedAnswer === index
                        ? "border-blue-500 bg-blue-50 dark:bg-blue-950/30 shadow-lg"
                        : "border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-700"
                    } ${isAnswering ? "opacity-50 cursor-not-allowed" : ""}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        selectedAnswer === index
                          ? "border-blue-500 bg-blue-500"
                          : "border-gray-300 dark:border-gray-600"
                      }`}>
                        {selectedAnswer === index && (
                          <div className="w-3 h-3 bg-white rounded-full" />
                        )}
                      </div>
                      <span className="text-gray-900 dark:text-white font-medium">
                        {option}
                      </span>
                    </div>
                  </motion.button>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>

      {/* Submit Button */}
      <Button
        onClick={handleSubmitAnswer}
        disabled={selectedAnswer === null || isAnswering}
        className="w-full h-12 bg-gradient-to-r from-purple-600 to-blue-600 disabled:opacity-50"
        size="lg"
      >
        {isAnswering ? "Memeriksa..." : "Submit Jawaban"}
      </Button>
    </div>
  );
}
