import { motion } from "motion/react";
import { Card, CardContent } from "@/app/components/ui/card";
import { 
  TrendingDown, 
  Flame, 
  Trophy, 
  Users, 
  AlertTriangle,
  XCircle,
  ArrowDown
} from "lucide-react";
import { getUserStats } from "@/app/lib/store";

interface LossItem {
  icon: React.ReactNode;
  label: string;
  current: string | number;
  after: string | number;
  severity: "critical" | "high" | "medium";
}

export function LossAversionWarning() {
  const stats = getUserStats();

  const losses: LossItem[] = [
    {
      icon: <Flame size={24} className="text-orange-500" />,
      label: "Streak Hilang",
      current: `${stats.streak} hari`,
      after: "0 hari",
      severity: "critical",
    },
    {
      icon: <Trophy size={24} className="text-yellow-500" />,
      label: "Poin Berkurang",
      current: stats.points,
      after: Math.max(0, stats.points - 50),
      severity: "high",
    },
    {
      icon: <TrendingDown size={24} className="text-red-500" />,
      label: "Ranking Turun",
      current: "Top 10%",
      after: "Top 30%",
      severity: "high",
    },
    {
      icon: <Users size={24} className="text-purple-500" />,
      label: "Level Avatar",
      current: "Level 3",
      after: "Level 2",
      severity: "medium",
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="space-y-4"
    >
      {/* Critical Warning Header */}
      <Card className="border-4 border-red-500 bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950/30 dark:to-orange-950/30">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-red-500 rounded-full animate-pulse">
              <AlertTriangle size={32} className="text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-2xl font-bold text-red-900 dark:text-red-200 mb-2">
                ⚠️ Peringatan Serius!
              </h3>
              <p className="text-red-800 dark:text-red-300 text-lg">
                Membuka aplikasi sekarang akan menyebabkan kerugian besar pada progress kamu!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Loss Preview */}
      <Card className="dark:bg-gray-900 dark:border-gray-800">
        <CardContent className="p-6">
          <h4 className="font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <XCircle className="text-red-600" />
            Kerugian yang Akan Kamu Alami:
          </h4>
          
          <div className="space-y-3">
            {losses.map((loss, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`p-4 rounded-lg border-2 ${
                  loss.severity === "critical"
                    ? "border-red-500 bg-red-50 dark:bg-red-950/30"
                    : loss.severity === "high"
                    ? "border-orange-500 bg-orange-50 dark:bg-orange-950/30"
                    : "border-yellow-500 bg-yellow-50 dark:bg-yellow-950/30"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {loss.icon}
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">
                        {loss.label}
                      </p>
                      <div className="flex items-center gap-2 text-sm mt-1">
                        <span className="text-green-600 dark:text-green-400 font-medium">
                          {loss.current}
                        </span>
                        <ArrowDown className="text-red-600" size={16} />
                        <span className="text-red-600 dark:text-red-400 font-medium line-through">
                          {loss.after}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  {loss.severity === "critical" && (
                    <div className="px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-full animate-pulse">
                      CRITICAL
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Motivational Alternative */}
      <Card className="border-2 border-green-500 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30">
        <CardContent className="p-6">
          <h4 className="font-bold text-green-900 dark:text-green-200 mb-3">
            💡 Alternatif Lebih Baik:
          </h4>
          <ul className="space-y-2 text-green-800 dark:text-green-300">
            <li className="flex items-start gap-2">
              <span className="text-green-600 mt-1">✓</span>
              <span>Bertahan 15 menit lagi, lalu break tanpa penalty</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600 mt-1">✓</span>
              <span>Dapatkan bonus +10 poin untuk konsistensi</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600 mt-1">✓</span>
              <span>Pertahankan streak dan ranking kamu</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </motion.div>
  );
}
