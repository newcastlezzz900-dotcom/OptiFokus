import { ReactNode } from "react";
import { Navbar } from "./Navbar";
import { BottomNav } from "./BottomNav";
import { FloatingChatButton } from "./FloatingChatButton";

interface AppLayoutProps {
  children: ReactNode;
  showChat?: boolean;
}

export function AppLayout({ children, showChat = true }: AppLayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-20 md:pb-0">
      <Navbar />
      {showChat && <FloatingChatButton />}
      <BottomNav />
      {children}
    </div>
  );
}
