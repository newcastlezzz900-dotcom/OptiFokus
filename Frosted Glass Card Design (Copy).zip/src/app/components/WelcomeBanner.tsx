/**
 * Welcome Banner - Subtle & Non-Intrusive
 * Replaces the annoying full-screen modal
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Sparkles, ArrowRight } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Link } from "react-router";

const WELCOME_SHOWN_KEY = "optifokus_welcome_shown_v2";

export function WelcomeBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const hasShown = localStorage.getItem(WELCOME_SHOWN_KEY);
    if (!hasShown) {
      // Show banner after 1 second
      setTimeout(() => setIsVisible(true), 1000);
      
      // Auto-hide after 8 seconds
      setTimeout(() => {
        setIsVisible(false);
        localStorage.setItem(WELCOME_SHOWN_KEY, "true");
      }, 9000);
    }
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    localStorage.setItem(WELCOME_SHOWN_KEY, "true");
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -50 }}
          transition={{ type: "spring", bounce: 0.3 }}
          className="fixed top-20 left-1/2 -translate-x-1/2 z-50 w-[95%] sm:w-auto max-w-2xl"
        >
          <div className="bg-gradient-to-r from-blue-500 via-blue-600 to-indigo-600 rounded-2xl shadow-2xl border-2 border-blue-300/50 backdrop-blur-xl p-4 sm:p-6 relative overflow-hidden">
            {/* Decorative Elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl" />
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2 blur-2xl" />
            
            {/* Close Button */}
            <button
              onClick={handleClose}
              className="absolute top-3 right-3 p-1.5 bg-white/20 hover:bg-white/30 rounded-full transition-colors backdrop-blur-sm"
            >
              <X className="w-4 h-4 text-white" />
            </button>

            {/* Content */}
            <div className="relative">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm flex-shrink-0">
                  <Sparkles className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="text-xl sm:text-2xl font-bold text-white mb-2 flex items-center gap-2">
                    Selamat Datang di OptiFokus! 🎉
                  </h3>
                  <p className="text-blue-50 text-sm sm:text-base mb-4">
                    Aplikasi anti-distraksi dengan <strong className="text-white">Contextual Learning</strong>. 
                    Belajar sambil unlock aplikasi yang diblokir!
                  </p>

                  {/* Quick Stats */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
                    <div className="bg-white/20 backdrop-blur-sm rounded-lg p-2 text-center">
                      <div className="text-lg sm:text-xl font-bold text-white">+152%</div>
                      <div className="text-[10px] sm:text-xs text-blue-100">Fokus ↑</div>
                    </div>
                    <div className="bg-white/20 backdrop-blur-sm rounded-lg p-2 text-center">
                      <div className="text-lg sm:text-xl font-bold text-white">-74%</div>
                      <div className="text-[10px] sm:text-xs text-blue-100">Distraksi ↓</div>
                    </div>
                    <div className="bg-white/20 backdrop-blur-sm rounded-lg p-2 text-center">
                      <div className="text-lg sm:text-xl font-bold text-white">87%</div>
                      <div className="text-[10px] sm:text-xs text-blue-100">Quiz</div>
                    </div>
                    <div className="bg-white/20 backdrop-blur-sm rounded-lg p-2 text-center">
                      <div className="text-lg sm:text-xl font-bold text-white">89%</div>
                      <div className="text-[10px] sm:text-xs text-blue-100">Success</div>
                    </div>
                  </div>

                  {/* CTA */}
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Link to="/upload" className="flex-1">
                      <Button 
                        className="w-full bg-white hover:bg-blue-50 text-blue-600 font-semibold shadow-lg"
                        onClick={handleClose}
                      >
                        Upload Materi
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                    <Button
                      variant="ghost"
                      className="text-white hover:bg-white/20 border border-white/30"
                      onClick={handleClose}
                    >
                      Nanti Saja
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
