import { motion } from "motion/react";
import { Card, CardContent } from "@/app/components/ui/card";
import { Users, TrendingUp, Award, Clock } from "lucide-react";

interface PeerData {
  name: string;
  avatar: string;
  status: string;
  focusTime: number;
}

export function SilentSocialPressure() {
  // Mock peer data - in real app this would come from server
  const peers: PeerData[] = [
    { name: "Anonymous User #1", avatar: "👨‍🎓", status: "Fokus sejak 45 menit lalu", focusTime: 45 },
    { name: "Anonymous User #2", avatar: "👩‍💻", status: "Fokus sejak 30 menit lalu", focusTime: 30 },
    { name: "Anonymous User #3", avatar: "🧑‍💼", status: "Fokus sejak 60 menit lalu", focusTime: 60 },
  ];

  const stats = {
    totalFocusing: 127,
    avgSessionTime: 42,
    topPercentile: 15,
  };

  return (
    <div className="space-y-4">
      {/* Community Stats */}
      <Card className="border-2 border-blue-200 dark:border-blue-800 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30">
        <CardContent className="p-6">
          <h4 className="font-bold text-blue-900 dark:text-blue-200 mb-4 flex items-center gap-2">
            <Users size={20} />
            Komunitas Saat Ini
          </h4>
          
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                {stats.totalFocusing}
              </div>
              <div className="text-xs text-blue-800 dark:text-blue-300 mt-1">
                Sedang Fokus
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                {stats.avgSessionTime}m
              </div>
              <div className="text-xs text-blue-800 dark:text-blue-300 mt-1">
                Rata-rata Sesi
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                Top {stats.topPercentile}%
              </div>
              <div className="text-xs text-blue-800 dark:text-blue-300 mt-1">
                Ranking Kamu
              </div>
            </div>
          </div>

          <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
            <p className="text-sm text-blue-900 dark:text-blue-200 text-center">
              📊 Kamu berada di <span className="font-bold">Top 15%</span> pengguna paling produktif!
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Peer Activity Feed */}
      <Card className="dark:bg-gray-900 dark:border-gray-800">
        <CardContent className="p-6">
          <h4 className="font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <TrendingUp size={20} className="text-green-600" />
            Teman-teman Masih Fokus
          </h4>
          
          <div className="space-y-3">
            {peers.map((peer, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700"
              >
                <div className="text-3xl">{peer.avatar}</div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900 dark:text-white text-sm">
                    {peer.name}
                  </p>
                  <div className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                    {peer.status}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-gray-900 dark:text-white">
                    {peer.focusTime}m
                  </div>
                  <div className="text-xs text-gray-500">fokus</div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-4 p-3 bg-purple-50 dark:bg-purple-950/30 rounded-lg border border-purple-200 dark:border-purple-800">
            <p className="text-sm text-purple-900 dark:text-purple-200 text-center">
              💪 <span className="font-bold">127 pengguna</span> lain sedang fokus belajar. Jangan menyerah sekarang!
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Impact of Quitting */}
      <Card className="border-2 border-orange-200 dark:border-orange-800 bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/30 dark:to-red-950/30">
        <CardContent className="p-6">
          <h4 className="font-bold text-orange-900 dark:text-orange-200 mb-3 flex items-center gap-2">
            <Award size={20} />
            Dampak Jika Unlock Sekarang
          </h4>
          
          <div className="space-y-2 text-sm text-orange-800 dark:text-orange-300">
            <div className="flex items-center justify-between p-2 bg-white/50 dark:bg-black/20 rounded">
              <span>Ranking kamu akan turun</span>
              <span className="font-bold text-red-600">Top 15% → Top 35%</span>
            </div>
            <div className="flex items-center justify-between p-2 bg-white/50 dark:bg-black/20 rounded">
              <span>Streak akan reset</span>
              <span className="font-bold text-red-600">0 hari</span>
            </div>
            <div className="flex items-center justify-between p-2 bg-white/50 dark:bg-black/20 rounded">
              <span>Terlempar dari leaderboard</span>
              <span className="font-bold text-red-600">-50 poin</span>
            </div>
          </div>

          <div className="mt-4 p-3 bg-red-100 dark:bg-red-900/30 rounded-lg border-2 border-red-400">
            <p className="text-sm text-red-900 dark:text-red-200 text-center font-semibold">
              🔻 127 orang akan mendahului kamu di leaderboard
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Encouragement */}
      <Card className="border-2 border-green-500 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30">
        <CardContent className="p-6">
          <div className="text-center">
            <div className="text-4xl mb-3">🏆</div>
            <p className="font-bold text-green-900 dark:text-green-200 text-lg mb-2">
              Kamu Hampir Sampai!
            </p>
            <p className="text-green-800 dark:text-green-300 text-sm">
              Bertahan 15 menit lagi dan dapatkan <span className="font-bold">+25 bonus poin</span> untuk konsistensi!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
