import { Link, useLocation } from "react-router";
import { Home, Focus, BookOpen, Users, Settings, Shield, Trophy, Calendar } from "lucide-react";
import { getUserStats } from "@/app/lib/store";
import { useState, useEffect } from "react";
import { ThemeToggle } from "./ThemeToggle";

export function Navbar() {
  const location = useLocation();
  const [stats, setStats] = useState(getUserStats());

  useEffect(() => {
    setStats(getUserStats());
  }, [location.pathname]);

  const navItems = [
    { path: "/dashboard", icon: Home, label: "Home" },
    { path: "/focus", icon: Focus, label: "Fokus" },
    { path: "/upload", icon: BookOpen, label: "Materi" },
    { path: "/schedule", icon: Calendar, label: "Jadwal" },
    { path: "/leaderboard", icon: Trophy, label: "Leaderboard" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ];

  return (
    <nav className="bg-white/95 dark:bg-slate-900/95 border-b border-blue-200 dark:border-blue-900 sticky top-0 z-50 backdrop-blur-xl shadow-lg">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Logo - Clickable to Dashboard */}
          <Link to="/dashboard" className="flex items-center gap-3 flex-shrink-0 group">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all group-hover:scale-105">
              <Shield className="text-white" size={24} />
            </div>
            <div className="hidden sm:block">
              <h1 className="font-bold text-xl sm:text-2xl bg-gradient-to-r from-blue-600 to-blue-800 dark:from-blue-400 dark:to-blue-600 bg-clip-text text-transparent">
                OptiFokus
              </h1>
              <p className="text-xs text-blue-600 dark:text-blue-400 -mt-1 font-medium">Belajar Tanpa Distraksi</p>
            </div>
          </Link>

          {/* Desktop Nav Items */}
          <div className="hidden md:flex items-center gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path || 
                              (item.path === "/dashboard" && location.pathname === "/");
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all font-medium ${
                    isActive
                      ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/30"
                      : "text-slate-600 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-blue-950/30 hover:text-blue-600 dark:hover:text-blue-400"
                  }`}
                >
                  <Icon size={18} />
                  <span className="text-sm">{item.label}</span>
                </Link>
              );
            })}
          </div>

          {/* Right side: Theme + Stats */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Stats - Hidden on mobile, visible on desktop */}
            <div className="hidden lg:flex items-center gap-4 mr-2">
              <div className="text-right bg-blue-50 dark:bg-blue-950/30 px-4 py-2 rounded-xl border border-blue-200 dark:border-blue-800">
                <p className="text-xs text-blue-600 dark:text-blue-400 font-medium">Poin</p>
                <p className="font-bold text-blue-700 dark:text-blue-300 text-lg">{stats.points}</p>
              </div>
              <div className="text-right bg-orange-50 dark:bg-orange-950/30 px-4 py-2 rounded-xl border border-orange-200 dark:border-orange-800">
                <p className="text-xs text-orange-600 dark:text-orange-400 font-medium">Streak</p>
                <p className="font-bold text-orange-700 dark:text-orange-300 flex items-center gap-1 text-lg">
                  🔥 {stats.streak}
                </p>
              </div>
            </div>
            
            <ThemeToggle />
          </div>
        </div>
      </div>
    </nav>
  );
}
