import { motion } from "motion/react";
import { Sparkles } from "lucide-react";

interface AvatarEvolutionProps {
  meetings: number;
  streak: number;
}

// Evolution stages berdasarkan meetings
const getEvolutionStage = (meetings: number, streak: number): number => {
  // Bonus evolution dari streak (setiap minggu = 7 hari)
  const weekBonus = Math.floor(streak / 7);
  
  if (meetings >= 1500 || weekBonus >= 50) return 5; // Max evolution
  if (meetings >= 1000 || weekBonus >= 30) return 4;
  if (meetings >= 500 || weekBonus >= 15) return 3;
  if (meetings >= 200 || weekBonus >= 5) return 2;
  if (meetings >= 50 || weekBonus >= 1) return 1;
  return 0; // Starter
};

const getCreatureData = (stage: number) => {
  const creatures = [
    {
      name: "Fokito",
      description: "Makhluk pemula yang baru mulai belajar fokus",
      color: "#94a3b8",
      size: 60,
      emoji: "🥚",
    },
    {
      name: "Fokito Junior",
      description: "Mulai tumbuh dengan semangat belajar",
      color: "#60a5fa",
      size: 80,
      emoji: "🐣",
    },
    {
      name: "Fokusmon",
      description: "Kini lebih kuat dan fokus!",
      color: "#3b82f6",
      size: 100,
      emoji: "🐥",
    },
    {
      name: "Fokusmon Alpha",
      description: "Master dalam konsentrasi",
      color: "#8b5cf6",
      size: 120,
      emoji: "🦅",
    },
    {
      name: "Fokusmon Supreme",
      description: "Legenda produktivitas!",
      color: "#c026d3",
      size: 140,
      emoji: "🦉",
    },
    {
      name: "Fokusmon Ultimate",
      description: "RAJA FOKUS - Pencapaian Tertinggi!",
      color: "#f59e0b",
      size: 160,
      emoji: "👑",
    },
  ];

  return creatures[stage];
};

const getProgressToNext = (meetings: number, streak: number): number => {
  const stage = getEvolutionStage(meetings, streak);
  const thresholds = [0, 50, 200, 500, 1000, 1500];
  
  if (stage >= 5) return 100; // Max level
  
  const currentThreshold = thresholds[stage];
  const nextThreshold = thresholds[stage + 1];
  const progress = ((meetings - currentThreshold) / (nextThreshold - currentThreshold)) * 100;
  
  return Math.min(progress, 100);
};

export function AvatarEvolution({ meetings, streak }: AvatarEvolutionProps) {
  const stage = getEvolutionStage(meetings, streak);
  const creature = getCreatureData(stage);
  const progress = getProgressToNext(meetings, streak);
  const weekBonus = Math.floor(streak / 7);

  return (
    <div className="relative">
      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 text-center">
        {/* Avatar Container */}
        <motion.div
          className="relative inline-block"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", duration: 0.6 }}
        >
          {/* Glow Effect */}
          <motion.div
            className="absolute inset-0 rounded-full blur-2xl opacity-50"
            style={{ backgroundColor: creature.color }}
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />

          {/* Main Avatar Circle */}
          <motion.div
            className="relative rounded-full flex items-center justify-center"
            style={{
              width: creature.size,
              height: creature.size,
              backgroundColor: creature.color,
              boxShadow: `0 10px 40px ${creature.color}40`,
            }}
            whileHover={{ scale: 1.1 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <span className="text-5xl">{creature.emoji}</span>
          </motion.div>

          {/* Sparkles for higher stages */}
          {stage >= 3 && (
            <motion.div
              className="absolute -top-2 -right-2"
              animate={{
                rotate: 360,
                scale: [1, 1.2, 1],
              }}
              transition={{
                rotate: { duration: 3, repeat: Infinity, ease: "linear" },
                scale: { duration: 1.5, repeat: Infinity },
              }}
            >
              <Sparkles className="text-yellow-400" size={24} />
            </motion.div>
          )}
        </motion.div>

        {/* Creature Info */}
        <motion.div
          className="mt-6 space-y-2"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-2xl font-bold" style={{ color: creature.color }}>
            {creature.name}
          </h3>
          <p className="text-sm text-gray-600">{creature.description}</p>
          
          <div className="flex items-center justify-center gap-2 mt-4 text-sm">
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
              Level {stage}
            </span>
            <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full">
              {meetings} Pertemuan
            </span>
            {weekBonus > 0 && (
              <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full">
                +{weekBonus} minggu bonus
              </span>
            )}
          </div>
        </motion.div>

        {/* Progress to Next Evolution */}
        {stage < 5 && (
          <motion.div
            className="mt-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <div className="flex items-center justify-between text-xs text-gray-600 mb-2">
              <span>Progress ke level berikutnya</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </div>
            <p className="text-xs text-gray-500 mt-2">
              {stage < 5 && `Perlu ${[50, 200, 500, 1000, 1500][stage + 1] - meetings} pertemuan lagi`}
            </p>
          </motion.div>
        )}

        {stage === 5 && (
          <motion.div
            className="mt-4 text-yellow-600 font-bold"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            ⭐ EVOLUSI MAKSIMUM! ⭐
          </motion.div>
        )}
      </div>
    </div>
  );
}
