import { Link, useLocation } from "react-router";
import { Home, Focus, Calendar, Users, Settings } from "lucide-react";
import { motion } from "motion/react";

export function BottomNav() {
  const location = useLocation();

  const navItems = [
    { path: "/dashboard", icon: Home, label: "Home" },
    { path: "/focus", icon: Focus, label: "Fokus" },
    { path: "/schedule", icon: Calendar, label: "Jadwal" },
    { path: "/community", icon: Users, label: "Community" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-t-2 border-blue-200 dark:border-blue-900 z-50 pb-safe shadow-lg">
      <div className="flex items-center justify-around px-2 py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path || 
                          (item.path === "/dashboard" && location.pathname === "/");
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className="relative flex flex-col items-center justify-center flex-1 py-2 px-1 rounded-xl transition-all active:scale-95"
            >
              {isActive && (
                <motion.div
                  layoutId="bottomNavActiveIndicator"
                  className="absolute top-0 left-1/2 transform -translate-x-1/2 w-12 h-1 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full shadow-lg"
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
              )}
              <div className={`p-2 rounded-xl transition-all ${
                isActive 
                  ? "bg-gradient-to-r from-blue-500 to-blue-600 shadow-lg" 
                  : "bg-transparent"
              }`}>
                <Icon
                  size={22}
                  className={`transition-colors ${
                    isActive
                      ? "text-white"
                      : "text-slate-600 dark:text-slate-400"
                  }`}
                />
              </div>
              <span
                className={`text-[10px] mt-1 transition-colors font-medium ${
                  isActive
                    ? "text-blue-600 dark:text-blue-400 font-bold"
                    : "text-slate-600 dark:text-slate-400"
                }`}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}