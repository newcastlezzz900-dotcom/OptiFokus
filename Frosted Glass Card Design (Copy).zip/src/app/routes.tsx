import { createBrowserRouter } from "react-router";
import { Dashboard } from "./pages/Dashboard";
import { FocusModeEnhanced } from "./pages/FocusModeEnhanced";
import { QuizChallenge } from "./pages/QuizChallenge";
import { UploadMateri } from "./pages/UploadMateri";
import { SilentRoomEnhanced } from "./pages/SilentRoomEnhanced";
import { Settings } from "./pages/Settings";
import { EmergencyUnlock } from "./pages/EmergencyUnlock";
import { Leaderboard } from "./pages/Leaderboard";
import { Community } from "./pages/Community";
import { Schedule } from "./pages/Schedule";
import { Analytics } from "./pages/Analytics";
import { ResearchDashboard } from "./pages/ResearchDashboard";
import { Impact } from "./pages/Impact";
import { AccountabilitySettings } from "./pages/AccountabilitySettings";
import { MateriViewer } from "./pages/MateriViewer";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Dashboard />,
  },
  {
    path: "/dashboard",
    element: <Dashboard />,
  },
  {
    path: "/focus",
    element: <FocusModeEnhanced />,
  },
  {
    path: "/quiz",
    element: <QuizChallenge />,
  },
  {
    path: "/upload",
    element: <UploadMateri />,
  },
  {
    path: "/materi",
    element: <MateriViewer />,
  },
  {
    path: "/schedule",
    element: <Schedule />,
  },
  {
    path: "/silent-room",
    element: <SilentRoomEnhanced />,
  },
  {
    path: "/analytics",
    element: <Analytics />,
  },
  {
    path: "/research",
    element: <ResearchDashboard />,
  },
  {
    path: "/settings",
    element: <Settings />,
  },
  {
    path: "/accountability",
    element: <AccountabilitySettings />,
  },
  {
    path: "/emergency",
    element: <EmergencyUnlock />,
  },
  {
    path: "/leaderboard",
    element: <Leaderboard />,
  },
  {
    path: "/community",
    element: <Community />,
  },
  {
    path: "/impact",
    element: <Impact />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);